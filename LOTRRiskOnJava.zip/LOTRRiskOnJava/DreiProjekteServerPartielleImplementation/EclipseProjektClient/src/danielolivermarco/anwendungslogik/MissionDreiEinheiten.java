

package danielolivermarco.anwendungslogik;

import java.io.Serializable;
import java.util.ArrayList;
import danielolivermarco.datenhaltung.*;

public class MissionDreiEinheiten extends Mission implements Serializable{

	public MissionDreiEinheiten(Spieler eingabeBesitzer) {
		super(eingabeBesitzer);
		
	}
	
	
	

	public boolean erfuellt(){
		// Erst die L�nder vom besitzenden Spieler holen
		ArrayList<Land> besitzerLaender = besitzer.getBesitzLaender();
		// wenn der Besitzer keine 15 L�nder hat, ist die Mission nicht erf�llt
		if( besitzerLaender.size() < 15) return false;
		int laenderMit3 = 0;
		// danach jedes Land des Spielers (welcher die Missionskarte besitzt) angucken
		for( Land l : besitzerLaender){
		//wenn das angesehende Land mehr als 3 Einheiten hat, dann setze den zaehler f�r l�nder mit mehr als 3 einheiten einen hoch
			if( l.getSpielerArmee().getArmee().size() >= 3 ) laenderMit3++;
		}
		if(laenderMit3 >= 15){
			return true;
		}
		return false;
		
	}

}
