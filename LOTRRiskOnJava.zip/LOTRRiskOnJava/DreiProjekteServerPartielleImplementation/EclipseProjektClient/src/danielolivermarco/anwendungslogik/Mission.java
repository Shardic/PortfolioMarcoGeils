package danielolivermarco.anwendungslogik;

import java.io.Serializable;

import danielolivermarco.datenhaltung.*;

public class Mission implements Serializable{
	
	Spieler besitzer;
	
	public Mission(Spieler eingabeBesitzer){
		
		besitzer = eingabeBesitzer;
	}
	
	
	public boolean erfuellt(){
		return true;	
	}
}

