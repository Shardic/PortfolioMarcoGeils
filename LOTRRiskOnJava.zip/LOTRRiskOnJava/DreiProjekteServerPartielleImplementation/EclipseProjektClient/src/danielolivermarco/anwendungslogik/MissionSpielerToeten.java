package danielolivermarco.anwendungslogik;

import java.io.Serializable;
import java.util.ArrayList;
import danielolivermarco.datenhaltung.*;

public class MissionSpielerToeten extends Mission implements Serializable{

	private Spieler toetungsziel; 
	
	
	public MissionSpielerToeten(Spieler eingabeBesitzer, ArrayList<Spieler> spielerListe) {
		super(eingabeBesitzer);
		toetungsziel = waehleZufaelligenSpieler( spielerListe);
		besitzer.setToetungsziel(toetungsziel);
	}
	
		
	protected Spieler waehleZufaelligenSpieler( ArrayList<Spieler> spielerListe){
		// Besitzer der Mission in der Spielerliste finden und entfernen
		// da er sich nicht selbst als zu t�tenden Speiler w�hlen darf
		int posVomSpielerDerMission = spielerListe.indexOf(besitzer);
		Spieler spielerDerMission = spielerListe.get(posVomSpielerDerMission);
		
		// zuf�lligen ANDEREN Spieler aus den �brigen w�hlen
		Spieler erg = null;
		while (erg == null) {
		    int anzahlSp = spielerListe.size();
		    int zufallsPos = (int)(Math.random() * anzahlSp);
		    if (spielerListe.get(zufallsPos) != spielerDerMission){
		    	erg =  spielerListe.get(zufallsPos);
		    }
		}
	    
	    // und zuf�lligen anderen Spieler zur�ckgeben
	    return erg;
		
	}
	// methode die wahr oder falsch auf die Frage antwortet ob die Mission erf�llt ist
	public boolean erfuellt (){
		return !toetungsziel.amLeben();
	}

}
