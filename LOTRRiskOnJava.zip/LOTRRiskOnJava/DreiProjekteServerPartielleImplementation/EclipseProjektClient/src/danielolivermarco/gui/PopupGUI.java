package danielolivermarco.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;

public class PopupGUI {
	
	private JButton button;
	private JDialog popup;
	private JLabel label;
	
	public PopupGUI() {
		popup = new JDialog();
	}

	
	public void start() {
		popup.setTitle("Willkommen");
		label = new JLabel("Willkommen beim Herr der Ringe-Risiko!");
		popup.add(label);
		button = new JButton("OK");
		button.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent e) {
    			if (e.getSource().equals(button)) {
    				popup.setVisible(false);
    				popup.dispose();
    				popup.remove(label);
    			}
    		}
    	});
		popup.add(button);
		
		popup.setVisible(true);
		popup.pack();
		popup.setModal(true);
		popup.setLocationRelativeTo(null);
	}
	
	
	public void fehler() {
		popup.setTitle("Fehler!");
		label = new JLabel("Es ist ein Fehler aufgetreten!");
		popup.add(label);
		button = new JButton("OK");
		button.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent e) {
    			if (e.getSource().equals(button)) {
    				popup.setVisible(false);
    				popup.dispose();
    				popup.remove(label);
    			}
    		}
    	});
		popup.add(button);
		
		popup.setVisible(true);
		popup.pack();
		popup.setModal(true);
		popup.setLocationRelativeTo(null);
	}
	
	public void welcome() {
		label = new JLabel("Willkommen im Spiel.");
		popup.add(label);
	}
	
}
