package danielolivermarco.gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import domain.Client;

public class StartPopup {
	
	JDialog fenster;
	JTextField ip;
	JTextField port;
	SpielGUIClient spiel = new SpielGUIClient();
	
	public StartPopup() {
		fenster = new JDialog();
		fenster.setLayout(new BorderLayout());
		fenster.setSize(400, 200);

		JLabel label = new JLabel("Trage hier die IP und den Port des Servers ein:");
		fenster.add(label, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		ip = new JTextField("127.0.0.1");
		panel.add(ip);
		
		port = new JTextField("9000");
		panel.add(port);
		
		fenster.add(panel, BorderLayout.CENTER);
		
		final JButton button = new JButton("OK");
		button.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent e) {
    			if (e.getSource().equals(button)) {
    				fenster.setVisible(false);
    				fenster.dispose();
    				
    				spiel.setClient(new Client(getIp(), getPort()));
    				try {
						spiel.clientFirstInput();
					} catch (ClassNotFoundException | IOException e1) {
						e1.printStackTrace();
					}
    			}
    		}
    	});
		fenster.add(button, BorderLayout.SOUTH);
		
		fenster.setLocationRelativeTo(null);
		fenster.setVisible(true);
	}
	
	public String getIp() {
		return ip.getText();
	}
	
	public int getPort() {
		return Integer.parseInt(port.getText());
	}
}
