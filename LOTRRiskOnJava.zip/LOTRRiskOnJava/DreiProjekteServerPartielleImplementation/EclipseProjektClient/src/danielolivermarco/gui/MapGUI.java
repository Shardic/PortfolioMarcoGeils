package danielolivermarco.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class MapGUI extends JFrame {
	private Image mapImage;
	private BufferedImage mapBufImg;
	
	public MapGUI(){
		System.out.println("Lade Hintergrund Karte");
		//Bildgr��e
		Dimension dim = new Dimension(500,500);
		//Gui schlie�en, stopppt das programm 
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		this.mapImage = (new ImageIcon(getClass().getResource("/map.png"))).getImage();
		this.mapBufImg = new BufferedImage(dim.width, dim.height, BufferedImage.TYPE_INT_RGB);
		this.mapBufImg.getGraphics().drawImage(new ImageIcon(getClass().getResource("/map_color.png")).getImage(), 0, 0, dim.width, dim.height, this);
		this.setPreferredSize(dim);
		this.setSize(dim);
		
		
		this.addMouseListener(new MouseAdapter(){

			@Override
			public void mouseClicked(MouseEvent me) {
				int x = (int) me.getX();
				int y = (int) me.getY();
				Color col = new Color(getBuffImage().getRGB(x,y));
				
				int red = col.getRed();
				int green = col.getGreen();
				int blue = col.getBlue();
				
				if(red == 255 && blue == 0){
					System.err.println("Rot angeklickt");
				} else if(green == 255 && red == 0 && blue == 6){
					System.err.println("Gr�n angeklickt");
				} else if(red == 255 && blue == 234){
					System.err.println("Pink angeklickt");
				} else if(red == 0 && blue == 234 && green == 255){
					System.err.println("'Blau' angeklickt");
				} else {
					System.err.println("nichts angeklickt");
				}
			}
		});
	}
	
	public BufferedImage getBuffImage(){
		return this.mapBufImg;
	}
	
	public void paint(Graphics g){
		 Graphics2D g2 = (Graphics2D) g;
	        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
	          RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
	        g2.setRenderingHint(RenderingHints.KEY_RENDERING,
	          RenderingHints.VALUE_RENDER_QUALITY);
		
		super.paint(g);
		g.drawImage(mapImage, 0, 0, this.getWidth(), this.getHeight(), this);
		
	}
}
