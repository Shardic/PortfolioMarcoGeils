package danielolivermarco.gui;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

import danielolivermarco.anwendungslogik.*;
import danielolivermarco.datenhaltung.*;
import danielolivermarco.persistens.*;
import domain.Client;

/**
 * Hauptklasse des Spiels, in dieser wird sich ie Main befinden
 * 
 * @author Marco
 *
 */
public class SpielGUIClient implements Serializable{
	/**
	 * @param Die liste der Spieler dieses Spiels 
	 */
	private ArrayList<Spieler> spielerListe = new ArrayList<Spieler>(); 
	/**
	 * @param Die Anzahl der Spieler dieses Spiels 
	 */
	private int anzahlSpieler;
	
//	public Rundenverwaltung derRundenverwalter;
//	
//	public Anfangsphase dieAnfangsphase;
	
	/**
	 * @param Der Gewinner des Spiels
	 */
	private Spieler sieger;
	
	private Map karte; 
	
	public Client client;
	
	/**
	 * Hier wird das Spiel initiert d.h. 
	 * Es wird vom Spielmacher (Spaeter dann vermutlich serverseitig) ausgewaehlt wieviele Spieler es gibt, diese werden dann benannt 
	 * danach wird fuer jeden Spieler ein Interface und eine Mission erstellt, zusaetzlich werden die Starteinheiten eingestellt
	 * Dann wird die Map geladen, 
	 * danach beginnt das Spiel mit der Anfangsphase . 
	 * @throws IOException 
	 */
	public void init() throws IOException {
//		mapEinstellen();  	// Kontinente laden, Laender laden etc 
		for (int i = 0; i<this.getAnzahlSpieler();i++) {
			System.out.println(this.spielerListe.get(i).getName());
		}
//		interfaceEinstellen();
		missionenEinstellen();
		spielerEinstellen();
	}
	
	/**
	 * Fuer jeden Spieler wird ein neues persoenliches Interface erstellt
	 * SpielerInterface --> siehe Klasse SpielerInterface
	 */
//	private void interfaceEinstellen() {
//		for (int i = 0; i < spielerListe.size(); i++) {
//			spielerListe.get(i).setPersoenlichesInterface(new SpielerInterface(spielerListe.get(i)));
//		}
//	}

	/**
	 * Hier wird die Anzahl der Spieler abgefragt und der User kann/muss
	 * Namen fuer die Spieler eingeben.
	 * Die Spieleranzahl kann nur 2, 3 oder 4 betragen. Gibt der User eine andere
	 * Anzahl ein, erscheint eine Fehlermeldung und es muss erneut eine Anzahl eingegeben werden.
	 * Am Ende wird jeder Spieler zur Spielerliste hinzugefuegt.
	 */
	public void spielerwahl(int spielerAnz) {
		anzahlSpieler = spielerAnz;
	}
	
	/**
	 * Bei einer Spieleranzahl von 2 oder 3 werden jedem Spieler 35 Schwerteinheiten
	 * seinem Einheitenpool hinzugefuegt.
	 * Bei einer Spieleranzahl von 4 werden jedem Spieler 30 Schwerteinheiten
	 * seinem Einheitenpool hinzugefuegt.
	 * @return Gibt true zurueck wenn die Einstellung der Spieler geklappt hat.
	 */
	public boolean spielerEinstellen() {
		//System.out.println(spielerListe.size());										// loeschen
		if (spielerListe.size() == 2 || spielerListe.size() == 3) {
			for (int i = 0; i < spielerListe.size(); i++) {
				for (int y = 0; y < 35; y++){
					spielerListe.get(i).addEinheitenPool(new Schwert());
				}
			}
			return true;
		} else if (spielerListe.size() == 4) {
			for (int i = 0; i < spielerListe.size(); i++) {
				for (int y = 0; y < 30; y++){
					spielerListe.get(i).addEinheitenPool(new Schwert());
				}
			}
			return true;
		} else {
			return false;
		}
	}
	
	
	/**
	 * Hier werden die Missionen an die Spieler verteilt.
	 * Bei Spieleranzahl = 2 bekommt jeder Spieler die MissionVierKontinente.
	 * Bei Spieleranzahl = 3 werden die Missionen MissionVierKontinente und
	 * MissionDreiEinheiten random verteilt.
	 * Bei Spieleranzahl = 4 werden die Missionen MissionVierKontinente,
	 * MissionDreiEinheiten und MissionSpielerToeten random verteilt.
	 * Konnten die Missionen nicht zugeteilt werden, wird eine Fehlermeldung
	 * ausgegeben.
	 * Am Ende werden die Missionen der Spieler ausgegeben.
	 */
	private void missionenEinstellen() {
		Random random = new Random();
		if (anzahlSpieler == 2) {
			for (int i = 0; i < 2; i++) {
				spielerListe.get(i).setMission(new MissionVierKontinente(spielerListe.get(i), karte.getKontinente()));
			}
		} else if (anzahlSpieler == 3) {
			for (int y = 0; y < 3; y++) {
				int rand = random.nextInt(2) + 1; // gibt eine Zahl zwischen 1 und 2 zurueck
				if (rand == 1) {
					spielerListe.get(y).setMission(new MissionVierKontinente(spielerListe.get(y), karte.getKontinente()));
				} else if (rand == 2) {
					spielerListe.get(y).setMission(new MissionDreiEinheiten(spielerListe.get(y)));
				}
			}
		} else if (anzahlSpieler == 4) {
			for (int x = 0; x < 4; x++) {
				int rand = random.nextInt(3) + 1; // gibt eine Zahl zwischen 1 und 3 zurueck
				System.out.println(rand);
				if (rand == 1) {
					spielerListe.get(x).setMission(new MissionVierKontinente(spielerListe.get(x), karte.getKontinente()));
				} else if (rand == 2) {
					spielerListe.get(x).setMission(new MissionDreiEinheiten(spielerListe.get(x)));
				} else if (rand == 3) {
					spielerListe.get(x).setMission(new MissionSpielerToeten(spielerListe.get(x), this.spielerListe));
				}
			}
		} else {
			System.out.println("Ein Fataler Fehler tritt bei der Missionseinstellung auf!");
		}
		for (int i = 0; i < anzahlSpieler; i++)
		System.out.println(spielerListe.get(i).getMission());
		
	}
	
	/**
	 * Ein neues Mapobjekt wird erstellt und die Laender und
	 * Kontinente geladen.
	 */
	public void mapEinstellen() throws IOException {
		karte = new Map();
		karte.ladeLaender();
		karte.ladeKontinente();
	}
	
	public Map getKarte() {
		return this.karte;
	}
	
	public ArrayList<Spieler> getSpielerListe() {
		return spielerListe;
	}
	
	public Spieler getSieger() {
		return sieger;
	}

	public void setSieger(Spieler sieger) {
		this.sieger = sieger;
	}
	
	public int getAnzahlSpieler() {
		return anzahlSpieler;
	}

	public void setAnzahlSpieler(int anzahlSpieler) {
		this.anzahlSpieler = anzahlSpieler;
	}
	
	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}
	
	public void clientFirstInput() throws ClassNotFoundException, IOException {
		client.firstInput();
	}

	//	 /*
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		StartPopup start = new StartPopup();
	}
//	 */
}
