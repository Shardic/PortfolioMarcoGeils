package danielolivermarco.gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import danielolivermarco.persistens.Map;
import danielolivermarco.datenhaltung.*;
import danielolivermarco.anwendungslogik.*;
import domain.Client;


public class StartGUI extends JFrame {

	/**
	 * @param Der Weiterbutton als JButton
	 */
	private JButton weiterButton;
	
	//private Spiel spiel;
	
	private int anzahlSpieler; 
	
	private Client client;
	
	/**
	 * @param spielerNr wird in der Methode spielerNamen verwendet.
	 */
	private int spielerNr = 1;
	

	public StartGUI(Client client) {
		super();
		this.client = client;
		this.setSize(400, 150);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}


	/**
	 * Das Fensterlayout wird gesetzt. Es werden ein JLabel und ein JPanel zum Fenster hinzugefuegt.
	 * Mit einer JCombobox kann die Spieleranzahl ausgewaehlt werden. Mit einem Klick auf den Weiterbutton wird
	 * sie bestaetigt, das Fenster schliesst sich und der naechste Spielschritt wird gestartet.
	 */
	public void waehleSpielerAnz() {
    	this.setLayout(new FlowLayout());
    	final JLabel welcome = new JLabel("Willkommen bei Herr der Ringe Risiko.");
    	this.add(welcome);
    	
    	final JPanel center = new JPanel();
    	center.setLayout(new FlowLayout());
    	center.add(new JLabel("Wie viele Spieler seid ihr?"));
    	
    	//Array mit der Auswahl der moeglichen Spieleranzahlen
    	String[] comboBoxListe = {"2", "3", "4"};
    	final JComboBox spielerAnzAuswahl = new JComboBox (comboBoxListe);
    	center.add(spielerAnzAuswahl);
    	this.add(center);
    	
    	weiterButton = new JButton("Weiter");
    	weiterButton.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent e) {
    			if (e.getSource().equals(weiterButton)) {
    				client.setAnzahlSpieler(2 + spielerAnzAuswahl.getSelectedIndex());//+2 da der Index der Combobox abgefragt wird (bei 0 ist 2, bei 1 ist 3..)
    				anzahlSpieler = 2 + spielerAnzAuswahl.getSelectedIndex();
    				setVisible(false);
    				dispose();
    				//spiel.spielerwahl(spiel.getAnzahlSpieler());
    				remove(center);
    				remove(spielerAnzAuswahl);
    				remove(weiterButton);
    				remove(welcome);
    				//spiel.spielerErzeugen(getSpielerNr());
    				try {
						client.firstInput();
					} catch (ClassNotFoundException e1) {
						e1.printStackTrace();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
    			}
    		}
    	});
    	this.add(weiterButton);
    	
    	this.setVisible(true);
    	this.setLocationRelativeTo(null);
    	//this.pack();
	}
	
	/**
	 * Fensterlayout wird gesetzt. Ein JLabel, ein JTextfield und ein JButton werden
	 * hinzugefuegt. Im Textfeld wird der Spielername des entsprechenden Spielers eingetragen.
	 * Bei Klick auf den JButton wird die Methode spielerAdd des Spielobjekts mit entsprechenden Parametern
	 * ausgefuehrt. Hat der letzte Spieler den Button betaetigt, wird das Fenster geschlossen. Es folgt der
	 * naechste Spielschritt.
	 * @param nr Die Spielernummer wird beim Ausfuehren der Methode uebergeben.
	 */
	public void spielerNamen(int nr) {
		this.setLayout(new FlowLayout());
		final JLabel label = new JLabel("Wie lautet der Name von Spieler " + nr + " ?");
		this.add(label);
		final JTextField textfield = new JTextField("Spieler "+nr);
		this.add(textfield);
		weiterButton = new JButton("Weiter");
		weiterButton.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent e) {
    			if (e.getSource().equals(weiterButton) && spielerNr < anzahlSpieler) {
    				final String name = textfield.getText();
    				System.out.println("Test");
    				//spiel.spielerAdd(name, nr);
    				try {
						client.setSpieler(name, spielerNr);
					} catch (ClassNotFoundException e1) {
						e1.printStackTrace();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
    				setVisible(false);
    				dispose();
    				spielerNr++;
    				remove(textfield);
    				remove(label);
    				remove(weiterButton);
    				//spiel.spielerErzeugen(spielerNr);
    				rekursion(spielerNr);
    			} else if (e.getSource().equals(weiterButton) && spielerNr == anzahlSpieler) {
    				final String name = textfield.getText();
    				//spiel.spielerAdd(name, nr);
    				try {
						client.setSpieler(name, spielerNr);
					} catch (ClassNotFoundException e1) {
						e1.printStackTrace();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
        			setVisible(false);
        			dispose();
    				remove(textfield);
       				remove(label);
       				remove(weiterButton);
       				try {
						client.firstInput();
					} catch (ClassNotFoundException e1) {
						e1.printStackTrace();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
//       				StartGUI.this.spielModus();
//       				try {
//						spiel.init();
//					} catch (IOException e1) {
//						e1.printStackTrace();
//					}
    			}
    		}

			private void rekursion(int spielerNr) {
				spielerNamen(spielerNr);
			}
    	});
		this.add(weiterButton);
		this.setVisible(true);
    	this.setLocationRelativeTo(null);
	}
	
	/**
	 * Hier muss der Spielmodus gewaehlt werden. Ueber eine JCombobox kann einer der
	 * drei Spielmodi gewaehlt und anschliessend mit dem JButton bestaetigt werden.
	 */
	public void spielModus() {
		this.setSize(600, 100);
		
		final JLabel label = new JLabel("Welchen Spielmodus moechtet ihr spielen?");
		this.add(label);
		String[] comboBoxListe = {"Laender zufaellig auswaehlen und Einheiten manuell verteilen.", "Laender und Einheiten zufaellig verteilen.", "Laender und Einheiten manuell verteilen."};
    	final JComboBox modusAuswahl = new JComboBox (comboBoxListe);
    	this.add(modusAuswahl);
    	weiterButton = new JButton("Weiter");
    	weiterButton.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent e) {
    			if (e.getSource().equals(weiterButton)) {
    				setVisible(false);
        			dispose();
        			remove(label);
       				remove(weiterButton);
       				client.setModusInt(modusAuswahl.getSelectedIndex());
    				//spiel.getDieAnfangsphase().initGUI(modusAuswahl.getSelectedIndex());
    			}
    		}
    	});
    	
		this.add(weiterButton);
		this.setVisible(true);
    	this.setLocationRelativeTo(null);
	}
	
	
	public int getSpielerNr() {
		return spielerNr;
	}


	public void setSpielerNr(int spielerNr) {
		this.spielerNr = spielerNr;
	}
}
