package danielolivermarco.gui;


import danielolivermarco.datenhaltung.*;



public class AnfangsphaseGui {
	
	
	public void laenderAuswahl(Land l, Spieler s) {
		s.addBesitzLaender(l);
	}
}
