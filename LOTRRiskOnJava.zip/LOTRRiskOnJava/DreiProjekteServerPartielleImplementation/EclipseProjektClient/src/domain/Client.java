package domain;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;

import danielolivermarco.gui.StartGUI;
import value.*;

@SuppressWarnings("serial")
public class Client implements Serializable {
	private Socket socket;
	private ObjectInputStream sInput; // to read from the socket
	private ObjectOutputStream sOutput; // to write on the socket
	private StartGUI start;
	
	public Client(String ip, int port) {
		connect(ip, port);
	}
	
	public void connect(String ip, int port) {
		try {
			this.socket = new Socket(ip, port);
			this.sInput = new ObjectInputStream(this.socket.getInputStream());
			this.sOutput = new ObjectOutputStream(this.socket.getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.err.println("Socket Verbindung");
	}

	public void firstInput() throws ClassNotFoundException, IOException {
		this.firstAction((StartAction) this.sInput.readObject());
	}

	private void firstAction(StartAction o) throws ClassNotFoundException, IOException {
		if (o.isAnzahlWaehlen() == true) {
			start = new StartGUI(this);
			start.waehleSpielerAnz();
		} else if (o.isWarten() == true) {
			nichtMehrWarten((AnfangsPhaseAction) this.sInput.readObject() );
		} else if (o.isSpielerErstellen() == true) {
			int sNr = o.getSpielerErstellenNr();
			start.spielerNamen(sNr);
		} else if (o.isModiAuswahl() == true) {
			start.spielModus();
		}
		//this.firstAction((StartAction) this.sInput.readObject());
	}
	
	private void nichtMehrWarten(AnfangsPhaseAction anfang) {
		
	}

	public void setAnzahlSpieler(int spielerAnzahl) {
		StartActionAnt actionAnt = new StartActionAnt();
		actionAnt.setAnzahlSpieler(spielerAnzahl);
		actionAnt.setSpielerNr(spielerAnzahl);
		try {
			this.sOutput.writeObject(actionAnt);
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			this.sOutput.reset();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void setSpieler(String name, int nr) throws ClassNotFoundException, IOException {
		//this.sOutput.reset();
		StartActionAnt actionAnt = new StartActionAnt();
		actionAnt.setName(name);
		actionAnt.setSpielerNr(nr);
		try {
			this.sOutput.writeObject(actionAnt);
		} catch (IOException e) {
			e.printStackTrace();
		}
		//this.firstAction((StartAction) this.sInput.readObject());
	}
	
	public void setModusInt(int a) {
		StartActionAnt actionAnt = new StartActionAnt();
		actionAnt.setModus(a);
		try {
			this.sOutput.writeObject(actionAnt);
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
}
