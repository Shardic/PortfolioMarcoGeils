package value;

import java.io.Serializable;

public class StartAction implements Serializable {

	private boolean anzahlWaehlen = false;
	private boolean warten = false;
	private boolean wartenEnde = false;
	private boolean spielerErstellen = false;
	private int spielerErstellenNr;
	private boolean modiAuswahl = false;
	
	public boolean isAnzahlWaehlen() {
		return anzahlWaehlen;
	}
	public void setAnzahlWaehlen(boolean anzahlWaehlen) {
		this.anzahlWaehlen = anzahlWaehlen;
	}
	public boolean isWarten() {
		return warten;
	}
	public void setWarten(boolean warten) {
		this.warten = warten;
	}
	public boolean isSpielerErstellen() {
		return spielerErstellen;
	}
	public void setSpielerErstellen(boolean spielerErstellen) {
		this.spielerErstellen = spielerErstellen;
	}
	public boolean isModiAuswahl() {
		return modiAuswahl;
	}
	public void setModiAuswahl(boolean modiAuswahl) {
		this.modiAuswahl = modiAuswahl;
	}
	public void setSpielerErstellenNr(int a) {
		spielerErstellenNr = a;
	}
	public int getSpielerErstellenNr() {
		return spielerErstellenNr;
	}
	public void setWartenEnde(boolean wartenEnde) {
		this.wartenEnde = wartenEnde;
	}
	public boolean isWartenEnde() {
		return wartenEnde;
	}
	
	
	
	
}
