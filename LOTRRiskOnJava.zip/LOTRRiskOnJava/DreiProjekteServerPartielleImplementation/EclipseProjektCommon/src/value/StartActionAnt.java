package value;

import java.io.Serializable;

public class StartActionAnt implements Serializable {

	private int anzahlSpieler = 0;
	private String name = null;
	private int spielerNr = 0;
	private int modus;
	
	public int getAnzahlSpieler() {
		return anzahlSpieler;
	}
	public void setAnzahlSpieler(int anzahlSpieler) {
		this.anzahlSpieler = anzahlSpieler;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSpielerNr() {
		return spielerNr;
	}
	public void setSpielerNr(int spielerNr) {
		this.spielerNr = spielerNr;
	}
	public int getModus() {
		return modus;
	}
	public void setModus(int modus) {
		this.modus = modus;
	}
}
