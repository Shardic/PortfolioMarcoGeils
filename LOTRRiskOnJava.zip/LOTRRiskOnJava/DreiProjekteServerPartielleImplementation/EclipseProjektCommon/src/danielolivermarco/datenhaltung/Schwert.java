package danielolivermarco.datenhaltung;
/**
 * Infranterie guenstigster Einheitentyp
 * Darf im Zweikampf nur einmal Wuerfeln
 * 
 * @author Daniel
 *
 */

public class Schwert extends Einheit {


	public Schwert() {
		super(100, 1);
	}
}
