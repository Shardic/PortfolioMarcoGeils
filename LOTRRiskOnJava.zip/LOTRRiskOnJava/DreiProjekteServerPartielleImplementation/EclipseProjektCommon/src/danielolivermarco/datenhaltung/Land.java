package danielolivermarco.datenhaltung;

import java.awt.Color;
import java.io.Serializable;

/**
 * 
 * Die Klasse der einzelnen Laender.
 * @author oliverbammann
 *
 */
public class Land implements Serializable{
	
	/**
	 * @param Der Name des Landes.
	 */
	private String name;
	
	/**
	 * @param Der Besitzer des Landes.
	 */
	private Spieler owner;
	
	/**
	 * @param Die Armee, die sich in dem Land befindet.
	 */
	private Armee spielerArmee;
	
	/**
	 * @param Die Nummer des Landes (jedes Land erhaelt eine Nummer).
	 */
	private int nummer;
	
	/**
	 * @param Ein Objektarray vom Typ Land fuer alle Nachbar Laender eines Landes.
	 */
	private Land[] nachbarn;
	
	private Color color;

	/**
	 * Konstruktor fuer die Klasse Land.
	 * @param n Hier wird der Name als String uebergeben.
	 * @param nr Hier wird die Nummer des Landes als Integer uebergeben.
	 */
	public Land(String n, int nr, int nachbarAnzahl, Color c) {
		name = n;
		setNummer(nr);
		nachbarn = new Land[nachbarAnzahl];
		color = c;
	}
	
	public Color getColor() {
		return color;
	}

	public Spieler getOwner() {
		return owner;
	}
	
	public void setOwner(Spieler s) {
		owner = s;
	}

	public int getNummer() {
		return nummer;
	}

	public void setNummer(int nummer) {
		this.nummer = nummer;
	}

	public String getName() {
		return name;
	}
	
	public Land[] getNachbarn() {
		return nachbarn;
	}

	public void setNachbarn(Land[] nachbarn) {
		this.nachbarn = nachbarn;
	}

	public Armee getSpielerArmee() {
		return spielerArmee;
	}
	
	public void setSpielerArmee(Armee a) {
		spielerArmee = a;
	}
}