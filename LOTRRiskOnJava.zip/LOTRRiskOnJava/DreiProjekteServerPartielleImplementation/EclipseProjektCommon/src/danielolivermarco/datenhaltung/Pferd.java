package danielolivermarco.datenhaltung;

/**
 * Kavallerie, der teuerste Einheitentyp
 * Darf im Zweikampf vier mal Wuerfeln
 * 
 * @author Marco
 *
 */
public class Pferd extends Einheit {

	public Pferd() {
		super(400, 4);
	}
}
