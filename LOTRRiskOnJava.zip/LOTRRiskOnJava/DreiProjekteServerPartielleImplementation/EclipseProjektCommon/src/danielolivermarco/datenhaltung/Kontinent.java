package danielolivermarco.datenhaltung;

import java.io.Serializable;

/**
 * Die Klasse der Kontinente,enthalten bestimmte Laender.
 * @author oliverbammann
 *
 */
public class Kontinent implements Serializable{
	private String name;
	private Spieler owner;
	private Land[] laender;
	

	public Kontinent(String n, int laenderAnzahl) {
		this.setName(n);
		this.laender = new Land[laenderAnzahl];
	}
	
	public boolean setOwner() {
		this.owner = laender[0].getOwner();
		for (Land l:laender) {
			if (l.getOwner()!=owner) {
				this.owner = null;
				return false;
			}
		}
		return true;
		//Variable owner setzen, wenn ein Spieler alle Laender eines Kontinents besitzt
	}
	
	public Spieler getOwner(){
		return owner;
	}
	
	public Land[] getLaender() {
		return laender;
	}

	public void setLaender(Land[] laender) {
		this.laender = laender;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}