package danielolivermarco.datenhaltung;

/**
 * Mittelteurer Einheitentyp
 * Darf im Zweikampf zwei mal Wuerfeln
 * 
 * @author Marco
 *
 */
public class Bogen extends Einheit {
	public Bogen() {
		super(200, 2);
	}
}
