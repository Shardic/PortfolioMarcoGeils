package danielolivermarco.datenhaltung;

import java.io.Serializable;
import java.util.ArrayList;

import danielolivermarco.anwendungslogik.*;
//import danielolivermarco.cui.*;
//import danielolivermarco.gui.*;
//import danielolivermarco.network.ServerClient;
//import domain.Client;

public class Spieler implements Serializable{

	/**
	 * @param So heisst der Spieler
	 */
	private String name;
	/**
	 * Die Spielinterne Nummer des Spielers
	 */
	private int spielerNr;
	//private Spiel seinSpiel;
	//private ServerClient client;
	private Mission mission;
	private Kontinent[] zuErobern;
	private Spieler toetungsziel;
	private int geld;
	private ArrayList<Einheit> einheitenPool = new ArrayList<Einheit>();
	private ArrayList<Kontinent> besitzKontinente = new ArrayList<Kontinent>();
	private ArrayList<Land> besitzLaender = new ArrayList<Land>();
//	private SpielerInterface persoenlichesInterface;
//	private SpielerInterfaceGUI persoenlichesInterfaceGUI;
//	private KartenGui karte;
	
	public Spieler(String n, int nr){
		name = n;
		setSpielerNr(nr);
//		setSeinSpiel(s);
		geld = 0;
//		setPersoenlichesInterfaceGUI(new SpielerInterfaceGUI(this));  //neues GUI Spielerinterface fuer jeden Spieler
	}
	
//	public Spieler(String n, int nr, ServerClient client){
//		this.setClient(client);
//		name = n;
//		setSpielerNr(nr);
////		setSeinSpiel(s);
//		geld = 0;
////		setPersoenlichesInterfaceGUI(new SpielerInterfaceGUI(this));  //neues GUI Spielerinterface fuer jeden Spieler
//	}
	
	public String getName() {
		return name;
	}

	public ArrayList<Einheit> getEinheitenPool() {
		return this.einheitenPool;
	}

	public void addEinheitenPool(Einheit e) {
		this.einheitenPool.add(e);
	}
	
	public void remEinheitenPool(Einheit e) {
		if (this.einheitenPool.contains(e)) {
			this.einheitenPool.remove(e);
		} else {
			System.out.println("Ein fataler Fehler trat bei dem Entfernen aus dem Einheitenpool auf");
		}
		
	}

	public int getGeld() {
		return geld;
	}

	public void addGeld(int plus) {
		this.geld += plus;
	}
	
	public void remGeld(int minus) {
		this.geld -= minus;
	}

	public int getSpielerNr() {
		return spielerNr;
	}

	public void setSpielerNr(int spielerNr) {
		this.spielerNr = spielerNr;
	}

	public Mission getMission() {
		return mission;
	}

	public void setMission(Mission m) {
		this.mission = m;
	}

//	public Spiel getSeinSpiel() {
//		return seinSpiel;
//	}
//
//	public void setSeinSpiel(Spiel seinSpiel) {
//		this.seinSpiel = seinSpiel;
//	}

	public ArrayList<Kontinent> getBesitzKontinente() {
		return besitzKontinente;
	}

	public void addBesitzKontinente(ArrayList<Kontinent> besitzKontinente) {
		this.besitzKontinente = besitzKontinente;
	}

	public ArrayList<Land> getBesitzLaender() {
		return besitzLaender;
	}

	public void addBesitzLaender(Land l) {
		this.besitzLaender.add(l);
	}
	
	public void remBesitzLaender(Land rl) {
		this.besitzLaender.remove(rl);
	}

//	public SpielerInterface getPersoenlichesInterface() {
//		return persoenlichesInterface;
//	}
//
//	public void setPersoenlichesInterface(SpielerInterface pi) {
//		this.persoenlichesInterface = pi;
//	}

//	public ServerClient getClient() {
//		return client;
//	}
//
//	public void setClient(ServerClient client) {
//		this.client = client;
//	}

	public boolean amLeben() {
		if (besitzLaender.size() == 0 ) {
			return false;
		} else {
			return true; 
		}
	}

	public Spieler getToetungsziel() {
		return toetungsziel;
	}

	public void setToetungsziel(Spieler toetungsziel) {
		this.toetungsziel = toetungsziel;
	}

	public Kontinent[] getZuErobern() {
		return zuErobern;
	}

	public void setZuErobern(Kontinent[] zuErobern) {
		this.zuErobern = zuErobern;
	}
	
//	public void start() {
//		karte = new KartenGui(seinSpiel.getKarte(), this); //Karte laden
//		persoenlichesInterfaceGUI.welcomeAnzeige();	
//	}

//	public SpielerInterfaceGUI getPersoenlichesInterfaceGUI() {
//		return persoenlichesInterfaceGUI;
//	}

//	public void setPersoenlichesInterfaceGUI(
//			SpielerInterfaceGUI persoenlichesInterfaceGUI) {
//		this.persoenlichesInterfaceGUI = persoenlichesInterfaceGUI;
//	}
}
