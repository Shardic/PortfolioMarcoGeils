package danielolivermarco.anwendungslogik;

import danielolivermarco.datenhaltung.*;

public class ArmeeAufloeser {
	
	public ArmeeAufloeser() {
	}
	/**
	 * Nimmt eine Armee und ein Land entgegen um dei Armee in die im Land stationierte Armee einzugliedern
	 * 
	 * @param a Erwartet eine Armee die in das Land einfliessen soll
	 * @param l	In dieses Land fliesst die Armee ein
	 */
	public void init(Armee a, Land l) {
		for (int i = 0; i < a.getArmee().size(); i++) {
			l.getSpielerArmee().armeeZuwachs(a.getArmee().get(i));
		}
	}
}
