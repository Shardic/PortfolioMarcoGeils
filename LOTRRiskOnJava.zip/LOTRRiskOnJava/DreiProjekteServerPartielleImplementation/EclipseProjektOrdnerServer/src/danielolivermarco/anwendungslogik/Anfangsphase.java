package danielolivermarco.anwendungslogik;

import java.util.Random;


//import danielolivermarco.cui.IO;
import danielolivermarco.datenhaltung.*;

public class Anfangsphase {
	
	private Spiel dasSpiel;
	Random rand = new Random();
	
	public Anfangsphase(Spiel s) {
		dasSpiel = s;
	}
	
	public void initGUI(int modusNr) {
		for (int i = 0; i < dasSpiel.getSpielerListe().size(); i++) {
		//	dasSpiel.getSpielerListe().get(i).getPersoenlichesInterface().halloAnz();
		}
		switch (modusNr) {
			case 0:		//laenderAutoVerteilen();
		//				restlicheVerteilen();
	//					dasSpiel.starteSpiel();
						break;
			case 1:		laenderAutoVerteilen();
						restlicheAutoVerteilen();
		//				dasSpiel.starteSpiel();
						break;
			case 2:		//laenderAuswahl();
		//				restlicheVerteilen();
		//				dasSpiel.starteSpiel();
					break;
		}
	}
	
//	public void initCUI() {
//		for (int i = 0; i < dasSpiel.getSpielerListe().size(); i++) {
//			dasSpiel.getSpielerListe().get(i).getPersoenlichesInterface().halloAnz();
//			System.out.println("hallo");
//		}
//		int modusNr = IO.readInt();
//		switch (modusNr) {
//		case 0:		laenderAutoVerteilen();
//					restlicheVerteilen();
//					break;
//		case 1:		laenderAutoVerteilen();
//					restlicheAutoVerteilen();
//					break;
//		case 2:		laenderAuswahl();
//					restlicheVerteilen();
//					break;
//		}
//	}

	private void restlicheAutoVerteilen() {
		while (dasSpiel.getSpielerListe().get(dasSpiel.getSpielerListe().size()-1).getEinheitenPool().isEmpty() != true) {
			for (int y = 0; y < dasSpiel.getSpielerListe().size(); y++) {
				Spieler spieler = dasSpiel.getSpielerListe().get(y);
				if (spieler.getEinheitenPool().isEmpty() != true) {
					int index = rand.nextInt(spieler.getBesitzLaender().size());
					int landId = spieler.getBesitzLaender().get(index).getNummer();
					Einheit insLand = spieler.getEinheitenPool().get(spieler.getEinheitenPool().size() - 1);
					dasSpiel.getKarte().getLaender().get(landId - 1).getSpielerArmee().armeeZuwachs(insLand);
					spieler.remEinheitenPool(insLand);
				}
			}
		}		
	}

	private void laenderAutoVerteilen() {
		boolean verteilt = false;
		int landId = 0;
		for (int i = 0; i < 42; i += dasSpiel.getSpielerListe().size()) {
			for (int y = 0; y < dasSpiel.getSpielerListe().size(); y++)	 {
				Land land = null;
				while (!verteilt) {
					landId = rand.nextInt(42); 
					land = dasSpiel.getKarte().getLaender().get(landId);
					if (land.getOwner() == null) {
						verteilt = true;
					}
				}	
				landZuteilen(landId, y);
				verteilt = false;
			}
		}
		
	}

//	private void laenderAuswahl() {
//		if(dasSpiel.getSpielerListe().size() == 2) {
//			//Wird bei einer Spieleranzahl von 2 ausgefuehrt
//			for (int i = 0; i < 42/2; i++) {
//				for (int y = 0; y < dasSpiel.getSpielerListe().size(); y++) {
//					boolean funkt = false;
//					do {
//						Spieler spieler = dasSpiel.getSpielerListe().get(y);
//			//			int landId = spieler.getPersoenlichesInterface().landAuswahlStart() - 1;
//						Land land = dasSpiel.getKarte().getLaender().get(landId);
//						if (land.getOwner() == null) {
//							landZuteilen(landId, y);
//							funkt = true;
//						} else {
//			//				spieler.getPersoenlichesInterface().landAuswahlFehler();
//						}						
//						
//					} while (funkt == false);
//				}
//			}
//		} else if (dasSpiel.getSpielerListe().size() == 3) {
//			//Wird bei einer Spieleranzahl von 3 ausgefuehrt
//			for (int i = 0; i < 42/3; i++) {
//				for (int y = 0; y < dasSpiel.getSpielerListe().size(); y++) {
//					boolean funkt = false;
//					do {
//						Spieler spieler = dasSpiel.getSpielerListe().get(y);
//	//					int landId = spieler.getPersoenlichesInterface().landAuswahlStart() - 1;
//						Land land = dasSpiel.getKarte().getLaender().get(landId);
//						if (land.getOwner() == null) {
//							landZuteilen(landId, y);
//							funkt = true;
//						} else {
////							spieler.getPersoenlichesInterface().landAuswahlFehler();
//						}						
//						
//					} while (funkt == false);
//				}
//			}
//		} else if (dasSpiel.getSpielerListe().size() == 4) {
//			//Wird bei einer Spieleranzahl von 4 ausgefuehrt
//			for (int i = 0; i < 10; i++) {
//				for (int y = 0; y < dasSpiel.getSpielerListe().size(); y++) {
//					boolean funkt = false;
//					do {
//						Spieler spieler = dasSpiel.getSpielerListe().get(y);
//	//					int landId = spieler.getPersoenlichesInterface().landAuswahlStart() - 1;
//						Land land = dasSpiel.getKarte().getLaender().get(landId);
//						if (land.getOwner() == null) {
//							landZuteilen(landId, y);
//							funkt = true;
//						} else {
//	//						spieler.getPersoenlichesInterface().landAuswahlFehler();
//						}						
//						
//					} while (funkt == false);
//				}
//			}
//			for (int y = 0; y < 2; y++) {
//				boolean funkt = false;
//				do {
//					Spieler spieler = dasSpiel.getSpielerListe().get(y);
//	//				int landId = spieler.getPersoenlichesInterface().landAuswahlStart() - 1;
//					Land land = dasSpiel.getKarte().getLaender().get(landId);
//					if (land.getOwner() == null) {
//						landZuteilen(landId, y);
//						funkt = true;
//					} else {
//			//			spieler.getPersoenlichesInterface().landAuswahlFehler();
//					}						
//					
//				} while (funkt == false);
//			}
//		}
//	}	
//	
//	private void restlicheVerteilen() {
//		while (dasSpiel.getSpielerListe().get(dasSpiel.getSpielerListe().size()-1).getEinheitenPool().isEmpty() != true) {
//			for (int y = 0; y < dasSpiel.getSpielerListe().size(); y++) {
//				Spieler spieler = dasSpiel.getSpielerListe().get(y);
//				if (spieler.getEinheitenPool().isEmpty() != true) {
//					int landId = spieler.getPersoenlichesInterface().einheitenVeteilen();
//					Einheit insLand = spieler.getEinheitenPool().get(spieler.getEinheitenPool().size() - 1);
//					dasSpiel.getKarte().getLaender().get(landId - 1).getSpielerArmee().armeeZuwachs(insLand);
//					spieler.remEinheitenPool(insLand);
//				}
//			}
//		}
//	}
	
	public void landZuteilen(int lId, int x) {
		int landId = lId;
		int y = x; 
		dasSpiel.getKarte().getLaender().get(landId).setOwner(dasSpiel.getSpielerListe().get(y));
		dasSpiel.getKarte().getLaender().get(landId).setSpielerArmee(new Armee(this.dasSpiel.getSpielerListe().get(y)));
		dasSpiel.getSpielerListe().get(y).addBesitzLaender(dasSpiel.getKarte().getLaender().get(landId));
		Einheit insLand = dasSpiel.getSpielerListe().get(y).getEinheitenPool().get(dasSpiel.getSpielerListe().get(y).getEinheitenPool().size() -1);
		dasSpiel.getKarte().getLaender().get(landId).getSpielerArmee().armeeZuwachs(insLand);
		dasSpiel.getSpielerListe().get(y).remEinheitenPool(insLand);	
	}
}
