package danielolivermarco.anwendungslogik;



import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import danielolivermarco.datenhaltung.*;
//import danielolivermarco.cui.*;
import danielolivermarco.network.ServerClient;
import danielolivermarco.persistens.*;
//import danielolivermarco.gui.*;


/**
 * Hauptklasse des Spiels, in dieser wird sich ie Main befinden
 * 
 * @author Marco
 *
 */
public class Spiel {
	/**
	 * @param Die liste der Spieler dieses Spiels 
	 */
	private ArrayList<Spieler> spielerListe = new ArrayList<Spieler>(); 
	/**
	 * @param Die Anzahl der Spieler dieses Spiels 
	 */
	private int anzahlSpieler;
	/**
	 * @param Der Gewinner des Spiels
	 */
	private Spieler sieger;
	
	private Map karte;
	
	//public StartGUI start = new StartGUI(this);
	
	public Anfangsphase dieAnfangsphase;
	
	public Rundenverwaltung derRundenverwalter;
	
	//private AnfangsphaseGui AnfangsGui; 
	
	
	public Spiel() {
		setDieAnfangsphase(new Anfangsphase(this));
		setDerRundenverwalter(new Rundenverwaltung(this));
	}


	/**
	 * Hier wird das Spiel initiert d.h. 
	 * Es wird vom Spielmacher (Spaeter dann vermutlich serverseitig) ausgewaehlt wieviele Spieler es gibt, diese werden dann benannt 
	 * danach wird fuer jeden Spieler ein Interface und eine Mission erstellt, zusaetzlich werden die Starteinheiten eingestellt
	 * Dann wird die Map geladen, 
	 * danach beginnt das Spiel mit der Anfangsphase . 
	 * @throws IOException 
	 */
//	public void init() throws IOException {
//		for (int i = 0; i<this.getAnzahlSpieler();i++) {
//		System.out.println(this.spielerListe.get(i).getName()); //Spielernamen zum Testen ausgeben
//	}
//		interfaceEinstellen();
//		spielerEinstellen();
//		missionenEinstellen();
//	}

//	private void interfaceEinstellen() {
//		for (int i = 0; i < spielerListe.size(); i++) {
//			spielerListe.get(i).setPersoenlichesInterface(new SpielerInterface(spielerListe.get(i)));
//		}
//	}

//	public void spielerwahlCUI() {
//		boolean richtigeAnzahl = false;
//		StartInterface s1 = new StartInterface(); 
//		do {
//			s1.spielerzahlAuswaehlen();
//			anzahlSpieler = IO.readInt();
//			if (anzahlSpieler <= 1 || anzahlSpieler > 4) {
//				s1.invalideZahl();
//			} else {
//				richtigeAnzahl = true; 
//			}
//		} while (richtigeAnzahl == false);
//		for (int i = 1; i < anzahlSpieler + 1; i++) {
//			s1.spielerNameAuswaehlen(i);
//			String name = IO.readString();
//			spielerListe.add(new Spieler(name, i, this));
//		}
//	}
	
	public void spielerwahl(int spielerAnz) {
		anzahlSpieler = spielerAnz;
	}
	
//	public void spielerErzeugen(int spielerNr) {
//		start.spielerNamen(spielerNr);
//	}
//	
	public void spielerAdd(String name, int nr) {
		spielerListe.add(new Spieler(name, nr));
	}
	
	public Anfangsphase getDieAnfangsphase() {
		return dieAnfangsphase;
	}

	public void setDieAnfangsphase(Anfangsphase dieAnfangsphase) {
		this.dieAnfangsphase = dieAnfangsphase;
	}

//	public void setAnfangsphaseGui(AnfangsphaseGui anfangsGui) {
//		AnfangsGui = anfangsGui;
//	}
	
//	public AnfangsphaseGui getAnfangsphaseGui() {
//		return AnfangsGui;
//	}
//	
	public Rundenverwaltung getDerRundenverwalter() {
		return derRundenverwalter;
	}


	public void setDerRundenverwalter(Rundenverwaltung derRundenverwalter) {
		this.derRundenverwalter = derRundenverwalter;
	}


	/**
	 * 
	 * @return Gibt true zurueck wenn die Einstellung der Spieler geklappt hat.
	 */
	public boolean spielerEinstellen() {										
		if (spielerListe.size() == 2 || spielerListe.size() == 3) {
			for (int i = 0; i < spielerListe.size(); i++) {
				for (int y = 0; y < 35; y++){
					spielerListe.get(i).addEinheitenPool(new Schwert());
				}
			}
			return true;
		} else if (spielerListe.size() == 4) {
			for (int i = 0; i < spielerListe.size(); i++) {
				for (int y = 0; y < 30; y++){
					spielerListe.get(i).addEinheitenPool(new Schwert());
				}
			}
			return true;
		} else {
			return false;
		}
	}
	
	public void missionenEinstellen() {
		Random random = new Random();
		if (anzahlSpieler == 2) {
			for (int i = 0; i < 2; i++) {
				spielerListe.get(i).setMission(new MissionVierKontinente(spielerListe.get(i), karte.getKontinente()));
			}
		} else if (anzahlSpieler == 3) {
			for (int y = 0; y < 3; y++) {
				int rand = random.nextInt(2) + 1; // gibt eine Zahl zwischen 1 und 2 zurueck
				if (rand == 1) {
					spielerListe.get(y).setMission(new MissionVierKontinente(spielerListe.get(y), karte.getKontinente()));
				} else if (rand == 2) {
					spielerListe.get(y).setMission(new MissionDreiEinheiten(spielerListe.get(y)));
				}
			}
		} else if (anzahlSpieler == 4) {
			for (int x = 0; x < 4; x++) {
				int rand = random.nextInt(3) + 1; // gibt eine Zahl zwischen 1 und 3 zurueck
				System.out.println(rand);
				if (rand == 1) {
					spielerListe.get(x).setMission(new MissionVierKontinente(spielerListe.get(x), karte.getKontinente()));
				} else if (rand == 2) {
					spielerListe.get(x).setMission(new MissionDreiEinheiten(spielerListe.get(x)));
				} else if (rand == 3) {
					spielerListe.get(x).setMission(new MissionSpielerToeten(spielerListe.get(x), this.spielerListe));
				}
			}
		} else {
			System.out.println("Ein Fataler Fehler tritt bei der Missionseinstellung auf!");
		}
		for (int i = 0; i < anzahlSpieler; i++)
		System.out.println(spielerListe.get(i).getMission());
		
	}
	
	public void mapEinstellen() throws IOException {
		karte = new Map();
		karte.ladeLaender();
		karte.ladeKontinente();
	}
	
	public Map getKarte() {
		return this.karte;
	}
	
	public ArrayList<Spieler> getSpielerListe() {
		return this.spielerListe;
	}
	
	public Spieler getSieger() {
		return sieger;
	}

	public void setSieger(Spieler sieger) {
		this.sieger = sieger;
	}
//	
//	public void einfuegen(StartGUI startGui) {
//		this.start = startGui;
//		
//	}
	
//	public void starteSpiel() {
//		for (int i = 0; i<this.getAnzahlSpieler();i++) {
//			this.spielerListe.get(i).start();
//		}
//	}

	public void setAnzahlSpieler(int a) {
		anzahlSpieler = a;
	}
	
	public int getAnzahlSpieler() {
		return anzahlSpieler;
	}


}
