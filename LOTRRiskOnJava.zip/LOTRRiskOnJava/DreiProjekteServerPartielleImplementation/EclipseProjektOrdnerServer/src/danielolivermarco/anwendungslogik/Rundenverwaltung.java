package danielolivermarco.anwendungslogik;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import danielolivermarco.datenhaltung.*;
//import danielolivermarco.cui.*;

public class Rundenverwaltung implements Serializable{
	                          
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Spiel dasSpiel;
	
//	private BuyAndSet goldUndKaufen; 
//	private AngriffsModus attacke;			// armee aus bestimmten Land zusammenstellen und die nachbarn damit angreifen 
//	private VerschiebenModus verschieben;	// armee aus bestimmten Land zusammenstellen und ins Nachbarland verschieben
	private PruefenModus pruefen;			// hier muss geprueft werden ob ein Spieler ausgeloescht wurde, und dieser muss dann aus dem Spiel entfernt werden
											// zusaetzlich ob nur ein Spieler noch uebrig ist und ob jemand seine Mission erfuellt hat.
	boolean jemandGewinnt = false;
	
	public Rundenverwaltung(Spiel s) {
		dasSpiel = s;
	}

	public void init() {
//		goldUndKaufen = new BuyAndSet(dasSpiel); 		// 
//		attacke = new AngriffsModus(dasSpiel);
//		verschieben = new VerschiebenModus(dasSpiel);
//		pruefen = new PruefenModus(dasSpiel);
//		runde();
	}
	
	public void runde(){
		int i = 0;
		do {			
			if (i == dasSpiel.getSpielerListe().size()) {
				//Nachdem der Spieler einmal dran war, fragen, ob gespeichert werden soll
//				spielSpeichern();
				i = 0;
			}
//			goldUndKaufen.init(dasSpiel.getSpielerListe().get(i));
//			attacke.init(dasSpiel.getSpielerListe().get(i));
//			verschieben.init(dasSpiel.getSpielerListe().get(i));
//			jemandGewinnt = pruefen.init(dasSpiel.getSpielerListe().get(i));
//			if(jemandGewinnt == false) {
//				i++;
//			}
		} while (jemandGewinnt == false);
	//	Endbildschirm ende = new Endbildschirm(dasSpiel);
	//	ende.ende();
	}
	
//	public void spielSpeichern(){
//		// fragen ob gespeichert werden soll, wenn nein raus
////		LadenSpeichernInterface ladenspeichern = new LadenSpeichernInterface();
//		if( ladenspeichern.willSpeichern() ){
//			// alle f�r den Spielstand wichtigen Attribute serialisieren ( Spiel, AngriffsModus, BuyAndSet, VerschiebenModus, PruefenmModus )
//			// und in Datei speichern
//			try (final ObjectOutputStream oop = new ObjectOutputStream(new FileOutputStream("spielstand.ser"))){
//				try{
//					//Rundenverwaltung speichert sich selber
//					oop.writeObject(this);
//				}catch (NotSerializableException e){
//					System.err.println("nicht serializierbar");
//				}
//			}catch (IOException e){
//				System.err.println("Error");
//			}
//			// dann evtl fragen ob weitergespielt werden soll
//		}
//	}

	public void initCUI() {
//		goldUndKaufen = new BuyAndSet(dasSpiel); 		// 
//		attacke = new AngriffsModus(dasSpiel);
//		verschieben = new VerschiebenModus(dasSpiel);
		pruefen = new PruefenModus(dasSpiel);
		runde();
	}
}