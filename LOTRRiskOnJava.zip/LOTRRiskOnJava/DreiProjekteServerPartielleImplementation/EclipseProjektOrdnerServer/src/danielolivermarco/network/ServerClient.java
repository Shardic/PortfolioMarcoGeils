package danielolivermarco.network;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;

import value.StartAction;
import value.StartActionAnt;


public class ServerClient implements Serializable {
	private ObjectInputStream sInput; // to read from the socket
	private ObjectOutputStream sOutput; // to write on the socket
	private Socket socket;
	private ServerStart server;
	private int nummer;
	
	public ServerClient(int nr, Socket s, ServerStart serv) {
		this.server = serv;
		this.socket = s;
		this.nummer = nr;

		try {
			this.sOutput = new ObjectOutputStream(this.socket.getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			this.sInput = new ObjectInputStream(this.socket.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void pushFirstActionAnzahl() {
		StartAction firstAction = new StartAction();
		firstAction.setAnzahlWaehlen(true);
		try {
			this.sOutput.writeObject(firstAction);
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			this.sOutput.reset();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		try {
			getFirstActionAnt((StartActionAnt) this.sInput.readObject());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void getFirstActionAnt(StartActionAnt actionAnt) throws ClassNotFoundException, IOException  {
		if (actionAnt.getAnzahlSpieler() > 0) {
			server.getDasSpiel().setAnzahlSpieler(actionAnt.getAnzahlSpieler());
			try {
				server.connectRestlicheSpieler();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if(actionAnt.getName() != null) {
			server.getDasSpiel().spielerAdd(actionAnt.getName(), actionAnt.getSpielerNr());
			if (server.getDasSpiel().getSpielerListe().size() < server.getDasSpiel().getAnzahlSpieler()) {
				this.getFirstActionAnt((StartActionAnt) this.sInput.readObject());	
			}
		}
	}
	
	public void pushFirstActionSpieler() throws IOException, ClassNotFoundException {
		StartAction firstAction = new StartAction();
		firstAction.setSpielerErstellen(true);
		int nr = server.getDasSpiel().getSpielerListe().size() + 1;
		firstAction.setSpielerErstellenNr(nr);
		try {
			this.sOutput.writeObject(firstAction);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.sOutput.reset();
		this.getFirstActionAnt((StartActionAnt) this.sInput.readObject());
	}

	public void pushWarten() {
		StartAction firstAction = new StartAction();
		firstAction.setWarten(true);
		try {
			this.sOutput.writeObject(firstAction);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int pushFirstActionModus() {
		StartAction firstAction = new StartAction();
		firstAction.setModiAuswahl(true);
		try {
			this.sOutput.writeObject(firstAction);
		} catch (IOException e) {
			e.printStackTrace();
		}
		StartActionAnt antwort = null;
		try {
			antwort =(StartActionAnt) this.sInput.readObject();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		int modus = antwort.getModus();
		return modus;
		
	}

	public int getModusNr() {
		int modusInt = pushFirstActionModus();
		System.out.println(modusInt);
		return modusInt;
	}
}
