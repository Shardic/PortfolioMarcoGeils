package danielolivermarco.network;

import java.io.IOException;
import java.net.*;
import java.nio.channels.ServerSocketChannel;
import java.util.Vector;

import danielolivermarco.anwendungslogik.Spiel;

public class ServerStart {
	private int port;
	private Vector<ServerClient> clients;
	private int nummer;
	private Spiel dasSpiel;
	private ServerSocket serverSocket;
	
	public ServerStart(int p) throws ClassNotFoundException {
		this.port = p;
		this.clients = new Vector<ServerClient>();
		try {
			serverSocket = new ServerSocket(port);
			System.out.println("Server waiting for Clients on port " + this.port + ".");
			Socket socket = serverSocket.accept(); 
			nummer++;
			System.out.println("Client connected");
			clients.add(new ServerClient(nummer, socket, this));
			spielStart();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void connectRestlicheSpieler() throws IOException {
		while(nummer < dasSpiel.getAnzahlSpieler()){
			System.out.println("Server waiting for Clients on port " + this.port + ".");
			Socket socket = serverSocket.accept();
			nummer++;
			System.out.println("Client connected");
			clients.add(new ServerClient(nummer, socket, this));
			clients.get(clients.size()-1).pushWarten();
		}
	}
	
	
	public Spiel getDasSpiel() {
		return dasSpiel;
	}


	public void setDasSpiel(Spiel dasSpiel) {
		this.dasSpiel = dasSpiel;
	}

	public Vector<ServerClient> getClients() {
		return clients;
	}


	public void spielStart() throws IOException, ClassNotFoundException {
		dasSpiel = new Spiel();
		dasSpiel.mapEinstellen();
		clients.get(0).pushFirstActionAnzahl();
		clients.get(0).pushFirstActionSpieler();
//		for (int y = 0; y < dasSpiel.getSpielerListe().size(); y++) {
//			System.out.println(dasSpiel.getSpielerListe().get(y).getName());
//		}
		//Modus durch Client 1 auswaehlen lassen: 
		dasSpiel.spielerEinstellen();
		dasSpiel.missionenEinstellen();
		dasSpiel.getDieAnfangsphase().initGUI(clients.get(0).getModusNr());
	}
	
	
}
