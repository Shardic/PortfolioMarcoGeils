package danielolivermarco.domain;

import danielolivermarco.network.ServerStart;

public class Server {

	public static void main(String[] args) throws ClassNotFoundException {
		int port = 9000;
		ServerStart server = new ServerStart(port);
	}
}
