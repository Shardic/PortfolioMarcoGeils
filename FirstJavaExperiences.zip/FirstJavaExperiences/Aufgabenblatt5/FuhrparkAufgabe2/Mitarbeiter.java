class Mitarbeiter {
 
 private String name;
 private String abteilung;
 private boolean unterwegs = false;
	
	public Mitarbeiter(String n, String abt) {
		this.name = n;
		this.abteilung = abt;
	}
	
	public void printStatus(){
		System.out.println("Mitarbeiter " + this.name + " (" + this.abteilung + ") ist " + ( this.unterwegs ? " unterwegs." : " da"));
	}
	
	public void setzeUnterwegs(boolean status) {
		this.unterwegs = status;
	}
	
	public boolean istUnterwegs() {
		return this.unterwegs;
	}
	
	public String hatAbteilung() {
		return this.abteilung;
	}
	
	public String hatName() {
		return this.name;
	}
}