class Fahrt {
	private Mitarbeiter mitarbeiter;
	private Kfz fahrzeug;
	private int startTag = 0;
	private int endTag = 0;
	
	public Fahrt(Kfz k, Mitarbeiter m) {
		this.fahrzeug = k;
		this.mitarbeiter = m;
	}
	
	public void antreten(int heute) {
		this.startTag = heute;
		// Mitarbeiter und Fahrzeug sind ab jetzt unterwegs
		this.mitarbeiter.setzeUnterwegs(true);
		this.fahrzeug.setzeVerfuegbarkeit(false);
	}
		
	public void beenden(int heute) {
		this.endTag = heute;
		// Mitarbeiter ist wieder zuhause ...
		this.mitarbeiter.setzeUnterwegs(false);
		// ... und Kfz wieder verfügbar
		this.fahrzeug.warten();
		this.fahrzeug.setzeVerfuegbarkeit(true);
	}
	
	public int hatDauer() {
		if (this.endTag < this.startTag) {
			return (365 + this.endTag - this.startTag);
		} else {
			return (this.endTag - this.startTag);
		}
	}
		
	public Mitarbeiter hatMitarbeiter() {
		return mitarbeiter;
	}
}