class Kfz {
 
	private String kennzeichen;
	private boolean verfuegbar;
	public Kfz(String kennz) {
		this.kennzeichen = kennz;
		this.verfuegbar = true;
	}
 
	public void setzeVerfuegbarkeit(boolean status) { 
		this.verfuegbar = status;
	}
 
	public boolean istVerfuegbar() {
		return this.verfuegbar;
	}
	
	public void warten() {
		// dem Tankwart Bescheid geben ...
	}
 
	public void printStatus() {
		IO.println("Kfz Kennzeichen "+this.kennzeichen+" ist" 
			+ ( (this.verfuegbar==true) ? " da." : " unterwegs."));
	}
}
