class Rechnung {
	private int anzahlTage; // Anzahl Tage, die Mitarbeiter weg war
	private String name;
	private String abteilung;
	
	public Rechnung (String name, String abt, int tage) {
		this.name = name;
		this.abteilung = abt;
		this.anzahlTage = tage;
	}
 
	public void printStatus() {
		IO.println("Rechnung ueber " + this.anzahlTage 
		+ " Tage fuer Mitarbeiter " + this.name 
		+ " aus Abt. " + this.abteilung);
	}
}