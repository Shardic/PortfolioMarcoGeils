public class Tannenbaum {
	private int hoehe;
	
	public Tannenbaum(int h) {
		hoehe = h;
	}
	
	public void zeichne() {
		if (this.hoehe < 0) {
			System.out.println("Du hast eine negative Zahl eingegeben, wie soll der Baum denn aussehen?");

		} else {
			kroneZeichnen();
			stammZeichnen();
		}
	}

	private void kroneZeichnen() {
		int krongrenzeLinks = hoehe - 2;
		int krongrenzeRechts = krongrenzeLinks + 2;
		char[][] krone = new char[hoehe][(hoehe*2)-1];
		for (int i = 0; i<hoehe; i++) {
			System.out.println();
			for (int breite = 0; breite < (hoehe*2)-1; breite++) {
				if (krongrenzeLinks >= breite || krongrenzeRechts <= breite) {
					krone[i][breite] = ' ';
				}	else {
					krone[i][breite] = 'x';
				}
			System.out.print(krone[i][breite]);
			}
			krongrenzeLinks--;
			krongrenzeRechts++;
		}
	}
	
	private void stammZeichnen() {
		int stammBreite = 2*(hoehe/5)+1;
		int stammHoehe = stammBreite/2+1;
		char[][] stamm = new char[stammHoehe][(hoehe*2)-1];
		for(int i = 0; i < stammHoehe; i++) {
			System.out.println();
			for (int b = 0; b < (hoehe+(stammBreite/2)); b++) {
				if ((hoehe-(stammBreite/2+1)) > b) {
					stamm[i][b] = ' ';
				} else {
					stamm[i][b] = 'x';
				}
			System.out.print(stamm[i][b]);
			}
		}
	}
		
	public static void main(String[] args) {
		System.out.println("Wie hoch soll dein Baum sein? Gib einen Integer ein!");
		Tannenbaum tb = new Tannenbaum(IO.readInt());
		tb.zeichne();
	}
}