class Spiel {
	
	private Spielfeld diesesFeld;
		
	public void userInterface() {
		boolean menueEins = true;
		System.out.println("Willkommen beim Game of Life!");
		System.out.println("1: Spiel starten, Spielfeld bestimmen und Steine legen.");
		System.out.println("2: Spiel doch wieder beenden.");
		while(menueEins) {
			int auswahl = IO.readInt();
			switch (auswahl) {
				case 1 :spielBeginnen(); 
						menueEins = false;
						break;
				case 2 :spielBeenden();
						menueEins = false;
						break;
				default : 	System.out.println("Falsche Eingabe");
							break;
				}
			}
	}

	public void spielBeginnen() {
		System.out.println("Wie gross soll dein zweidimensionales Spielfeld sein?");
		int hoehe = IO.readInt();
		int breite = IO.readInt();
		this.diesesFeld = new Spielfeld(hoehe,breite);
		steineLegen();
	}
	
	public void steineWerdenGelegt() {
		int steinHoehe = IO.readInt();
		int steinBreite = IO.readInt();
		this.diesesFeld.steinLegen(steinHoehe + 2, steinBreite + 2);
	}
	
	public void steineLegen() {
		boolean steinePlatzieren = true; 
		System.out.println("Bitte lege nun Spielsteine aufs Feld.");
		System.out.println("Gebe dazu Koordinaten an, bedenke dabei, dass dein Spielfeld bei den Koordinaten 0/0 beginnt!");
		steineWerdenGelegt();
		while(steinePlatzieren) {
			System.out.println("1: Weiteren Stein legen.");
			System.out.println("2: Spiel beginnen.");
			int auswahl = IO.readInt();
			switch(auswahl) {
				case 1 : 	steineWerdenGelegt();
							break;
				case 2 : 	interfaceWhilePlaying();
							steinePlatzieren = false;
							break;
				default : 	System.out.println("Fehleingabe");
							break;
			}
		}
	}
	
	public void interfaceWhilePlaying() {
		boolean imSpiel = true;
		while(imSpiel) {
			System.out.println("1: Eine Generation weiter.");
			System.out.println("2: Spiel beenden."); 	
			int auswahl = IO.readInt();
			switch(auswahl) {
				case 1: 	this.diesesFeld.generationVor();						// Hier soll das Spiel eine weitere Generation berechnen und diese in ein neues eventuell groe�eres Spielfeld uebertragen
							break;
				case 2:		spielBeenden();
							imSpiel =  false;
							break;
				default : 	System.out.println("Fehleingabe.");
							break;
			}
		}		
	}
	
	public void spielBeenden() {
		System.out.println("Auf Wiedersehen.");
	}


	public static void main(String[] args) {
		Spiel gOfL = new Spiel();
		gOfL.userInterface();
	}
}