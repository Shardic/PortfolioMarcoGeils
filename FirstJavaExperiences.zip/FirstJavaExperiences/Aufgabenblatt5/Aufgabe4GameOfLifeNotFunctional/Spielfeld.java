class Spielfeld {
		
	protected Spielsteine[][] dasFeld;
	private Spielsteine[][] naechsteGeneration;
	
	public Spielfeld () {
	}
	
	public Spielfeld(int hoehe, int breite) {
		this.dasFeld = new Spielsteine[hoehe+4][breite+4];
		initialisieren();
	}

	private void initialisieren() {
		for (int i = 0; i < this.dasFeld.length; i++) {
			for (int j = 0; j < this.dasFeld[i].length; j++) {
				this.dasFeld[i][j] = new Spielsteine(2);
			}
		}
	}
	
	public void zeichnen() {
		char dies;
		for (int i = 0; i < this.dasFeld.length; i++) {
			for (int j = 0; j < this.dasFeld[i].length; j++) {
				dies = this.dasFeld[i][j].hatStein();
				System.out.print(dies);
			}
			System.out.println();
		}
	}
	
	public void wachstumPruefen() {
		boolean einMehr = false;
		for (int k = 1; k < naechsteGeneration.length-1; k++) {
			if (naechsteGeneration[1][k].getAlive()) {
				einMehr = true;
			}
			if (naechsteGeneration[k][1].getAlive()) {
				einMehr = true;
			}
			if (naechsteGeneration[k][naechsteGeneration.length-2].getAlive()) {
				einMehr = true;
			}
			if (naechsteGeneration[naechsteGeneration.length-2][k].getAlive()) {
				einMehr = true;
			}
		}
		System.out.println("Feldgroesse: " + naechsteGeneration.length + " * " + dasFeld.length);
		nextGenSet();
		if (einMehr == true) {	
			this.dasFeld = new Spielsteine[this.dasFeld.length+2][this.dasFeld.length+2];
			for (int i = 1; i < dasFeld.length-2; i++) {				
				for (int j = 1; j < dasFeld.length-2; j++) {			
					this.dasFeld[i+2][j+2] = this.naechsteGeneration[i][j];
				}
			}
		} else {
			for (int i = 0; i < dasFeld.length; i++) {				// Die Steine aus dem Feld naechste Generation einsetzen
				for (int j = 0; j < dasFeld.length; j++) {			// verschiedene Bedingungen um das neue Feld zu befüllen je nachdem ob das aktuele Feld die neue größe hat oder die alte mit if einmehr > 0 und einmehr == 0 
					this.dasFeld[i][j] = this.naechsteGeneration[i][j];
				}
			}
		}
	}
	
	public void generationVor() {
		this.naechsteGeneration = hatNachbarn(this.dasFeld);
		wachstumPruefen();
		zeichnen();
	}
	
	private void nextGenSet() {
		for (int i = 0; i < naechsteGeneration.length; i++) {
			for (int j = 0; j < naechsteGeneration.length; j++) {
				if(naechsteGeneration[i][j].getAlive()) {
					this.naechsteGeneration[i][j] = new Spielsteine(1);
				} else {
					this.naechsteGeneration[i][j] = new Spielsteine(2);
				}
			}
		}
	}
	
	private Spielsteine[][] hatNachbarn(Spielsteine[][] formalesFeld) {
		int nachbarn = 0;
		for (int i = 1;i < formalesFeld.length-1; i++) {
			for (int k = 1; k < formalesFeld[i].length-1; k++) {
						if (formalesFeld[i][k-1].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i+1][k-1].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i][k+1].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i+1][k+1].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i+1][k].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i-1][k].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i-1][k+1].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i-1][k-1].hatStein() == 'x') {
							nachbarn++;
						}				
				if (formalesFeld[i][k].hatStein() == 'x' && (nachbarn == 2 || nachbarn == 3)) {
					formalesFeld[i][k].setAlive();
				} else if (formalesFeld[i][k].hatStein() == 'x' && (nachbarn != 2 || nachbarn != 3)) {
					formalesFeld[i][k].unsetAlive();
				} else if (formalesFeld[i][k].hatStein() == ' ' && nachbarn == 3) {
					formalesFeld[i][k].setAlive();
				} 	
			nachbarn = 0;  
			}
		}
		return formalesFeld;
	}
	
	public void steinLegen(int hoehe, int breite) {
		for (int i = 0; i < dasFeld.length; i++) {
			if (i == hoehe) {
				for (int k = 0; k < dasFeld[i].length; k++) {
					if (k == breite) {
						this.dasFeld[i][k].setAlive();
						this.dasFeld[i][k] = new Spielsteine(1);	
					}
				}
			}
		}
	}
	
}