class Spielsteine {
/*
	es gibt zwei moegliche Spielsteine 1. auf Feldern die belegt werden mit 'x' und zweitens die leeren Felder mit ' ' 
	es wird später hier geprüft wieviele Nachbarn ein Spielstein hat. Je nachdem er mit 'x' oder ' ' belegt ist wird ein return geliefert und woanders gespeichert ob das Feld ein belegtes Feld ist oder nicht 
*/
	private char stein;
	boolean amLeben = false;
	
	public Spielsteine (int einsOderZwei) {
		if (einsOderZwei == 1) {
			this.stein = 'x';
		} else if(einsOderZwei == 2) {
			this.stein = ' ';
		}
	}

	public char hatStein() {
		return this.stein;
	}
	
	public void setAlive() { 			//gilt jeweils nur für die nächste Runde
		this.amLeben = true;
	}
	
	public boolean getAlive() {
		return this.amLeben;
	}
	
	public void unsetAlive() {
		this.amLeben = false;
	}
	
}