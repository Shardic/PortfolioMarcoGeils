class Abteilung {
	private String name;
	private Mitarbeiter[] maDerAbteilung;

	public Abteilung(String n) {
	 this.name = n;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setMaDerAbteilung(Mitarbeiter[] dieMa) {
		this.maDerAbteilung = dieMa;
	}
	
	public Mitarbeiter[] getMaDerAbteilung() {
		return maDerAbteilung;
	}
	
	public String getAbtName() {
		return this.name;
	}

	public void printStatus() {
		System.out.println("Abteilung: " + this.name + " hat " + maDerAbteilung.length + " Mitarbeiter:");
		for (int i = 0; i < maDerAbteilung.length;i++) {
			maDerAbteilung[i].printStatus();
		}
	}
	
	private Mitarbeiter getArmMa() {
		Mitarbeiter armer = this.maDerAbteilung[0];
		
		for (int i = 1; i < maDerAbteilung.length ; i++) {
			if (armer.getGehalt() > maDerAbteilung[i].getGehalt()) {
				armer = maDerAbteilung[i];
			}
		}
		return armer;
	}
	
	public void bonusGeben(int bonus) {
		Mitarbeiter armer = getArmMa();
		for (int i = 0; i < this.maDerAbteilung.length ; i++) {
			if (armer.equals(maDerAbteilung[i])) {
				int hoeher = bonus + (bonus * 10 / 100);
				this.maDerAbteilung[i].aendereGehalt(hoeher);
			} else {
				this.maDerAbteilung[i].aendereGehalt(bonus);
			}
		}
	}
	
	public int getKosten() {
		int kosten = 0;
		for(int i = 0; i< maDerAbteilung.length ;i++) {
			kosten = kosten + maDerAbteilung[i].getGehalt();
		}
		return kosten;
	}
	
	public void einsparen(int prozent, int minGehalt) {
		for (int i = 0; i < maDerAbteilung.length ; i++) {
			int einsparung = maDerAbteilung[i].getGehalt() * prozent / 100;
			if ((maDerAbteilung[i].getGehalt() - einsparung) >= minGehalt) {
				maDerAbteilung[i].aendereGehalt(-einsparung);
			} 
		}
	}
	
	public void maRaus(Mitarbeiter m){
		Mitarbeiter gekuendigt = new Mitarbeiter("Freier Arbeitsplatz", 0);
		for (int i = 0; i < maDerAbteilung.length; i++) {
			if (m.equals(maDerAbteilung[i])) {
				maDerAbteilung[i] = gekuendigt;
			}
		}
	}
	
}