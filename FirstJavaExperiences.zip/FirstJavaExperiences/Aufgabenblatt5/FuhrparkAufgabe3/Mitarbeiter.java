class Mitarbeiter {
	private String name;
	private int gehalt;
	
	public Mitarbeiter() {
		this.name = "Anonym";
		this.gehalt = 2500;
	}
	
	public Mitarbeiter(String n, int geh) {
		this.name = n;
		this.gehalt = geh;	
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getGehalt() {
		return this.gehalt;
	}
	
	public void aendereGehalt(int n) {
		this.gehalt += n;
	}
	
	public void printStatus() {
		System.out.println("Das Gehalt von " + this.name + " betraegt " + this.gehalt + ".");
	}
}