public class Firma {
	private Abteilung[] abtDerFirma;
	private Mitarbeiter derChef;
	private String firmenName;
	
	public Firma(String name, Mitarbeiter chef) {
		this.abtDerFirma = new Abteilung[3]
		this.abtDerFirma[0] = new Abteilung("Finanzen");
		this.abtDerFirma[1] = new Abteilung("Personal");
		this.abtDerFirma[2] = new Abteilung("Vertrieb");
		this.derChef = chef;
		this.firmenName = name;
	}
	
	public boolean einstellen(Mitarbeiter[] mListe, String abtName) {
		for(Abteilung a : this.abtDerFirma) {
			if(abtName.equals(a.getAbtName())){
				a.setMaDerAbteilung(mListe);
				return true;
			}
		}
		return false;	
	}
	
	public void printStatus() {
		System.out.println("Die Firma heisst: " + this.firmenName + ", und wird von " + derChef.getName() + " geleitet.");
		System.out.println(this.firmenName + " hat " + abtDerFirma.length + " Abteilungen:");
		for (int i = 0; i < abtDerFirma.length ; i++) {
			abtDerFirma[i].printStatus();
		}
	}
	
	public int berechneKosten() {
		int gesamtKosten = 0;
		for (int i = 0; i < abtDerFirma.length ; i++) {
			gesamtKosten = gesamtKosten + abtDerFirma[i].getKosten();
		}
		return gesamtKosten;
	}

	public void printKosten() {
		int firmenKosten = berechneKosten();
		System.out.println("Die Gesamtkosten der Firma berechnen sich auf : " + firmenKosten + ", wohlgemerkt ohne das Gehalt vom Chef!");
	}
	
	public void bonusGeben(int bonus) {
		for (int i = 0; i < abtDerFirma.length ; i++) {
			abtDerFirma[i].bonusGeben(bonus);
		}
	}
	
	public void einsparen(int prozent) {
		Abteilung teuer = abtDerFirma[0];
		int teurer = abtDerFirma[0].getKosten();
		for (Abteilung aktuell : abtDerFirma) {
			if(aktuell.getKosten() > teurer) {
					teuer = aktuell;
					teurer= aktuell.getKosten();
			}
		}
		teuer.einsparen(prozent, 1500);
	}
	
	public void kuendigen(Mitarbeiter m) {
		Abteilung relevante = abtDerFirma[0];
		for(Abteilung rausda: abtDerFirma) {
			Mitarbeiter[] liste = rausda.getMaListe();
			for (int k = 0; k < liste.length; k++) {
				if(m.equals(liste[k])) {
					relevante = rausda;
				}
			}
		}
		relevante.maRaus(m);
	}
	
	public static void main(String[] args) {
		Mitarbeiter chef = new Mitarbeiter( "Marco Geils" , 10000);
		Firma firma1 = new Firma("Self-Ag", chef);
		Mitarbeiter[] maFinanzen = new Mitarbeiter[3];
		maFinanzen[0] = new Mitarbeiter("Mueller", 2500);
		maFinanzen[1] = new Mitarbeiter("Meyer", 2400);
		maFinanzen[2] = new Mitarbeiter("Baecker", 2500);
		Mitarbeiter[] maPersonal = new Mitarbeiter[3];
		maPersonal[0] = new Mitarbeiter("Holy",3001);
		maPersonal[1] = new Mitarbeiter("Moly",3000);
		maPersonal[2] = new Mitarbeiter("Broly",3001);
		Mitarbeiter[] maVertrieb = new Mitarbeiter[10];
		maVertrieb[0] = new Mitarbeiter("Sklave1", 1502);
		maVertrieb[1] = new Mitarbeiter("Sklave2", 1502);
		maVertrieb[2] = new Mitarbeiter("Sklave3", 1502);
		maVertrieb[3] = new Mitarbeiter("Sklave4", 1502);
		maVertrieb[4] = new Mitarbeiter("Sklave5", 1501);
		maVertrieb[5] = new Mitarbeiter("Sklave6", 1502);
		maVertrieb[6] = new Mitarbeiter("Sklave7", 1502);
		maVertrieb[7] = new Mitarbeiter("Sklave8", 1502);
		maVertrieb[8] = new Mitarbeiter("Sklave9", 1502);
		maVertrieb[9] = new Mitarbeiter("Sklave10", 1502);
		firma1.einstellen(maFinanzen, "Finanzen");
		firma1.einstellen(maPersonal, "Personal");
		firma1.einstellen(maVertrieb, "Vertrieb");
		firma1.printStatus();
		firma1.printKosten();
		firma1.bonusGeben(100);
		firma1.printStatus();
		firma1.printKosten();
		firma1.einsparen(1);
		firma1.printStatus();
		firma1.printKosten();
		firma1.kuendigen(maPersonal[1]);
		firma1.printStatus();
		firma1.printKosten();
	}
}