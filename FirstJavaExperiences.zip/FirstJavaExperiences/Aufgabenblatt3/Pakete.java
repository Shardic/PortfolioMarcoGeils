/* Die abfragen deklarieren in denen die eingaben eingegeben werden
	ein Paket objekt erstellen 
	im paket methoden deklarieren die das Paket packen und dabei die regeln beachten
	diese methode ansteuern mit den vom nutzer eingegebenen Eingaben
*/
public class Pakete {
	int usedkp = 0;
	public int paketPacken(int kp, int gp, int zg) {
			while (gp > 0 && zg > 0) {
				zg -= 5;
				gp--;
			}
			while (kp > 0 && zg > 0) {
				zg--;
				kp--;
				usedkp++;
			}
			if (zg > 0) {
				return -1;
			}
			if (zg == 0) {
				return usedkp;
			} else {
				return -2;
			}
	} 
	public static void main (String[] args) {
		System.out.println("Gib das Zielgewicht an welches du verschicken moechtest");
		int zielgr = IO.readInt();
		System.out.println("Wieviele kleine Pakungseinheiten, die ein Kilo fassen, stehen dir zur Verfuegung ?");
		int klPak = IO.readInt();
		System.out.println("Wieviele grosse Pakungseinheiten, die fuenf Kilo fassen, stehen dir zur Verfuegung ?");
		int grPak = IO.readInt();
		Pakete bob = new Pakete();
		int ergebnis = bob.paketPacken(klPak, grPak, zielgr); 
		switch(ergebnis) {
			case -1 : System.out.println("Du hast zu wenige Packungseinheiten!");
						break;
			default : System.out.println("Du hast von den kleinen Packungseinheiten " + ergebnis + " genutzt");
		}
	}
}