public class Hamster {
	private int anzKoerner;
	private String farbe;
	
	public void schlagen(int aua) {
		if(aua == 0) {
			IO.println("Du bist gut :-) Man schlaegt keine armen wehrlosen Tiere!");
		} else if (aua == 1 || aua == 2) {
			IO.println("Aha dir macht es Spass Tiere zu schlagen? Ich hol den Tierschutz, verschwinde lieber!");
		} else if (aua < 0) {
			IO.println("Hae? Wie tust du? Negativ mal zuschlagen? Ja klar und ich teile durch 0");
		} else if (aua >= 3) {
			IO.println("Oh, du hast " + aua + " mal zugeschlagen, der Hamster hat nicht ueberlebt! Hoffentlich bekommst du niemals Kinder!");
		} else return;
	}		
	
	public Hamster() {
		anzKoerner = 0;
	}
	
	public void nimm() {
		anzKoerner++;
	}
	
	public int getAnzKoerner() {
		return anzKoerner;
	}
	
	public void setFarbe(String dieFarbe) {
		farbe = dieFarbe;
	}
	
	public String getFarbe() {
		return farbe;
	}
	
	public static void main(String[] args) {
		Hamster h1;
		h1 = new Hamster();
		h1.nimm();
		h1.nimm(); 
		
		int anz = h1.getAnzKoerner();
		IO.println("Koerner im Maul: " + anz);
		IO.println("In welcher Farbe moechtest du den Hamster streichen ?");
		h1.setFarbe(IO.readString());
		String welcheFarbe =  h1.getFarbe();
		IO.println("Der Hamster ist " + welcheFarbe);
		IO.println("Oh! Du kannst den Hamster schlagen, wie oft möchtest du ihn schlagen?");
		h1.schlagen(IO.readInt());

	}
}