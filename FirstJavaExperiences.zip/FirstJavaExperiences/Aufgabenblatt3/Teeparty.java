class Teeparty {
	public int party (int tee, int kekse) {
		int p1 = tee *2;
		int p2 = kekse *2;
		if (tee < 5 || kekse < 5) {
			return 0;
		}
		if (tee >= p2 || kekse >= p1) {
			return 2;
		}
		if (tee >= 5 && kekse >= 5) {
			return 1;
		} else {
			return 3;
		}
	}
	public static void main(String[] args) {
		Teeparty tp = new Teeparty();
		IO.println("Wieviele Kekse gab es auf der Party?");
		int k = IO.readInt();
		System.out.println("Und wieviel Tee gab es auf der Party ?");
		int t = IO.readInt();
		int e = tp.party(t,k);
			if (e == 0) {
				System.out.println("Die Party war schlecht! Gib dir das naechste mal mehr Muehe!");
			}
			if (e == 1) {
				IO.println("Die Party war gut!");
			}
			if (e == 2) {
				IO.println("Die Party war super!!! WOW Hangover war nix dagegen!");
			}
			if (e == 3) {
				IO.println("Irgendwas ist furchtbar schief gelaufen");
			}
	}
}
