class Rechner {
	int z1;
	int z2;
	int ergebnis;
	char op;
	public void einlesen() {
		IO.println("Hallo! Willkommen in der Matrix!");
		IO.println("Du kannst hier verschiedene Berechnungen anstellen.");
		IO.println("Dazu solltest du wissen das du zuerst den Operator eingeben sollst!");
		IO.println("Die Operatoren gibst du folgend ein:");
		IO.println("Addition: a");
		IO.println("Subtraktion: s");
		IO.println("Multiplikation: m");
		IO.println("Division: d");
		IO.println("Gebe nun den Operator ein:");
		op = IO.readChar();
		IO.println("Gebe nun den ersten Operanten ein");
		z1 = IO.readInt();
		IO.println("Gebe nun den zweiten Operanten ein");
		z2 = IO.readInt();
	}	
	public boolean berechne() { 
		// Fehlerprüfungen:
		if (op != 'a' && op != 's' && op != 'm' && op != 'd') {
			return false;
		} 
		if (op == 'd' && z2 == 0) {
			return false;
		} 
		if (op == 'd' && z1 % z2 != 0) {
		return false;
		} else { 
			switch(op) {
				case 'a' : ergebnis = z1 + z2;
							break;
				case 's' : ergebnis = z1 - z2;
							break;
				case 'm' : ergebnis = z1 * z2;
							break;
				case 'd' : if(z1 != 0) {
								ergebnis = z1 / z2;
								return true;
							} else {
								return false;
							}
				default: return false;
			}
		} return true;
	}
	public void ausgeben() {
		if (berechne()) {
			IO.println("Das Ergebnis ist: " + ergebnis);
		} else {
			IO.println("Dir ist ein Fehler unterlaufen");
		}
	}
	public static void main(String[] args)  {
		char w = 'y';
		Rechner one = new Rechner();	
		do {
			one.einlesen();
			one.ausgeben();
			IO.println("Moechtest du eine weitere Berechnung anstellen?");
			IO.println("Gebe n ein wenn du das nicht moechtest! Jede andere Taste wird dich wieder an den Anfang schicken!");   // nur 'y' soll die Schleife wiederholen alles andere soll die Frage wiederholen 
			w = IO.readChar();
			while (w != 'y' && w != 'n') {
				System.out.println("Du musst schon ein n oder y eingeben");
				w = IO.readChar();
			}
		} while (w == 'y');
		}
}