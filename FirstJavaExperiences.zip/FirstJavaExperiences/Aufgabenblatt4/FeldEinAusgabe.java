public class FeldEinAusgabe {
	private char[][] array;
	private int zeilen;
	private int spalten;
	private int xZeile;
	private int xSpalte;
	
	public FeldEinAusgabe() { //Konstruktor
	}
	
	public void einlesen() {
		System.out.println("Willkommen, du kannst ein 2D Feld erstellen welches in Punkten dargestellt wird,");
		IO.println("danach kannst du eine Koordinate angeben an welcher dann ein X erscheint!");
		System.out.println("Wie gross soll dein 2D Feld sein? Gib zuerst die Zeilen, dann die Spalten ein.");
		zeilen = IO.readInt();
		spalten = IO.readInt();
		array = new char[zeilen][spalten];
		for (int z = 0; z < zeilen; z++) {
			for (int s = 0; s < spalten; s++) {
				array[z][s] = '.';
			}
		}
		System.out.println("Wo moechtest du nun dein X eintragen?");
		System.out.println("Gib zuerst die Zeilen, dann die Spalten ein. Die Koordinaten beginnen bei 1/1");
		xZeile = IO.readInt();
		xSpalte = IO.readInt();
		array[xZeile-1][xSpalte-1] = 'X';	
	}
	
	public void ausgeben() {
		for (int z = 0; z < zeilen; z++) {
			System.out.println();
			for (int s = 0; s < spalten; s++) {
				System.out.print(array[z][s]);
			}
		}
	}
}