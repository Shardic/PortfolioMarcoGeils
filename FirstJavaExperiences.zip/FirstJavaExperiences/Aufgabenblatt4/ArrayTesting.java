public class ArrayTesting {
	int[] bro = new int[10];			//warum an dieser Stelle nicht in mehreren Zeilen wie unten? 
	public void indexOverflow() {									//---> int[] bro;
		for(int i= 0;i<11;i++) {									// bro = new int[10]; nicht möglich ???
			bro[i] = 1;
			System.out.println(bro[i]);
		}
	}
	public void nichtErzeugung() {
		int[] blub = null;	
		System.out.println(blub[5]);
	}
	public void heapOverflow() {
			int kill= 1234567846;
			int[][][] a = new int[100000][100000][100000];
			int[] test = new int[kill];
			kill *= 123456;
	}
	public float[] expliziteErzeugung() {
		float[] flo;
		flo = new float[5];
		for(int i = 0, j = 1; i<flo.length ; i++) {
			flo[i] = i+j;
			System.out.println("ImplizitesArray: " + flo[i]);
		} 
		return null;
	}
	public int[] impliziteErzeugung() {
		int[] in = {2,4,6,8,10};
		for (int i = 0; i <in.length ; i++) {
			System.out.println("ExplezitesArray: " + in[i]);
		}
		return null;
	}
	public static void main(String[] args) {
		ArrayTesting arr = new ArrayTesting();
		//arr.impliziteErzeugung();
		//arr.expliziteErzeugung();
		//arr.indexOverflow();
		//arr.nichtErzeugung();
		arr.HeapOverflow();
	}
}