public class TamagochiHundA {
	
	public TamagochiHundA(){
	}
	
	private int z = 0;
	private int[][] hund = { 	{1,5},
								{3,2},
								{3,6},
								{4,1},
								{100,100},
								{1,5},
								{1,7},
								{100,100}
							};
	private String[] hundausgabe = {"Der Hund wedelt mit dem Schwanz und bellt! Was moechtest du tun?",
									"Der Hund wedelt mit dem Schwanz! Was moechtest du tun?",
									"Der Hund schnurrt! Was moechtest du tun?",
									"Der Hund kotzt! Was moechtest du tun?",
									"Der Hund ist geplatzt!",
									"Der Hund bellt! Was moechtest du tun?",
									"Der Hund gaehnt! Was moechtest du tun?",
									"Nun schlaeft der Hund endlich friedlich!"};
	
	private void zustandAendern(int x) {
		
		if (x != 1 && x != 2) {
			System.out.println("Fehleingabe");
		} else {	
		
			System.out.println("x: " + x);
		z = hund[z][x];
		}
	}
	
	private void ausgabe(int zu) {
		System.out.println(hundausgabe[z]);
	}
	
	public void tama() {
		while (z != 4 && z != 7) {
			this.ausgabe(z);
			System.out.println();
			System.out.println("Du kannst den Hund fuettern (Eingabe: 0) oder streicheln (Eingabe: 1)");
			this.zustandAendern(IO.readInt());
			System.out.println("z: " + this.z);
		}
		this.ausgabe(z);
	}

	public static void main (String[] args) {
		System.out.println("Hallo, willkommen zum Tamagochi Hund");
		System.out.println("Sieh nur ein Hund wird geboren");
		TamagochiHundA h1 = new TamagochiHundA();
		h1.tama();
	}
}