public class TamagochiHund {
	private int z = 0;
	
	public TamagochiHund(){
	}
	
	private void ausgabe(int zu) {
		switch (zu) {
			case 0 : System.out.println("Der Hund wedelt mit dem Schwanz und bellt! Was moechtest du tun?");
					break;
			case 1 : System.out.println("Der Hund wedelt mit dem Schwanz! Was moechtest du tun?");
					break;				
			case 2 : System.out.println("Der Hund schnurrt! Was moechtest du tun?");
					break;
			case 3 : System.out.println("Der Hund kotzt! Was moechtest du tun?");
					break;
			case 4 : System.out.println("Der Hund ist geplatzt!");
					break;
			case 5 : System.out.println("Der Hund bellt! Was moechtest du tun?");
					break;
			case 6 : System.out.println("Der Hund gaehnt! Was moechtest du tun?");
					break;
			case 7 : System.out.println("Nun schlaeft der Hund endlich friedlich!");
					break;
			default : return;
		}
	}
	
	private void zustandAendern(int n) {
		if (n != 1 && n != 2) {
			this.z = z;
			System.out.println("Fehleingabe");
		} else if (n == 1) {
			switch (z) {
				case 0 : z = 1;
					break;
				case 1 : z = 3;
					break;
				case 2 : z = 3;
					break;
				case 3 : z = 4;
					break;
				case 5 : z = 1;
					break;
				case 6 : z = 1;
					break;
				default : z = z;
			}
		} else if (n == 2) {
			switch(z) {
				case 0 : z = 5;
					break;
				case 1 : z = 2;
					break;
				case 2 : z = 6;
					break;
				case 3 : z = 1;
					break;
				case 5 : z = 5;
					break;
				case 6 : z = 7;
					break;
				default : z = z;
			}
		}
	}		
	
	public void tama() {
		while (z != 4 && z != 7) {
			this.ausgabe(z);
			System.out.println("Du kannst den Hund fuettern (Eingabe: 1) oder streicheln (Eingabe: 2)");
			this.zustandAendern(IO.readInt());
		}
		this.ausgabe(z);
	}

	public static void main (String[] args) {
		System.out.println("Hallo, willkommen zum Tamagochi Hund");
		System.out.println("Sieh nur ein Hund wird geboren");
		TamagochiHund h1 = new TamagochiHund();
		h1.tama();
	}
}