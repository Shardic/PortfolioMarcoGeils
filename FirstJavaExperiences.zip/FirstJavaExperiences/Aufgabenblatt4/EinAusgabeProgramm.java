public class EinAusgabeProgramm {
	public static void main(String[] args) {
		FeldEinAusgabe obj = new FeldEinAusgabe();
		obj.einlesen();
		obj.ausgeben();
	}
}