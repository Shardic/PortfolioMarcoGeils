class Spielfeld {
		
		/*
			YOU WANNA BRING IT ? CMON BRING IT I GOT MY CAPSLOCK ON!
		*/
		
		
	protected Spielsteine[][] dasFeld;
	protected Spielsteine[][] zwischenspeicher;

	public Spielfeld() {				// ein 54 * 154 großes Spielfeld erstellen (maximum für die Konsole) / initialisieren aufrufen!
		this.dasFeld = new Spielsteine[54][154];
		initialisieren();
	}

	private void initialisieren() {   			// jedes Feld mit '_' belegen // ' ' sorgt für fehlanzeigen in der Konsole auf meinem Laptop
		for (int i = 0; i < this.dasFeld.length; i++) {
			for (int j = 0; j < this.dasFeld[i].length; j++) {
				this.dasFeld[i][j] = new Spielsteine(2);
			}
		}
	}
	
	public void zeichnen() {					//die jeweiligen Steine zeichnen die von den Spielsteine Objekten zuruückgegeben werden 
		char dies;
		for (int i = 0; i < this.dasFeld.length; i++) {
			for (int j = 0; j < this.dasFeld[i].length; j++) {
				dies = this.dasFeld[i][j].hatStein();
				System.out.print(dies);
			}
			System.out.println();
		}
	}
	
	private Spielsteine[][] hatNachbarn(Spielsteine[][] formalesFeld) {     // gibt ein Feld zurück in dem die Alive variable der Spielsteine auf ON und OFF sind
		int nachbarn = 0;
		for (int i = 1;i < formalesFeld.length-1; i++) {
			for (int k = 1; k < formalesFeld[i].length-1; k++) {
						if (formalesFeld[i][k-1].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i+1][k-1].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i][k+1].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i+1][k+1].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i+1][k].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i-1][k].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i-1][k+1].hatStein() == 'x') {
							nachbarn++;
						}
						if (formalesFeld[i-1][k-1].hatStein() == 'x') {
							nachbarn++;
						}				
				if (formalesFeld[i][k].hatStein() == 'x' && (nachbarn == 2 || nachbarn == 3)) {
					formalesFeld[i][k].setAlive();
				} else if (formalesFeld[i][k].hatStein() == 'x' && (nachbarn != 2 || nachbarn != 3)) {
					formalesFeld[i][k].unsetAlive();
				} else if (formalesFeld[i][k].hatStein() == '_' && nachbarn == 3) {
					formalesFeld[i][k].setAlive();
				} 	
			nachbarn = 0;  
			}
		}
		return formalesFeld;
	}
	
	public void generationVor() {
		this.zwischenspeicher = hatNachbarn(dasFeld);	// hier ein Feld holen wo Life counter der nächstn Generation vermerkt sind
		for (int i = 0; i < zwischenspeicher.length; i++) {					// hier wieder alle Felder auf '_'
			for (int k = 0; k < zwischenspeicher[i].length; k++) {
				if (zwischenspeicher[i][k].getAlive() == true) {
					steinLegen(i, k);
				} else {
					dasFeld[i][k].unsetAlive();
					dasFeld[i][k] = new Spielsteine(2);
				}
			}		
		}
	}
	
	public void randomizer() {
		int zufallszahl = 0;
		for (int i = 0; i < dasFeld.length; i++) {
			for (int j = 0; j < dasFeld[i].length; j++) {
				zufallszahl = myRandom(2,4);
				if (zufallszahl == 3) {
					steinLegen(i, j);
				}
			}
		}
	}
	
	public int myRandom(int a, int b) {
		return (int) (Math.random() * (b - a) + a);
	}
	
	public void steinLegen(int hoehe, int breite) {
		for (int i = 0; i < dasFeld.length; i++) {
			if (i == hoehe) {
				for (int k = 0; k < dasFeld[i].length; k++) {
					if (k == breite) {
						this.dasFeld[i][k].setAlive();
						this.dasFeld[i][k] = new Spielsteine(1);	
					}
				}
			}
		}
	}
	
}