class Spiel {
	
	private Spielfeld diesesFeld; 
	private int genCounter = 0;
		
	public void userInterface() {
		boolean menueEins = true;
		System.out.println("Willkommen beim Game of Life!");
		System.out.println("1: Spiel starten und Steine legen.");
		System.out.println("2: Spiel doch wieder beenden.");
		while(menueEins) {
			int auswahl = IO.readInt();
			switch (auswahl) {
				case 1 :spielBeginnen(); 
						menueEins = false;
						break;
				case 2 :spielBeenden();
						menueEins = false;
						break;
				default : 	System.out.println("Falsche Eingabe");
							break;
				}
			}
	}

	public void spielBeginnen() {			// Spielfeld erstellen und 3 Optionen ausw�hlen wo er hin will
		boolean menu2 = true;
		this.diesesFeld = new Spielfeld();
		System.out.println("Das Spielfeld ist 50 x 150 Felder gross! Was moechtest du darin tun?");
		System.out.println("1. Bekannte Pattern in die Mitte legen");
		System.out.println("2. Eigene Steine in ein 3x3 Feld in die Mitte legen?");
		System.out.println("3. Zurueck");
		while(menu2 == true) {
			int auswahl = IO.readInt();
			switch (auswahl) {
				case 1: patternLegen();
						menu2 = false;
						break;
				case 2: steineLegen();
						menu2 = false;
						break;
				case 3: userInterface();
						break;
				default: System.out.println("Falsche Eingabe");
			}
		}
	}
	
	public void patternLegen() {						// verschiedene voreingestellt pattern verwenden u.a. ein Randomizer f�r das Gesamte Feld 									
		boolean menu3 = true;
		System.out.println("1: Randomizer!");
		System.out.println("2: !");
		System.out.println("3: !");
		int auswahl = IO.readInt();
		while (menu3 == true) {
			switch(auswahl) {
				case 1: diesesFeld.randomizer();
						menu3 = false;
						interfaceWhilePlaying();
						break;
				case 2: System.out.println("Nichts geschieht");
						break;
				case 3: System.out.println("Nichts geschieht");
						break;
				default: System.out.println("Falsche Eingabe");
			}
		}
	//		System.out.println("hier geschieht noch nichts");
	}
	
	public void steineWerdenGelegt() {				// steine im Spielfeld Objekt legen
		int steinHoehe = IO.readInt();
		int steinBreite = IO.readInt();
		this.diesesFeld.steinLegen(steinHoehe + 27, steinBreite + 77);
	}
	
	public void steineLegen() {							// hier werden die Steine vom Spieler gelegt. 
		boolean steinePlatzieren = true; 
		System.out.println("Bitte lege nun Spielsteine aufs Feld.");
		System.out.println("Gebe dazu Koordinaten an, bedenke dabei, dass dein Spielfeld von 0/0 bis 2/2 geht!");
		steineWerdenGelegt();
		while(steinePlatzieren) {
			System.out.println("1: Weiteren Stein legen.");
			System.out.println("2: Spiel beginnen.");
			int auswahl = IO.readInt();
			switch(auswahl) {
				case 1 : 	steineWerdenGelegt();
							break;
				case 2 : 	this.diesesFeld.zeichnen();
							interfaceWhilePlaying();
							steinePlatzieren = false;
							break;
				default : 	System.out.println("Fehleingabe");
							break;
			}
		}
	}
	
	public void interfaceWhilePlaying() {
		boolean imSpiel = true;
		while(imSpiel) {
			System.out.println("1: Eine Generation weiter.");
			System.out.println("2: Spiel beenden."); 	
			int auswahl = IO.readInt();
			switch(auswahl) {
				case 1: 	this.diesesFeld.generationVor();
							this.diesesFeld.zeichnen(); 								// Hier soll das Spiel eine weitere Generation berechnen und diese in ein neues eventuell groe�eres Spielfeld uebertragen
							genCounter++;
							System.out.println("Generation Nr.:" + genCounter);
							break;
				case 2:		spielBeenden();
							imSpiel =  false;
							break;
				default : 	System.out.println("Fehleingabe.");
							break;
			}
		}		
	}
	
	public void spielBeenden() {			// Nachricht beim verlassen des Spiels
		System.out.println("Auf Wiedersehen.");
	}


	public static void main(String[] args) {
		Spiel gOfL = new Spiel();
		gOfL.userInterface();
	}
}