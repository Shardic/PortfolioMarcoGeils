import java.util.ArrayList;

public class Fuhrpark {
	
	public Mitarbeiter[] maListe = new Mitarbeiter[4];
 
	public Kfz[] kfzListe = new Kfz[2];
	private ArrayList<Fahrt> fahrtenListe = new ArrayList<Fahrt>();
 
	// Konstruktor
	public Fuhrpark() {
 
	// "Datenbank" anlegen:
	this.maListe[0] = new Mitarbeiter("Mueller", "Vertrieb");
	this.maListe[1] = new Mitarbeiter("Meier", "Buchhaltung");
	this.maListe[2] = new Mitarbeiter("Dummkopf", "Postbereich");
	this.maListe[3] = new Mitarbeiter("El Chefe", "Boss-Buero");
	this.kfzListe[0] = new Kfz("HB-A-1"); 
	this.kfzListe[1] = new Kfz("HB-B-2"); 
	}

	public Mitarbeiter[] hatMaListe() {
		return this.maListe;
	}
	public Kfz[] hatKfzListe(){
		return this.kfzListe;
	}

	public Fahrt fahrtAntreten(Kfz k, Mitarbeiter m, int tag) {
		if (!m.istUnterwegs() && k.istVerfuegbar()) {
			Fahrt dienstFahrt = new Fahrt(k, m);
			fahrtenListe.add(dienstFahrt);
			dienstFahrt.antreten(tag);
			return dienstFahrt;
		}
		return null;
	}
 
	public Rechnung fahrtAbrechnen(Fahrt f, int heute) {
		// Fahrt beenden 
		f.beenden(heute);
		// Rechnung erstellen
		int tage = f.hatDauer();
		Mitarbeiter m = f.hatMitarbeiter();
		Rechnung re = new Rechnung(m.hatName(), m.hatAbteilung(), tage);
		return re;
	}
	
	public void userInterface() {
		boolean programmAusfuehren = true;
		IO.println("Willkommen beim Fuhrparkmanager!");
		IO.println("Folgende Mitarbeiter stehen dir zur Verfuegung:");
		for (int i = 0; i < maListe.length;i++) {
			System.out.println(maListe[i].hatName() + ", " + maListe[i].hatAbteilung() + ", MNr: " + i);
		}
		IO.println("Folgende Wagen stehen dir zur Verfuegung:");
		for (int k = 0; k < kfzListe.length; k++) {
			kfzListe[k].printStatus(); 
			System.out.println("Die KNr des Kraftfahrzeuges ist: " + k);
		}
		while (programmAusfuehren) {
			System.out.println("Was moechtest du tun?");
			IO.println("1: Abfahren oder Wiederkommen.");
			IO.println("2: Mitarbeiterstatus ansehen.");
			IO.println("3: Kraftfahrzeugstatus ansehen");
			IO.println("9: Programm beenden");
			int auswahl = IO.readInt();
			switch(auswahl) {	
				case 1 : 	aktion();
							break;
				case 2 : 	this.maListe[0].printStatus();
							this.maListe[1].printStatus();
							this.maListe[2].printStatus();
							this.maListe[3].printStatus();
							break;
				case 3 :	this.kfzListe[0].printStatus();
							this.kfzListe[1].printStatus();
							break;
				case 9 : 	programmAusfuehren = false;
							break;
				default : System.out.println("Falsche Eingabe!");
			} 
		}
	} 

	private void aktion() {
		System.out.println("Moechtest du eine Fahrt starten oder wiederkommen lassen?");
		System.out.println("1: Fahrt antreten.");
		System.out.println("2: Fahrt wiederkommen lassen.");
		int auswahl = IO.readInt();
		switch(auswahl) {
			case 1 : 	aktionZwei();
						break;
			case 2 : 	aktionDrei();
						break;
			default : System.out.println("Falsche Eingabe");
		}
	}
	
	private void aktionZwei() {
		Mitarbeiter fahrLos = new Mitarbeiter("keiner","du hast einen Fehler gemacht");
		Kfz autoFahr = new Kfz("falsches Auto");
		System.out.println("Welchen Mitarbeiter moechtest du fahren lassen?");
		for (int i = 0; i < maListe.length ; i++) {
			if (!maListe[i].istUnterwegs()) {
				System.out.print("MNr.: " + i + " ");
				maListe[i].printStatus();
			} // else {
			//	System.out.println("Alle Mitarbeiter sind bereits unterwegs.");
			// }
		}
		int auswahl = IO.readInt();
		if (auswahl > maListe.length) {
			System.out.println("Fehleingabe");
			userInterface();
		} else {
			if (!maListe[auswahl].istUnterwegs()) {
				fahrLos = maListe[auswahl];
			} else { 
				System.out.println("Fehleingabe");
				userInterface();
			}
			System.out.println("Welches Auto soll " + maListe[auswahl].hatName() + " fahren?");
				for (int k = 0; k < kfzListe.length; k++) {
					if(kfzListe[k].istVerfuegbar()) {
						System.out.print("KNr.: " + k + " ");
						kfzListe[k].printStatus();
					}
				}
			int auswahlZwei = IO.readInt();
			if (auswahlZwei > maListe.length) {
				System.out.println("Fehleingabe");
				userInterface();
			} else {
				if (kfzListe[auswahlZwei].istVerfuegbar()) {
					autoFahr = kfzListe[auswahlZwei];
				} else {
					System.out.println("Fehleingabe");
					userInterface();
				}
				System.out.println("An welchem Tag soll die Fahrt beginnen?");
				int tagLos = IO.readInt();
				Fahrt f2 = fahrtAntreten(autoFahr, fahrLos, tagLos);
			}
		}
	}
	
	private void aktionDrei() {
		System.out.println("Welche Fahrt moechtest du wiederkommen lassen?");
		for (int i = 0; i < fahrtenListe.size(); i++) {
			System.out.print(i + ": Die Fahrt von ");
			fahrtenListe.get(i).hatMitarbeiter().printStatus();
		}
		int auswahl = IO.readInt();
		if (auswahl > fahrtenListe.size()) {
			System.out.println("Fehleingabe");
			userInterface();
		} else {
			System.out.println("An welchem Tag wurde die Fahrt beendet?");
			int auswahlTag = IO.readInt();
			fahrtenListe.get(auswahl).beenden(auswahlTag);
			fahrtenListe.remove(auswahl);
		}
	}

	// Klasse Fuhrpark dient als Hauptprogramm:
	public static void main(String[] args) {
	
		Fuhrpark fuhrpark = new Fuhrpark(); 
		// Testlauf mit konstanter Belegung: 
		// Mitarbeiter 1 fährt mit Kfz 1 an Tag 3 los
		Kfz k = fuhrpark.kfzListe[0];
		Mitarbeiter m = fuhrpark.maListe[0];
		Fahrt f = fuhrpark.fahrtAntreten(k, m, 3);
		fuhrpark.userInterface();
		
		/*if (f != null) {				// Testing 
			IO.println("Hat geklappt, los geht's!");
		} else { 
			IO.println("Das hat leider nicht funktioniert!");
			m.printStatus(); // ist jetzt unterwegs
			k.printStatus(); // ist jetzt unterwegs
			// Mitarbeiter 1 ist am 7.Tag zurueck
			Rechnung re = fuhrpark.fahrtAbrechnen(f, 7);
			re.printStatus();
			m.printStatus();
			k.printStatus();
		}*/
	}
}