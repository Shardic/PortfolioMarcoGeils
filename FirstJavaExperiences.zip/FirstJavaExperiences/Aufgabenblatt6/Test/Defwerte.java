public class Defwerte {
	private int alter;
	char[] a = new char[6];
	public void test() {
		System.out.println(alter);
		for (char blub : a) {
			System.out.println(blub);
		}
	}

	public static void main(String[] args) {
		Defwerte d = new Defwerte();
		d.test();
	}
}