class ArraytestSecond {

	private int x = 154;
	private int y = 54;
	
	private char[][] xx = new char[y][x];
	
	public void print() {
			for (int i = 0; i<xx.length; i++) {
				for (int j = 0; j<xx[i].length; j++) {
					xx[i][j] = 'x';
				}
			}
			for (int k = 0; k<xx.length; k++) {
				for (int l = 0; l<xx[k].length; l++) {
					System.out.print(xx[k][l]);
				}			
				System.out.println();
			}
	}

	public static void main(String[] args) {
		ArraytestSecond a = new ArraytestSecond();
		a.print();
	}
}
