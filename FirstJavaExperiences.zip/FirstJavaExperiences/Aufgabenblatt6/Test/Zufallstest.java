class Zufallstest {

	public void testen() {
		int x = 0;
		while (x <= 50) {
			int zufallszahl = myRandom(1,10); 							// mit 0,2 gibt Random entweder 0 oder 1 zurueck 			
			System.out.println("zufallszahl ist " + zufallszahl);		// bei nur einem Unterschied gibt er immer das a zurueck
			x++;														// mit 1,3 gibt er 1 oder 2 aus
		}																// es scheint zuf�llig eine Zahl zwischen dem a und genau ein vor b herauszukommen
	}
	
	
	public int myRandom(int a, int b) {
		return (int) (Math.random() * (b - a) + a);
	}
	

	public static void main(String[] args) {
		Zufallstest a = new Zufallstest();
		a.testen();
	}
}