public class Arraytest {
public static void main(String[] args) {
int[] vektor1 = { 1, 2, 3 };
int[] vektor2 = { 1, 2, 3 };
if (vektor1 == vektor2) {
System.out.println("Die Arrays sind gleich.");
}
else {
System.out.println("Die Arrays sind nicht gleich.");
}
}
}
