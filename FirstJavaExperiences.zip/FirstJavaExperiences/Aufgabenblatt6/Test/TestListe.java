public class TestListe {
	private char derChar;
	
	public void setChar(char x) {
		this.derChar = x;
	}
	
	public char getChar() {
		return this.derChar;
	}




}