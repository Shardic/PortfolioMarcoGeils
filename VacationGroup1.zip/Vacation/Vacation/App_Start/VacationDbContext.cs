﻿using Microsoft.AspNet.Identity.EntityFramework;
using System.Data.Entity;
using Vacation.Models;
using System.Collections.Generic;

namespace Vacation.Models
{
    public class VacationDbContext : IdentityDbContext<IdentityUser>
    {
        // Specify the "tables" you want to use.

        public DbSet<Memory> Memories { get; set; }
        public DbSet<Media> Medias { get; set; }
        public DbSet<User> User { get; set; }
        public DbSet<Vacation> Vacations { get; set; }
        public VacationDbContext() : base("AuthContext"){}
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<User>().HasMany(u => u.friends).WithMany();
            modelBuilder.Entity<User>().HasMany(u => u.vacations).WithMany();
            modelBuilder.Entity<Vacation>().HasMany(v => v.memories).WithMany();
            modelBuilder.Entity<IdentityUser>().ToTable("AspNetUsers");
        }
    }
}