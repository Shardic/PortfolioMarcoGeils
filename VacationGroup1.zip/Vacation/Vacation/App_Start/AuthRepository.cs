﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Vacation.Models;

namespace Vacation.App_Start
{
    public class AuthRepository : IDisposable
    {
        private VacationDbContext _ctx;

        private UserManager<IdentityUser> _userManager;

        public AuthRepository()
        {
            _ctx = new VacationDbContext();
            _userManager = new UserManager<IdentityUser>(new UserStore<IdentityUser>(_ctx));
        }

        public async Task<IdentityResult> RegisterUser(Models.Account userAccount)
        {
            IdentityUser user = new IdentityUser
            {
                UserName = userAccount.username
            };

            var result = new IdentityResult();
            result = await _userManager.CreateAsync(user, userAccount.password);

            return result;
        }

        public void updateUser(string theUserId, string newName)
        {
            IdentityUser updatingUser = this.FindUserById(theUserId);
            updatingUser.UserName = newName;
            _userManager.Update(updatingUser);
        }

        public async Task<IdentityUser> FindUser(string userName, string password)
        {
            IdentityUser user = await _userManager.FindAsync(userName, password);
            return user;
        }

        public IdentityUser FindUserById(string userId)
        {
            IdentityUser user = _userManager.FindById(userId);
            return user;
        }


        public async Task<IdentityResult> deleteUser(IdentityUser theUser)
        {
            IdentityResult result = _userManager.Delete(theUser);
            return result;
        }

        public void Dispose()
        {
            _ctx.Dispose();
            _userManager.Dispose();

        }
    }
}