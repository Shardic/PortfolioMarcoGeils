﻿using NamespaceControllerSelectorSample;
using Newtonsoft.Json.Serialization;
using System;
using System.Linq;
using System.Net.Http.Formatting;
using System.Web.Http;
using System.Web.Http.Dispatcher;


namespace Vacation
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web-API-Konfiguration und -Dienste
                        

                      // Web-API-Routen
                      config.MapHttpAttributeRoutes();

            //substitutes the IHttpControllerSelector with an selector who regards the versioning in the namespace
            config.Services.Replace(typeof(IHttpControllerSelector),
            new NamespaceHttpControllerSelector(config));

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{namespace}/{controller}/{id}/{option}/{secondOption}",
                defaults: new { id = RouteParameter.Optional, option = RouteParameter.Optional, secondOption = RouteParameter.Optional}                
            );
            var jsonFormatter = config.Formatters.OfType<JsonMediaTypeFormatter>().First();
            jsonFormatter.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
        }
    }
}

