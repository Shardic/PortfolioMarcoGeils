﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vacation.Models
{
    public class Media
    {
        public int id { get; set; }
        public string fileUrl { get; set; }
        public string container { get; set; }
    }
}