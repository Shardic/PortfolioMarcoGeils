﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vacation.Models
{
    public class PictureMedia : Media
    {
        public int width { get; set; }
        public int height { get; set; }
    }
}