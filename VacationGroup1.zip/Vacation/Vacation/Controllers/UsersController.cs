﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Vacation.Models;
using System.Threading.Tasks;
using Vacation.App_Start;
using System.Web;

namespace Vacation.Controllers.v1
{
    public class UsersController : ApiController
    {
        private AuthRepository _repo;

        [Authorize]
        //Implemented
        // GET: api/v1/users/id    (id is the searched username) 
        //Returns the User as a JSON Object with the username which is filled in in the id part of the URL 
        //If the User doesnt exist an Error Response is returned 
        public HttpResponseMessage Get(string id)
        {
            using (var db = new VacationDbContext())
            {
                var L2EQuery = db.User.Include("friends").Include("vacations").Where(s => s.username == id);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                if (foundUser == null)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Was not able to find the User with the name " + id);
                }
                else if (foundUser != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, foundUser);
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Unexpected Exception occured");
                }
            }
        }

        [Authorize]
        //Implemented
        // PUT: api/User/5
        public HttpResponseMessage Put(string id, [FromBody] User updatedUser)
        {
            using (var db = new VacationDbContext())
            {
                var L2EQuery = db.User.Where(s => s.username == id);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                if (foundUser == null)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Was not able to find the User with the name " + id);
                }
                else if (foundUser != null)
                {
                    if (User.Identity.GetUserName() == foundUser.username)
                    {
                        if (updatedUser.username == null)
                        {
                            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "The User needs a username");
                        }
                        else if (checkAvailableUsername(updatedUser.username))
                            {
                                _repo = new AuthRepository();
                                _repo.updateUser(foundUser.identity, updatedUser.username);
                                foundUser.firstName = updatedUser.firstName;
                                foundUser.lastName = updatedUser.lastName;
                                foundUser.username = updatedUser.username;
                                foundUser.email = updatedUser.email;
                                db.SaveChanges();
                                return Request.CreateResponse(HttpStatusCode.OK, "The Userprofil is updated. Please get a new Token.");
                            }
                            else
                            {
                                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "The Username is already taken by another user consider using the old Username of the user");
                            }
                        } else
                        {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Cant change User data from another User!");
                        }
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Unexpected Exception occured");
                }
            }
        }

        [Authorize]
        //Implemented
        //PATCH: api/v1/users/<username>
        public HttpResponseMessage Patch(string id, [FromBody] User updatedUser)
        {
            using (var db = new VacationDbContext())
            {
                var L2EQuery = db.User.Where(s => s.username == id);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                if (User.Identity.GetUserName() == foundUser.username)
                {
                    if (foundUser == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Was not able to find the User with the name " + id);
                    }
                    if (foundUser != null)
                    {
                        if (updatedUser.firstName != null)
                        {
                            foundUser.firstName = updatedUser.firstName;
                        }
                        if (updatedUser.lastName != null)
                        {
                            foundUser.lastName = updatedUser.lastName;
                        }
                        if (updatedUser.username != null)
                        {
                            foundUser.username = updatedUser.username;
                            _repo = new AuthRepository();
                            _repo.updateUser(foundUser.identity, updatedUser.username);
                        }
                        if (updatedUser.email != null)
                        {
                            foundUser.email = updatedUser.email;
                        }
                        db.SaveChanges();
                        return Request.CreateResponse(HttpStatusCode.OK);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Unexpected Exception occured");
                    }
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Cant update the User Data from another User.");
                }
            }
        }

        [Authorize]
        // GET: api/v1/users/<username>/friends
        //Implemented
        public HttpResponseMessage Get(string id, string option)
        {
            using (var db = new VacationDbContext())
            { 
                var L2EQuery = db.User.Include("friends").Include("vacations").Where(s => s.username == id);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                if (option.Equals("friends"))
                {
                    if (foundUser == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Was not able to find the User with the name " + id);
                    }
                    else if (foundUser != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, foundUser.friends);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Unexpected Exception occured");
                    }
                }
                else if (option.Equals("vacations"))
                {
                    if (foundUser == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Was not able to find the User with the name " + id);
                    }
                    else if (foundUser != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, foundUser.vacations);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Unexpected Exception occured");
                    }
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "The Url " + option + "is not valid");
                }
            }
        }

        [Authorize]
        //Implemented!
        //Adds a user as a friend. To add a user as a friend put him as { "username" : "aaa" } in the body
        public HttpResponseMessage Post(string id, string option, [FromBody] Models.User friendName)
        {
            using (var db = new VacationDbContext())
            {
                var L2EQuery = db.User.Include("friends").Where(s => s.username == id);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                if (foundUser == null)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Was not able to find the User with the name " + id);
                }
                else if (foundUser != null)
                {
                    if (User.Identity.GetUserName() == foundUser.username)
                    {
                        var Query1 = db.User.Where(s => s.username == friendName.username);
                        User newFriend = Query1.FirstOrDefault<User>();
                        if (newFriend != null)
                        {
                            foundUser.friends.Add(newFriend);
                            db.SaveChanges();
                            return Request.CreateResponse(HttpStatusCode.OK, "Added " + friendName.username + " as a new Friend");
                        } else
                        {
                            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "There is no user with the username "+ friendName.username + ", so he cant be added as a friend.");
                        }
                    } else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Cant add User as friends to another User!");
                    }
                } else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Unexpected Exception occured");
                }
            }
        }

        [Authorize]
        //Implemented
        // DELETE: api/v1/users/<username>
        public HttpResponseMessage Delete(string id)
        {
            using (var db = new VacationDbContext())
            {
                string identityUsername = User.Identity.GetUserName();
                //With these Querys it is ensured that only the actual User has the Vacation
                var L2EQuery = db.User.Include("vacations").Include("vacations.memories").Include("vacations.memories.medias").Where(u => u.username == identityUsername);
                User validUser = L2EQuery.FirstOrDefault<User>();
                foreach (var vac in validUser.vacations )
                {
                    foreach (var memo in vac.memories)
                    {
                        foreach (var media in memo.mediasList)
                        {
                            db.Medias.Remove(media);
                            //TODO: maybe add that the S3 Data gets deleted -> not in specification
                        }
                            
                        db.Memories.Remove(memo);
                    }
                    db.Vacations.Remove(vac);
                }
                db.User.Remove(validUser);
                db.SaveChanges();

                return Request.CreateResponse(HttpStatusCode.OK, "The User is deleted.");

            }
        }

        [Authorize]
        //Implemented
        // DELETE: api/v1/users/<username>/friends/<friendsUsername>
        // deletes the friend in the second option as a friend from the user with the <username>
        public HttpResponseMessage Delete(string id, string option, string secondOption)
        {
            if (option.Equals("friends"))
            {
                using (var db = new VacationDbContext())
                {
                    var L2EQuery = db.User.Include("friends").Where(s => s.username == id);
                    User foundUser = L2EQuery.FirstOrDefault<User>();
                    var L2EQuery2 = db.User.Include("friends").Where(s => s.username == option);
                    User friendToDelete = L2EQuery2.FirstOrDefault<User>();
                    if (User.Identity.GetUserName() == foundUser.username)
                    {
                        if (foundUser == null)
                        {
                            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Was not able to find the User with the name " + id);
                        }
                        else if (friendToDelete == null)
                        {
                            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "There is no User with the name " + secondOption);
                        }
                        else if (foundUser != null && friendToDelete != null)
                        {
                            foundUser.friends.Remove(friendToDelete);
                            db.SaveChanges();
                            return Request.CreateResponse(HttpStatusCode.OK, "Deleted " + secondOption + "from your friendlist.");
                        }
                        else
                        {
                            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Unexpected Exception occured");
                        }
                    } else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Cant delete friends from the friendlist of another User.");
                    }
                }
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "The option " + option + " is not valid.");
            }
        }

        private bool checkAvailableUsername(string newUsername)
        {
            using (var db = new VacationDbContext())
            {
                var L2EQuery = db.User.Where(s => s.username == newUsername);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                if (foundUser != null)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
    }
}