﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Vacation.Models;

namespace Vacations.Controllers.v1
{
    public class VacationsController : ApiController
    {
        [Authorize]
        //Implemented
        // GET: api/v1/vacations
        //Returns vacations from the actual User and all of his friends
        public HttpResponseMessage Get()
        {
            List<Vacation.Models.Vacation> vacationsToReturn = new List<Vacation.Models.Vacation>(); 
            using (var db = new VacationDbContext())
            {
                string identityUsername = User.Identity.GetUserName();
                var L2EQuery = db.User.Include("vacations").Include("friends").Where(s => s.username == identityUsername);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                var L2EQuery2 = db.User.Include("vacations").Include("friends").Where(u => u.username == foundUser.username || u.friends.Any(m => m.username == foundUser.username)).ToList();
                List<User> allValidUsers = L2EQuery2;
                if (User.Identity.GetUserName() == foundUser.username)
                {
                        foreach (var user in allValidUsers)
                        {
                            foreach (var vac in user.vacations)
                            {
                                vacationsToReturn.Add(vac);
                            }
                        }
                        return Request.CreateResponse(HttpStatusCode.OK, vacationsToReturn);
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something with the Identity Check is wrong!");
                }
            }
        }

        [Authorize]
        //Implemented
        // GET: api/v1/vacations/<id>
        public HttpResponseMessage Get(int id)
        {
            using (var db = new VacationDbContext())
            {
                string identityUsername = User.Identity.GetUserName();
                var L2EQuery = db.User.Include("vacations").Include("friends").Where(s => s.username == identityUsername);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                var L2EQuery2 = db.User.Include("vacations").Include("friends").Where(u => u.username == foundUser.username && u.vacations.Any(v => v.id == id) || u.friends.Any(m => m.username == foundUser.username && m.vacations.Any(va => va.id == id))).ToList();
                User validUser = L2EQuery2.FirstOrDefault<User>();
                if (validUser == null)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You cant look at this vacation either it doesnt exist or the owner of it isnt your friend.");
                } else
                {
                    Vacation.Models.Vacation vacationToReturn = validUser.vacations.Single(v => v.id == id);
                    return Request.CreateResponse(HttpStatusCode.OK, vacationToReturn);
                }
            }
        }

        [Authorize]
        // Implemented
        // POST: api/v1/vacations
        public HttpResponseMessage Post([FromBody] Vacation.Models.Vacation newVacation)
        {
            using (var db = new VacationDbContext())
            {
                string identityUsername = User.Identity.GetUserName();
                var L2EQuery = db.User.Include("vacations").Where(s => s.username == identityUsername);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                // No Identity Check neccessary because it would have been rejected earlier from Oauth
                //Also allowed to construct empty vacations because the User can Update them later on... 
                foundUser.vacations.Add(newVacation);
                db.SaveChanges();
                return Request.CreateResponse(HttpStatusCode.OK, "Created a new Vacation for you, " + User.Identity.GetUserName() + "!");
            }
        }

        [Authorize]
        //Implemented
        // PUT: api/Vacation/5
        public HttpResponseMessage Put(int id, [FromBody]Vacation.Models.Vacation updatedVacation)
        {
            using (var db = new VacationDbContext())
            {
                string identityUsername = User.Identity.GetUserName();
                //With these Querys it is ensured that only the actual User has the Vacation
                var L2EQuery = db.User.Include("vacations").Where(u => u.username == identityUsername && u.vacations.Any(v => v.id == id));
                User validUser = L2EQuery.FirstOrDefault<User>();
                if (validUser == null)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You cant access this vacation, it isnt yours.");
                }
                else
                {
                    var L2EQuery2 = db.Vacations.Include("vacations").Where(v => v.id == id);
                    Vacation.Models.Vacation vacationToUpdate = L2EQuery2.FirstOrDefault<Vacation.Models.Vacation>();
                    vacationToUpdate.title = updatedVacation.title;
                    vacationToUpdate.description = updatedVacation.description;
                    vacationToUpdate.place = updatedVacation.place;
                    vacationToUpdate.start = updatedVacation.start;
                    vacationToUpdate.end = updatedVacation.end;
                    db.SaveChanges();
                    return Request.CreateResponse(HttpStatusCode.OK, "Your Vacation got updated.");
                }
            }
        }

        [Authorize]
        //Implemented
        // PATCH: api/v1/vacations/<id>
        public HttpResponseMessage Patch(int id,[FromBody]Vacation.Models.Vacation updatedVacation)
        {
            using (var db = new VacationDbContext())
            {
                string identityUsername = User.Identity.GetUserName();
                //With these Querys it is ensured that only the actual User has the Vacation
                var L2EQuery = db.User.Include("vacations").Where(u => u.username == identityUsername && u.vacations.Any(v => v.id == id));
                User validUser = L2EQuery.FirstOrDefault<User>();
                if (validUser == null)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You cant access this vacation, it isnt yours.");
                }
                else
                {
                    var L2EQuery2 = db.Vacations.Include("vacations").Where(v => v.id == id);
                    Vacation.Models.Vacation vacationToUpdate = L2EQuery2.FirstOrDefault<Vacation.Models.Vacation>();
                    if (updatedVacation.title != null)
                    {
                        vacationToUpdate.title = updatedVacation.title;
                    } if (updatedVacation.description != null)
                    {
                        vacationToUpdate.description = updatedVacation.description;
                    } if (updatedVacation.place != null) {
                        vacationToUpdate.place = updatedVacation.place;
                    } if (updatedVacation != null)
                    {
                        vacationToUpdate.start = updatedVacation.start;
                    } if (updatedVacation != null)
                    {
                        vacationToUpdate.end = updatedVacation.end;
                    }
                    db.SaveChanges();
                    return Request.CreateResponse(HttpStatusCode.OK, "Your Vacation got patched.");
                }
            }
        }

        [Authorize]
        //Implemented 
        // DELETE: api/v1/vacations/<id>
        public HttpResponseMessage Delete(int id)
        {
            using (var db = new VacationDbContext())
            {
                string identityUsername = User.Identity.GetUserName();
                //With these Querys it is ensured that only the actual User has the Vacation
                var L2EQuery = db.User.Include("vacations").Where(u => u.username == identityUsername && u.vacations.Any(v => v.id == id));
                User validUser = L2EQuery.FirstOrDefault<User>();
                if (validUser == null)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You cant access this vacation, it isnt yours.");
                }
                else
                {
                    var L2EQuery2 = db.Vacations.Include("memories").Include("memories.mediasList").Where(v => v.id == id);
                    Vacation.Models.Vacation vacationToDelete = L2EQuery2.FirstOrDefault<Vacation.Models.Vacation>();
                    foreach(var mem in vacationToDelete.memories)
                    {
                        foreach(var media in mem.mediasList)
                        {
                            db.Medias.Remove(media);
                        }
                        db.Memories.Remove(mem);
                    }
                    db.Vacations.Remove(vacationToDelete);
                    db.SaveChanges();
                    return Request.CreateResponse(HttpStatusCode.OK, "Your Vacation got deleted.");
                }
            }
        }

        [Authorize]
        //Implemented
        //POST: /api/v1/vacations/<id>/memories
        public HttpResponseMessage Post(int id, string option, [FromBody]Memory createdMemory)
        {
            if (option == "memories")
            {
                using (var db = new VacationDbContext())
                {
                    string identityUsername = User.Identity.GetUserName();
                    //With these Querys it is ensured that only the actual User has the Vacation
                    var L2EQuery = db.User.Include("vacations").Where(u => u.username == identityUsername && u.vacations.Any(v => v.id == id));
                    User validUser = L2EQuery.FirstOrDefault<User>();
                    if (validUser == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You cant create memories for this vacation, it isnt yours.");
                    }
                    else
                    {
                        var L2EQuery2 = db.Vacations.Include("memories").Where(v => v.id == id);
                        Vacation.Models.Vacation theVacation = L2EQuery2.FirstOrDefault<Vacation.Models.Vacation>();
                        theVacation.memories.Add(createdMemory);
                        db.SaveChanges();
                        return Request.CreateResponse(HttpStatusCode.OK, "Created a memory for the vacation.");
                    }
                }
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "This is an invalid URL, try it with memories at the end.");
            }
        }

        [Authorize]
        //Implemented
        // GET: api/v1/vacations/<id>/memories
        public HttpResponseMessage Get(int id, string option)
        {
            if (option == "memories")
            {
                using (var db = new VacationDbContext())
                {
                    string identityUsername = User.Identity.GetUserName();
                    var L2EQuery = db.User.Include("vacations").Include("friends").Where(s => s.username == identityUsername);
                    User foundUser = L2EQuery.FirstOrDefault<User>();
                    var L2EQuery2 = db.User.Include("vacations").Include("friends").Where(u => u.username == foundUser.username && u.vacations.Any(v => v.id == id) || u.friends.Any(m => m.username == foundUser.username && m.vacations.Any(va => va.id == id))).ToList();
                    User validUser = L2EQuery2.FirstOrDefault<User>();
                    if (validUser == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You cant look at this vacation either it doesnt exist or the owner of it isnt your friend.");
                    }
                    else
                    {
                        var L2EQuery3 = db.Memories.Where(m => m.id == id);
                        Memory memoryToReturn = L2EQuery3.FirstOrDefault<Memory>();
                        return Request.CreateResponse(HttpStatusCode.OK, memoryToReturn);
                    }
                }
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "This is an invalid URL, try it with memories at the end.");
            }
        }
    }
}
