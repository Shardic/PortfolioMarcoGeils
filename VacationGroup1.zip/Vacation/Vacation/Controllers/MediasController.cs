﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Vacation.Models;

namespace Vacation.Controllers.v1
{
    public class MediasController : ApiController
    {
        [Authorize]
        //Implemented 
        //TODO: maybe add that the S3 Data gets deleted
        // DELETE: api/v1/medias/<id>
        public HttpResponseMessage Delete(int id)
        {
            using (var db = new VacationDbContext())
            {
                string identityUsername = User.Identity.GetUserName();
                var L2EQuery = db.User.Include("vacations").Where(s => s.username == identityUsername);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                var L2EQuery2 = db.User.Include("vacations").Include("vacations.memories").Include("vacations.memories.mediasList").Where(u => u.username == foundUser.username && u.vacations.Any(v => v.memories.Any(m => m.mediasList.Any(med => med.id == id))));
                User validUser = L2EQuery2.FirstOrDefault<User>();
                if (validUser == null)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You cant delete this media, you are not the right user");
                }
                else
                {
                    Vacation.Models.Vacation vacationToReturn = validUser.vacations.Single(v => v.memories.Any(m => m.mediasList.Any(med => med.id == id)));
                    Memory memoryToReturn = vacationToReturn.memories.Single(m => m.mediasList.Any(med => med.id == id));
                    Media mediaToRemove = memoryToReturn.mediasList.Single(m => m.id == id);
                    db.Medias.Remove(mediaToRemove);
                    db.SaveChanges();
                    return Request.CreateResponse(HttpStatusCode.OK, "deleted the media");
                }
            }
        }
    }
}
