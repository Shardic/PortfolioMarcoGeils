﻿using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using Vacation.Models;

namespace Vacation.Controllers.v1
{
    public class MemoriesController : ApiController
    {
        [Authorize]
        //Implemented
        //api/v1/memories/search? type =< type > &q =< query >
        public HttpResponseMessage Get([FromUri] string type, [FromUri] string q)
        {
            List<Memory> memoriesToReturn = new List<Memory>();
            using (var db = new VacationDbContext())
            {
                string identityUsername = User.Identity.GetUserName();
                var L2EQuery = db.User.Include("vacations").Include("friends").Where(s => s.username == identityUsername);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                var L2EQuery2 = db.User.Include("vacations").Include("friends").Include("vacations.memories").Where(u => u.username == foundUser.username && u.vacations.Any(v => v.memories.Count >= 0) || u.friends.Any(m => m.username == foundUser.username) && u.vacations.Any(v => v.memories.Count >= 0)).ToList();
                List<User> allValidUsers = L2EQuery2;
                if (type == "user")
                {
                    foreach (var u in allValidUsers)
                    {
                        if (u.username == q)
                        {
                            foreach (var v in u.vacations)
                            {
                                foreach (var m in v.memories)
                                {
                                    memoriesToReturn.Add(m);
                                }
                            }
                        }
                    }
                    if (memoriesToReturn.Count == 0)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Didnt find any memories.");
                    }
                    else
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, memoriesToReturn);
                    }
                }
                else if (type == "place")
                {
                    foreach (var u in allValidUsers)
                    {
                        foreach (var v in u.vacations)
                        {
                            foreach (var m in v.memories)
                            {
                                if (m.place == q)
                                {
                                    memoriesToReturn.Add(m);
                                }
                            }
                        }
                    }
                    if (memoriesToReturn.Count == 0)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Didnt find any memories.");
                    }
                    else
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, memoriesToReturn);
                    }
                }
                else if (type == "title")
                {
                    foreach (var u in allValidUsers)
                    {
                        foreach (var v in u.vacations)
                        {
                            foreach (var m in v.memories)
                            {
                                if (m.title == q)
                                {
                                    memoriesToReturn.Add(m);
                                }
                            }
                        }
                    }
                    if (memoriesToReturn.Count == 0)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Didnt find any memories.");
                    }
                    else
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, memoriesToReturn);
                    }
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "This is not a valid type. You can look for type user, place or title.");
                }
            }
        }

        [Authorize]
        //Implemented
        //GET:
        public HttpResponseMessage Get(int id)
        {
            using (var db = new VacationDbContext())
            {
                string identityUsername = User.Identity.GetUserName();
                var L2EQuery = db.User.Include("vacations").Include("friends").Where(s => s.username == identityUsername);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                var L2EQuery2 = db.User.Include("vacations").Include("friends").Include("vacations.memories").Where(u => u.username == foundUser.username && u.vacations.Any(v => v.memories.Any(m => m.id == id)) || u.friends.Any(m => m.username == foundUser.username) && u.vacations.Any(v => v.memories.Any(m => m.id == id)));
                User validUser = L2EQuery2.FirstOrDefault<User>();
                if (validUser == null)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You cant look at this memory. Either it doesnt exist or the owner of it isnt your friend.");
                }
                else
                {
                    Vacation.Models.Vacation memoVac = validUser.vacations.Single(v => v.memories.Any(m => m.id == id));
                    Memory memoryToReturn = memoVac.memories.Single(m => m.id == id);
                    return Request.CreateResponse(HttpStatusCode.OK, memoryToReturn);
                }
            }
        }

        [Authorize]
        //Implemented
        //api/v1/memories/<id>
        public HttpResponseMessage Delete(int id)
        {
            using (var db = new VacationDbContext())
            {
                string identityUsername = User.Identity.GetUserName();
                var L2EQuery = db.User.Include("vacations").Include("friends").Where(s => s.username == identityUsername);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                var L2EQuery2 = db.User.Include("vacations").Include("friends").Include("vacations.memories").Include("vacations.memories.mediasList").Where(u => u.username == foundUser.username && u.vacations.Any(v => v.memories.Any(m => m.id == id)));
                User validUser = L2EQuery2.FirstOrDefault<User>();
                if (validUser == null)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You cant delete this memory it isnt yours.");
                }
                else
                {
                    Vacation.Models.Vacation memoVac = validUser.vacations.Single(v => v.memories.Any(m => m.id == id));
                    Memory memoryToRemove = memoVac.memories.Single(m => m.id == id);
                    db.Memories.Remove(memoryToRemove);
                    foreach (var media in memoryToRemove.mediasList)
                    {
                        db.Medias.Remove(media);
                        //TODO: Specification is fullfiled but the Files from S3 dont get Deleted here
                    }
                    db.SaveChanges();
                    return Request.CreateResponse(HttpStatusCode.OK, "delted the Memory");
                }
            }
        }

        [Authorize]
        //Implemented
        // GET: api/v1/memories/<id>/media-objects
        public HttpResponseMessage Get(int id, string option)
        {
            if (option.Equals("media-objects")) {
                using (var db = new VacationDbContext())
                {
                    string identityUsername = User.Identity.GetUserName();
                    var L2EQuery = db.User.Include("vacations").Where(s => s.username == identityUsername);
                    User foundUser = L2EQuery.FirstOrDefault<User>();
                    var L2EQuery2 = db.User.Include("vacations").Include("friends").Include("vacations.memories").Include("vacations.memories.mediasList").Where(u => u.username == foundUser.username && u.vacations.Any(v => v.memories.Any(m => m.mediasList.Any(med => med.id == id))) || u.friends.Any(m => m.username == foundUser.username) && u.vacations.Any(v => v.memories.Any(m => m.mediasList.Any(med => med.id == id))));
                    User validUser = L2EQuery2.FirstOrDefault<User>();
                    if (validUser == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You cant access this media, you are not the friend of the person owning this media data");
                    }
                    else
                    {
                        Vacation.Models.Vacation vacationToReturn = validUser.vacations.Single(v => v.memories.Any(m => m.mediasList.Any(med => med.id == id)));
                        Memory memoryToReturn = vacationToReturn.memories.Single(m => m.mediasList.Any(med => med.id == id));
                        Media mediaToReturn = memoryToReturn.mediasList.Single(m => m.id == id);
                        return Request.CreateResponse(HttpStatusCode.OK, mediaToReturn);
                    }
                }
            } else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest,  option + " is not a Valid URL, try adding media-objects at the end instead");
            }
        }


        [Authorize]
        //Implemented
        //FileURL in the model will be the File name -> So it is easyer to retrieve the Files from the S3 wen the keyName is also the File name
        //POST: api/v1/memories/<id>/sounds or pictures or  
        public async Task<HttpResponseMessage> Post(int id, string option, [FromUri] SoundMedia sound, [FromUri] PictureMedia picture, [FromUri] VideoMedia video)
        {
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }
            using (var db = new VacationDbContext())
            {
                string identityUsername = User.Identity.GetUserName();
                var L2EQuery = db.User.Include("vacations").Include("friends").Include("vacations.memories").Where(s => s.username == identityUsername);
                User foundUser = L2EQuery.FirstOrDefault<User>();
                var L2EQuery2 = db.User.Include("vacations").Include("friends").Include("vacations.memories").Include("vacations.memories.mediasList").Where(u => u.username == foundUser.username && u.vacations.Any(v => v.memories.Any(m => m.id == id)));
                User validUser = L2EQuery2.FirstOrDefault<User>();
                if (validUser == null)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You cant post a file at a memory from another user!");
                }
                else
                {
                    Vacation.Models.Vacation vacationWithMemo = foundUser.vacations.Single(theV => theV.memories.Any(m => m.id == id));
                    Memory memorie = vacationWithMemo.memories.Single(theM => theM.id == id);
                    if (memorie == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "The memory does not exist!");
                    }
                    else
                    {
                        if (option.Equals("sounds"))
                        {
                            string root = HttpContext.Current.Server.MapPath("~/App_Data");
                            var provider = new MultipartFormDataStreamProvider(root);

                            var task = Request.Content.ReadAsMultipartAsync(provider).
                            ContinueWith<HttpResponseMessage>(t =>
                            {
                            if (t.IsFaulted || t.IsCanceled)
                            {
                                Request.CreateErrorResponse(HttpStatusCode.InternalServerError, t.Exception);
                            }

                                if (provider.FileData.Count > 1)
                                {
                                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You only can upload one file at a time.");
                                }
                                else
                                {
                                    MultipartFileData file = provider.FileData.FirstOrDefault<MultipartFileData>();
                                    string mainName = file.Headers.ContentDisposition.FileName; //That is stored as the file url in the Database
                                    mainName = mainName.Trim(new Char[] { '"' });
                                    string filename = mainName + RandomString(100);
                                    SoundMedia soundToSave = new SoundMedia();
                                    soundToSave.fileUrl = filename;
                                    if (sound.container != null)
                                    {
                                        soundToSave.container = sound.container;
                                    }
                                    if (sound.duration != 0)
                                    {
                                        soundToSave.duration = sound.duration;
                                    }
                                    if (sound.codec != null)
                                    {
                                        soundToSave.codec = sound.codec;
                                    }
                                    if (sound.bitRate != 0)
                                    {
                                        soundToSave.bitRate = sound.bitRate;
                                    }
                                    if (sound.channels != 0)
                                    {
                                        soundToSave.channels = sound.channels;
                                    }
                                    if (sound.samplingRate != 0)
                                    {
                                        soundToSave.samplingRate = sound.samplingRate;
                                    }
                                    string bucketName = "swedishvacationbucket";
                                    string awsAccessKeyId = "AKIAJAKDD7746KQNFCTQ"; //<--TASK: Access Data from Marco Geils please change 
                                    string awsSecretAccessKey = "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";
                                    using (var client = new AmazonS3Client(
                                     awsAccessKeyId,
                                     awsSecretAccessKey,
                                     Amazon.RegionEndpoint.EUCentral1))
                                    {
                                        client.PutObject(new PutObjectRequest()
                                        {
                                            FilePath = file.LocalFileName,
                                            BucketName = bucketName,
                                            Key = filename // <---File URL
                                        });
                                    }
                                    memorie.mediasList.Add(soundToSave);
                                    db.SaveChanges();
                                }
                                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "The Sound is uploaded to S3");
                            });
                            return await task;
                        } else if (option.Equals("pictures"))
                        {
                            string root = HttpContext.Current.Server.MapPath("~/App_Data");
                            var provider = new MultipartFormDataStreamProvider(root);

                            var task = Request.Content.ReadAsMultipartAsync(provider).
                            ContinueWith<HttpResponseMessage>(t =>
                            {
                                if (t.IsFaulted || t.IsCanceled)
                                {
                                    Request.CreateErrorResponse(HttpStatusCode.InternalServerError, t.Exception);
                                }

                                if (provider.FileData.Count > 1)
                                {
                                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You only can upload one file at a time.");
                                }
                                else
                                {
                                    MultipartFileData file = provider.FileData.FirstOrDefault<MultipartFileData>();
                                    string mainName = file.Headers.ContentDisposition.FileName; //That is stored as the file url in the Database
                                    mainName = mainName.Trim(new Char[] { '"' });
                                    string filename = mainName + RandomString(100);
                                    PictureMedia pictureToSave = new PictureMedia();
                                    pictureToSave.fileUrl = filename;
                                    if (picture.container != null)
                                    {
                                        pictureToSave.container = picture.container;
                                    }
                                    if (picture.width != 0)
                                    {
                                        pictureToSave.width = picture.width;
                                    } if (picture.height != 0)
                                    {
                                        pictureToSave.height = picture.height;
                                    }
                                    memorie.mediasList.Add(pictureToSave);
                                    db.SaveChanges();
                                    string bucketName = "swedishvacationbucket";
                                    string awsAccessKeyId = "AKIAJAKDD7746KQNFCTQ"; //<--TASK: Access Data from Marco Geils please change 
                                    string awsSecretAccessKey = "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";
                                    using (var client = new AmazonS3Client(
                                     awsAccessKeyId,
                                     awsSecretAccessKey,
                                     Amazon.RegionEndpoint.EUCentral1))
                                    {
                                        client.PutObject(new PutObjectRequest()
                                        {
                                            FilePath = file.LocalFileName,
                                            BucketName = bucketName,
                                            Key = filename // <---File URL
                                        });
                                    }
                                }
                                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "The Picture is uploaded to S3");
                            });
                            return await task;
                        }
                        else if (option.Equals("videos"))
                        {
                            string root = HttpContext.Current.Server.MapPath("~/App_Data");
                            var provider = new MultipartFormDataStreamProvider(root);

                            var task = Request.Content.ReadAsMultipartAsync(provider).
                            ContinueWith<HttpResponseMessage>(t =>
                            {
                                if (t.IsFaulted || t.IsCanceled)
                                {
                                    Request.CreateErrorResponse(HttpStatusCode.InternalServerError, t.Exception);
                                }

                                if (provider.FileData.Count > 1)
                                {
                                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "You only can upload one file at a time.");
                                }
                                else
                                {
                                    MultipartFileData file = provider.FileData.FirstOrDefault<MultipartFileData>();
                                    string mainName = file.Headers.ContentDisposition.FileName; //That is stored as the file url in the Database
                                    mainName = mainName.Trim(new Char[] { '"' });
                                    string filename = mainName + RandomString(100);
                                    VideoMedia videoToSave = new VideoMedia();
                                    videoToSave.fileUrl = filename;
                                    if (video.container != null)
                                    {
                                        videoToSave.container = video.container;
                                    }
                                    if (video.videoCodec != null)
                                    {
                                        videoToSave.videoCodec = video.videoCodec;
                                    } if (video.videoBitRate != 0)
                                    {
                                        videoToSave.videoBitRate = video.videoBitRate;
                                    } if (video.width != 0)
                                    {
                                        videoToSave.width = video.width;
                                    } if (video.height != 0)
                                    {
                                        videoToSave.height = video.height;
                                    } if (video.frameRate != 0)
                                    {
                                        videoToSave.frameRate = video.frameRate;
                                    } if (video.audioCodec != null)
                                    {
                                        videoToSave.audioCodec = video.audioCodec;
                                    } if (video.audioBitRate != 0)
                                    {
                                        videoToSave.audioBitRate = video.audioBitRate;
                                    } if (video.channels != 0)
                                    {
                                        videoToSave.channels = video.channels;
                                    } if (video.samplingRate != 0)
                                    {
                                        videoToSave.samplingRate = video.samplingRate;
                                    }
                                    memorie.mediasList.Add(videoToSave);
                                    db.SaveChanges(); string bucketName = "swedishvacationbucket";
                                    string awsAccessKeyId = "AKIAJAKDD7746KQNFCTQ"; // TODO: Access Data from Marco Geils please change 
                                    string awsSecretAccessKey = "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";
                                    using (var client = new AmazonS3Client(
                                     awsAccessKeyId,
                                     awsSecretAccessKey,
                                     Amazon.RegionEndpoint.EUCentral1))
                                    {
                                        client.PutObject(new PutObjectRequest()
                                        {
                                            FilePath = file.LocalFileName,
                                            BucketName = bucketName,
                                            Key = filename // <---File URL
                                        });
                                    }
                                }
                                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "The Video is uploaded to S3");
                            });
                            return await task;
                        }
                        else
                        {
                            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "The URL isnt valid, you can only upload at sounds,pictures and videos.");
                        }
                    }
                }
            }
        }

        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}