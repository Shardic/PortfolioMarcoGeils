#ifndef HISTOGRAMCALCULATOR_H
#define HISTOGRAMCALCULATOR_H
#include "QImage"
#include "QObject"

class HistogramCalculator : QObject
{
    Q_OBJECT


public:
    HistogramCalculator();
    ~HistogramCalculator();
};

#endif // HISTOGRAMCALCULATOR_H
