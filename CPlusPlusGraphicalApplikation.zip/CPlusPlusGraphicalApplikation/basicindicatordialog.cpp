#include "basicindicatordialog.h"

BasicIndicatorDialog::BasicIndicatorDialog()
{

}
