#ifndef HISTOGRAM_H
#define HISTOGRAM_H
#include "QImage"
#include "QtWidgets/QMainWindow"
#include "QtCharts/QChartView"
#include "QtCharts/QBarSeries"
#include "QtCharts/QBarSet"
#include "QtCharts/QLegend"
#include "QtCharts/QBarCategoryAxis"
#include "QtCharts/QBarSet"
#include "QtCharts/QBarSeries"

QT_CHARTS_USE_NAMESPACE
class Histogram
{
public:
    Histogram();
    ~Histogram();

    void setImage(QImage* i);
    void calculateHistogram();
    void openHistogram();
    void safeAsTextFile();
private:
    QChart* chart = new QChart();
    QImage* image;
    int histogramArray[255];
};

#endif // HISTOGRAM_H
