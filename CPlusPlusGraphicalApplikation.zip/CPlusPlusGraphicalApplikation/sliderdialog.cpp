#include "sliderdialog.h"

SliderDialog::SliderDialog()
{

}
