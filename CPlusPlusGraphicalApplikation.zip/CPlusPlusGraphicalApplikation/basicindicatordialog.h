#ifndef BASICINDICATORDIALOG_H
#define BASICINDICATORDIALOG_H


class BasicIndicatorDialog
{
public:
    BasicIndicatorDialog();
};

#endif // BASICINDICATORDIALOG_H