#ifndef SLIDERDIALOG_H
#define SLIDERDIALOG_H


class SliderDialog
{
public:
    SliderDialog();
};

#endif // SLIDERDIALOG_H