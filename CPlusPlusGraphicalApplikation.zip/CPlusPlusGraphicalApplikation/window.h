#ifndef WINDOW_H
#define WINDOW_H
#include "QLabel"
#include "QImage"
#include "QScrollArea"
#include <QMainWindow>


namespace Ui {
class Window;
}

class Window : public QMainWindow
{
    Q_OBJECT

public:
    explicit Window(QWidget *parent = 0);
    ~Window();

    bool loadFile(QString &fileName);
    void setImage(QImage &newImage);

private slots:
    //File menu slots
    void open();

    //View menu slots
    void zoomIn();
    void zoomOut();
    void normalSize();
    void fitToWindow();

    //Tool menu slots
    void basicIndicators();
    void openHistogram();
    void smoothImage();
    void calculateGradiant();
    void thresholdImage();
    void calculateSizeOfObject();

private:
    Ui::Window *ui;

    QAction* openAction;
    QAction* exitAction;

    QAction* zoomInAction;
    QAction* zoomOutAction;
    QAction* normalSizeAction;
    QAction* fitToWindowAction;

    QAction* basicIndicatorAction;
    QAction* openHistogramAction;
    QAction* smoothImageAction;
    QAction* calculateGradiantAction;
    QAction* thresholdImageAction;
    QAction* calculateSizeOfObjectAction;

    QMenu* fileMenu;
    QMenu* viewMenu;
    QMenu* toolMenu;

    QImage image;
    QLabel* imageLabel;
    QScrollArea* scrollArea;

    double scaleFactor;

    void createActionsAndMenus();
    void changeWindowTitle(QString title);
    void updateActions();
    void enableToolActions();
    void scaleImage(double factor);
    void adjustScrollBar(QScrollBar *scrollBar, double factor);
};

#endif // WINDOW_H
