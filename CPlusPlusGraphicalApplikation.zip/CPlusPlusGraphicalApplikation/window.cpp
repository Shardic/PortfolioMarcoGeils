#include "window.h"
#include "ui_window.h"
#include "QScreen"
#include "QFileDialog"
#include "QImageReader"
#include "QScrollBar"
#include "QImageWriter"
#include "histogram.h"
#include "QStandardPaths"
#include "QMessageBox"
#include "basicindicatorcalculator.h"
#include "imagesmoother.h"
#include <QInputDialog>
#include <iostream>
#include <limits>

Window::Window(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Window),
    imageLabel(new QLabel),
    scrollArea(new QScrollArea),
    scaleFactor(1)
{
    ui->setupUi(this);
    changeWindowTitle(tr("Geils Picture Viewer"));

    imageLabel->setBackgroundRole(QPalette::Base);
    imageLabel->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
    imageLabel->setScaledContents(true);

    scrollArea->setBackgroundRole(QPalette::Dark);
    scrollArea->setWidget(imageLabel);
    scrollArea->setVisible(false);
    setCentralWidget(scrollArea);

    createActionsAndMenus();

    resize(QGuiApplication::primaryScreen()->availableSize() * 3 / 5);
}

Window::~Window()
{
    delete ui;
}

void Window::createActionsAndMenus() {

    openAction = new QAction(tr("&Open"), this);
    exitAction = new QAction(tr("&Exit"), this);

    connect(openAction,SIGNAL(triggered()),this,SLOT(open()));
    connect(exitAction,SIGNAL(triggered()),qApp,SLOT(quit()));

    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(openAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);

    zoomInAction = new QAction(tr("&Zoom in"), this);
    zoomInAction->setEnabled(false);
    zoomOutAction = new QAction(tr("&Zoom out"), this);
    zoomOutAction->setEnabled(false);
    normalSizeAction = new QAction(tr("&Scale to normal"), this);
    normalSizeAction->setEnabled(false);
    fitToWindowAction = new QAction(tr("&Scale to window"), this);
    fitToWindowAction->setCheckable(true);
    fitToWindowAction->setEnabled(false);

    connect(zoomInAction,SIGNAL(triggered()),this,SLOT(zoomIn()));
    connect(zoomOutAction,SIGNAL(triggered()),this,SLOT(zoomOut()));
    connect(normalSizeAction,SIGNAL(triggered()),this,SLOT(normalSize()));
    connect(fitToWindowAction,SIGNAL(triggered()),this,SLOT(fitToWindow()));

    viewMenu = menuBar()->addMenu(tr("&View"));
    viewMenu ->addAction(zoomInAction);
    viewMenu ->addAction(zoomOutAction);
    viewMenu ->addAction(normalSizeAction);
    viewMenu ->addAction(fitToWindowAction);

    basicIndicatorAction = new QAction(tr("&Open Basic Indicators"), this);
    basicIndicatorAction->setEnabled(false);
    openHistogramAction = new QAction(tr("&Histogram"), this);
    openHistogramAction->setEnabled(false);
    smoothImageAction = new QAction(tr("&Smooth Image"), this);
    smoothImageAction->setEnabled(false);
    calculateGradiantAction = new QAction(tr("&Calculate gradient"), this);
    calculateGradiantAction->setEnabled(false);
    thresholdImageAction = new QAction(tr("&Threshold"), this);
    thresholdImageAction->setEnabled(false);
    calculateSizeOfObjectAction = new QAction(tr("&Calculate Size"), this);
    calculateSizeOfObjectAction->setEnabled(false);

    connect(basicIndicatorAction,SIGNAL(triggered()),this,SLOT(basicIndicators()));
    connect(openHistogramAction,SIGNAL(triggered()),this,SLOT(openHistogram()));
    connect(smoothImageAction,SIGNAL(triggered()),this,SLOT(smoothImage()));
    connect(calculateGradiantAction,SIGNAL(triggered()),this,SLOT(calculateGradiant()));
    connect(thresholdImageAction,SIGNAL(triggered()),this,SLOT(thresholdImage()));
    connect(calculateSizeOfObjectAction,SIGNAL(triggered()),this,SLOT(calculateSizeOfObject()));

    toolMenu = menuBar()->addMenu(tr("&Tools"));
    toolMenu->addAction(basicIndicatorAction);
    toolMenu->addAction(openHistogramAction);
    toolMenu->addAction(smoothImageAction);
    toolMenu->addAction(calculateGradiantAction);
    toolMenu->addAction(thresholdImageAction);
    toolMenu->addAction(calculateSizeOfObjectAction);
}

void Window::changeWindowTitle(QString title) {
    this->setWindowTitle(title);
}

//took it from a tutorial (http://doc.qt.io/qt-5/qtwidgets-widgets-imageviewer-example.html)
static void openFileDialog(QFileDialog &dialog, QFileDialog::AcceptMode acceptMode) {

    static bool firstDialog = true;

    if (firstDialog) {
        firstDialog = false;
        const QStringList picturesLocations = QStandardPaths::standardLocations(QStandardPaths::PicturesLocation);
        dialog.setDirectory(picturesLocations.isEmpty() ? QDir::currentPath() : picturesLocations.last());
    }

    QStringList mimeTypeFilters;

    const QByteArrayList supportedMimeTypes = acceptMode == QFileDialog::AcceptOpen
        ? QImageReader::supportedMimeTypes() : QImageWriter::supportedMimeTypes();
    foreach (const QByteArray &mimeTypeName, supportedMimeTypes)
        mimeTypeFilters.append(mimeTypeName);

    mimeTypeFilters.sort();
    dialog.setMimeTypeFilters(mimeTypeFilters);
    dialog.selectMimeTypeFilter("image/jpeg");

    if (acceptMode == QFileDialog::AcceptSave)
        dialog.setDefaultSuffix("jpg");

}

void Window::open()
{
    QFileDialog dialog(this, tr("Open File"));
    openFileDialog(dialog, QFileDialog::AcceptOpen);

    while (dialog.exec() == QDialog::Accepted && !loadFile(dialog.selectedFiles().first())) {}
}

bool Window::loadFile(QString &fileName) {
    QImageReader reader(fileName);
    reader.setAutoTransform(true);
    QImage newImage = reader.read();
    if (newImage.isNull()) {
        QMessageBox::information(this, QGuiApplication::applicationDisplayName(),
                                 tr("Cannot load %1: %2")
                                 .arg(QDir::toNativeSeparators(fileName), reader.errorString()));
        return false;
    }
    setImage(newImage);

    const QString message = tr("\"%1\", %2x%3")
            .arg(QDir::toNativeSeparators(fileName)).arg(newImage.width()).arg(newImage.height());
    QLabel* statusLabel = new QLabel(message);
    statusBar()->addPermanentWidget(statusLabel);
    return true;
}

void Window::setImage(QImage &newImage) {

    imageLabel->setPixmap(QPixmap::fromImage(newImage));
    scaleFactor = 1.0;

    this->image = newImage;

    scrollArea->setVisible(true);
    fitToWindowAction->setEnabled(true);
    enableToolActions();
    updateActions();
    if (!fitToWindowAction->isChecked())
        imageLabel->adjustSize();
}

void Window::updateActions() {
    zoomInAction->setEnabled(!fitToWindowAction->isChecked());
    zoomOutAction->setEnabled(!fitToWindowAction->isChecked());
    normalSizeAction->setEnabled(!fitToWindowAction->isChecked());
}

void Window::enableToolActions() {
    basicIndicatorAction->setEnabled(true);
    openHistogramAction->setEnabled(true);
    smoothImageAction->setEnabled(true);
    calculateGradiantAction->setEnabled(true);
    thresholdImageAction->setEnabled(true);
    calculateSizeOfObjectAction->setEnabled(true);
}

void Window::scaleImage(double factor){
    scaleFactor *= factor;
    imageLabel->resize(scaleFactor * imageLabel->pixmap()->size());

    adjustScrollBar(scrollArea->horizontalScrollBar(), factor);
    adjustScrollBar(scrollArea->verticalScrollBar(), factor);
}

void Window::adjustScrollBar(QScrollBar *scrollBar, double factor){
    scrollBar->setValue(int(factor * scrollBar->value() + ((factor - 1) * scrollBar->pageStep()/2)));
}

void Window::zoomIn(){
    scaleImage(1.20);
}

void Window::zoomOut(){
    scaleImage(0.8);
}

void Window::normalSize() {
    imageLabel->adjustSize();
    scaleFactor = 1.0;
}

void Window::fitToWindow(){
    bool fitToWindow = fitToWindowAction->isChecked();
   scrollArea->setWidgetResizable(fitToWindow);
   if (!fitToWindow)
       normalSize();
   updateActions();
}

void Window::basicIndicators(){
    BasicIndicatorCalculator* bCalc = new BasicIndicatorCalculator();
    bCalc->setImage(&image);
    bCalc->calculate();
    bCalc->showIndicators();
}

void Window::openHistogram(){
    Histogram* histo = new Histogram();
    histo->setImage(&image);
    histo->calculateHistogram();
    histo->openHistogram();
    histo->safeAsTextFile();

    const QString message = tr("Histogram safed as textfile in the current directory");
    statusBar()->showMessage(message, 10000);
}

void Window::smoothImage(){

    bool ok;
    int nLevel = QInputDialog::getInt(this,tr("Choose the N for smoothing (min. 3)"),tr("N:"),0,std::numeric_limits<int>::min(), std::numeric_limits<int>::max(),1,&ok);
    if (ok && !(nLevel < 3)) {
        ImageSmoother* smoother = new ImageSmoother();
        smoother->setImage(&image);
        smoother->smootheImage(nLevel);
        QImage newImage = smoother->getNewImage();
        setImage(newImage);
        const QString message = tr("Image smoothed");
        statusBar()->showMessage(message, 5000);
    } else {
        const QString message = tr("Did not choose a valid N");
        statusBar()->showMessage(message, 5000);
    }
}

void Window::calculateGradiant(){
    //Vom Nutzer auswählen lassen ob horizontal / vertikal oder die magnitude

}

void Window::thresholdImage(){

}

void Window::calculateSizeOfObject(){

}
