package com.theb.theapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.theb.theapp.utilities.SessionManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class AddFriendActivity extends AppCompatActivity {


    SessionManager session;
    Button addUserButton;
    EditText friendName;
    String friendString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_friend);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        session = new SessionManager(getApplicationContext());
        Log.d("test", "ActionBarIsSet");
        if (session.isLoggedIn()) {

            addUserButton = (Button) findViewById(R.id.AddUserButton);

            addUserButton.setOnClickListener(
                    new Button.OnClickListener() {
                        public void onClick(View v) {
                            friendName = (EditText) findViewById(R.id.AddFriendEditText);
                            friendString = friendName.getText().toString();
                            //Add the friend to the User
                            addUser(friendString);
                        }
                    }
            );

        } else {
            startActivity(new Intent(this, MainActivity.class));
        }

    }

    public void addUser(final String friendString) {
        new AsyncTask<String, Void, Integer>() {

            @Override
            protected Integer doInBackground(String... params) {
                String response = "";
                String path = getString(R.string.ApiUrl) + "users/" + params[0] + "/friends";
                int statusCode = 0;
                try{
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("username", session.getUsername());
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setDoInput(true);
                    connection.setDoOutput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/json");
                    Log.d("test", session.getTokentype() + " " + session.getToken());
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    /*OutputStream outputstream = connection.getOutputStream();
                    OutputStreamWriter writer = new OutputStreamWriter(outputstream);
                    writer.write(jsonObject.toString());
                    writer.close();
                    outputstream.close();*/
                    statusCode = connection.getResponseCode();
                    Log.d("test", "status code after get is " + statusCode);
                    if (statusCode == 200) {
                        String line;
                        BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        while ((line=br.readLine()) != null) {
                            response+=line;
                        }
                        Log.d("test", response);
                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (JSONException | IOException e) {
                    e.printStackTrace();
                }
                return statusCode;
            }

            @Override
            protected void onPostExecute(Integer s) {
                super.onPostExecute(s);
                if (s == 200) {
                    Toast.makeText(getApplicationContext(), "Added friend Successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Friend does not exist or is already your friend", Toast.LENGTH_SHORT).show();
                }
            }
        }.execute(friendString);
    }
}