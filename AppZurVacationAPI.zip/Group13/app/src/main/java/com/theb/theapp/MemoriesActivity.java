package com.theb.theapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.theb.theapp.utilities.SessionManager;
import com.google.gson.GsonBuilder;
import com.theb.theapp.utilities.SessionManager;
import com.theb.theapp.utilities.MediaAdapter;
import com.theb.theapp.utilities.MemoryAdapter;
import com.theb.theapp.utilities.MediaAdapter;
import com.google.gson.GsonBuilder;
import com.theb.theapp.utilities.SessionManager;
import com.theb.theapp.utilities.MediaAdapter;
import com.theb.theapp.utilities.MemoryAdapter;
import com.theb.theapp.utilities.MediaAdapter;
import com.theb.theapp.models.Media;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MemoriesActivity extends AppCompatActivity {

    TextView memoryTitle, memPlace, memDesc, memTime, memLat, memLong;
    Integer mem_id;
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memories);

        // Install the Android Support Library per the SDK Manager to get that to work
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        session = new SessionManager(getApplicationContext());
        Log.d("test", "ActionBarIsSet");
        if (session.isLoggedIn()) {
            Intent mIntent = getIntent();

            if (mIntent != null) {
                mem_id = mIntent.getIntExtra("Memory ID", 0);

                //vac_id = extras.getIntExtra("Vacation ID");
                Log.d("Vacation ID", "(Activity Vac)" + mem_id);

                memoryTitle = (TextView) findViewById(R.id.MemoryTitle);
                memoryTitle.setText(mIntent.getStringExtra("Memory Title"));

                memPlace = (TextView) findViewById(R.id.MemoryPlace);
                memPlace.setText(mIntent.getStringExtra("Memory Place"));

                memTime = (TextView) findViewById(R.id.MemoryTime);
                memTime.setText(mIntent.getStringExtra("Memory Time"));

                memDesc = (TextView) findViewById(R.id.MemoryDescription);
                memDesc.setText(mIntent.getStringExtra("Memory Description"));

              //  memLat = (TextView) findViewById(R.id.MemoryLocation);
              // memLat.setText(mIntent.getStringExtra("Memory Lat"));

                loadmedia(mem_id);

            } else {
                startActivity(new Intent(MemoriesActivity.this, MainActivity.class));
            }

        }
    }

    public void loadmedia(final Integer mem_id) {

        new AsyncTask<Integer, Void, Media[]>() {

            @Override
            protected Media[] doInBackground(Integer... params) {

                ///api/v1/memories/<id>/media-objects
                String path = getString(R.string.ApiUrl) + "memories/" + params[0] + "/media-objects";
                Media[] mediaObjects = new Media[] {};


                try{
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setDoInput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/json");
                    Log.d("test", session.getTokentype() + " " + session.getToken());
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    int statusCode = connection.getResponseCode();
                    Log.d("test", "status code after get is " + statusCode);
                    String response = "";

                    if (statusCode == 200) {
                        String line;
                        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        while ((line=br.readLine()) != null) {
                            response+=line;
                        }
                        Gson gson = new Gson();
                        mediaObjects = gson.fromJson(response, Media[].class);
                        //Log.d("test", "media Objects:" + mediaObjects[0].container);

                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (IOException | RuntimeException e) {
                    e.printStackTrace();
                }
                return mediaObjects;
            }

            protected void onPostExecute(Media[] medias){
                //TODO implement adapter for media objects (sounds, clips and images)
                super.onPostExecute(medias);

                MediaAdapter adapter = new MediaAdapter(MemoriesActivity.this, medias);
                ListView listview = (ListView) findViewById(R.id.MediasList);
                listview.setAdapter(adapter);
            }

        }.execute(mem_id);


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem item =  menu.findItem(R.id.action_mediaupload);
        item.setVisible(true);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if(id == R.id.menu_newsfeed) {
            startActivity(new Intent(MemoriesActivity.this, NewsFeedActivity.class));
        }

        if(id == R.id.action_signout) {
            session.logoutUser();
            startActivity(new Intent(MemoriesActivity.this, MainActivity.class));

        }

        if(id == R.id.action_addVacation)
        {
            startActivity(new Intent(MemoriesActivity.this, AddVacationActivity.class));
        }

        if(id == R.id.action_mediaupload) {

            Intent intent = new Intent(MemoriesActivity.this, MediaUploadActivity.class);
            intent.putExtra("Memory ID", mem_id);
            startActivity(intent);
        }

        if( id == R.id.action_search) {
            startActivity(new Intent(MemoriesActivity.this, SearchActivity.class));
        }

        if(id == R.id.action_user) {
            Intent thisIntent = new Intent(MemoriesActivity.this, UserActivity.class);
            thisIntent.putExtra("username", session.getUsername());
            startActivity(thisIntent);
        }

        if(id == R.id.action_addFriend) {
            startActivity(new Intent(MemoriesActivity.this, AddFriendActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }

}

