package com.theb.theapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.theb.theapp.utilities.SessionManager;
import com.theb.theapp.models.Vacation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class AddVacationActivity extends AppCompatActivity {

    SessionManager session;
    Button addVacationButton;
    EditText title, description, place, start, end;
    String titleString, descriptionString, placeString;
    int startInt, endInt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vacation);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        session = new SessionManager(getApplicationContext());

        if (session.isLoggedIn()) {

            addVacationButton = (Button) findViewById(R.id.AddVacationButton);

            addVacationButton.setOnClickListener(
                    new Button.OnClickListener() {
                        public void onClick(View v) {
                            title = (EditText) findViewById(R.id.vacation_title_input);
                            titleString = title.getText().toString();

                            description = (EditText) findViewById(R.id.vacation_description_input);
                            descriptionString = description.getText().toString();

                            place = (EditText) findViewById(R.id.vacation_place_input);
                            placeString = place.getText().toString();

                            start = (EditText) findViewById(R.id.vacation_start_date_input);
                            startInt = Integer.parseInt(start.getText().toString());

                            end = (EditText) findViewById(R.id.vacation_end_date_input);
                            endInt = Integer.parseInt(end.getText().toString());

                            Vacation theVacation = new Vacation(0);
                            theVacation.setTitle(titleString);
                            theVacation.setDescription(descriptionString);
                            theVacation.setPlace(placeString);
                            theVacation.setStart(startInt);
                            theVacation.setEnd(endInt);
                            theVacation.setUserId(session.getUsername());
                            //Add the Vacation to the User
                            addVacation(theVacation);
                        }
                    }
            );

        } else {
            startActivity(new Intent(this, MainActivity.class));
        }

    }

    public void addVacation(Vacation theVacation) {

        new AsyncTask<Vacation,Void,Integer>() {
            protected Integer doInBackground(Vacation... params) {

                String urlString = getString(R.string.ApiUrl) + "vacations";
                URL url;
                int statusCode = 0;

                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("title", params[0].title);
                    jsonObject.put("description", params[0].description);
                    jsonObject.put("place", params[0].place);
                    jsonObject.put("start", params[0].start);
                    jsonObject.put("end", params[0].end);
                    //jsonObject.put("userId", params[0].userId);
                    url = new URL(urlString);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setDoInput(true);
                    connection.setDoOutput(true);
                    connection.setRequestMethod("POST");
                    connection.addRequestProperty("Content-Type", "application/json");
                    connection.setRequestProperty("Accept", "application/json");
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    OutputStream outputstream = connection.getOutputStream();
                    OutputStreamWriter writer = new OutputStreamWriter(outputstream);
                    writer.write(jsonObject.toString());
                    writer.close();
                    outputstream.close();
                    statusCode = connection.getResponseCode();
                    connection.disconnect();
                    if(statusCode == 400) {
                        Log.d("test", "Error in creating the vacation");
                    } else if (statusCode == 200) {
                        Log.d("test", "Vacation created");
                    }
                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }
                return statusCode;
            }

            protected void onPostExecute(Integer i) {
                super.onPostExecute(i);
                if (i == 200) {
                    Toast.makeText(getApplicationContext(), "Vacation created", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Error in creating the vacation.", Toast.LENGTH_SHORT).show();
                }
            }

        }.execute(theVacation);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if(id == R.id.action_addVacation)
        {
            startActivity(new Intent(AddVacationActivity.this, AddVacationActivity.class));
        }
        if(id == R.id.menu_newsfeed) {
            startActivity(new Intent(AddVacationActivity.this, NewsFeedActivity.class));
        }

        if(id == R.id.action_signout) {
            session.logoutUser();
        }

        if(id == R.id.action_mediaupload) {
            startActivity(new Intent(AddVacationActivity.this, MediaUploadActivity.class));
        }

        if( id == R.id.action_search) {
            startActivity(new Intent(AddVacationActivity.this, SearchActivity.class));
        }

        if(id == R.id.action_user) {
            Intent intent = new Intent(AddVacationActivity.this, UserActivity.class);
            intent.putExtra("username", session.getUsername());
            Log.d("test", "Profile View should start now");
            startActivity(intent);
        }
        if(id == R.id.action_update_account){
            startActivity(new Intent(AddVacationActivity.this, UpdateAccountActivity.class));
        }


        return super.onOptionsItemSelected(item);
    }

}
