package com.theb.theapp.models;

/**
 * Created by Marco on 09.11.2015.
 */
public class PictureMedia extends Media {

    public int width;
    public int height;

    public PictureMedia(int id, int memoryId) {
        super(id, memoryId);
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
