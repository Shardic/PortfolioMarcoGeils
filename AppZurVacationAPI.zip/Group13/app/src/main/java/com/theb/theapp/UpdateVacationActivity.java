package com.theb.theapp;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.theb.theapp.utilities.SessionManager;
import com.theb.theapp.models.Vacation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class UpdateVacationActivity extends AppCompatActivity {

    SessionManager session;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_vacation);
        String vacTitle = null, vacDesc = null, vacPlace = null;
        Integer vacId = null, vacStart = null, vacEnd = null;
        EditText title = null, desc = null, place = null, start = null, end = null;



        session = new SessionManager(getApplicationContext());

        if (session.isLoggedIn()) {

            Button updateVacButton = (Button) findViewById(R.id.button_update_vacation);

            Intent thisIntent = getIntent();
            if (thisIntent != null) {

                vacId = thisIntent.getIntExtra("Vacation ID", 0);

                title = (EditText) findViewById(R.id.editText_update_vacation_title);
                title.setText(thisIntent.getStringExtra("Vacation Title"));

                desc = (EditText) findViewById(R.id.editText_update_vacation_desc);
                desc.setText(thisIntent.getStringExtra("Vacation Description"));

                place = (EditText) findViewById(R.id.editText_update_vacation_place);
                place.setText(thisIntent.getStringExtra("Vacation Place"));

                //Update API to provide Start and End. Then only can you uncomment this
                start = (EditText) findViewById(R.id.editText_update_vacation_start);
                start.setText(""+thisIntent.getIntExtra("Vacation Start", 0));

                end = (EditText) findViewById(R.id.editText_update_vacation_end);
                end.setText(""+thisIntent.getIntExtra("Vacation End", 0));

            }
            else
            {
                startActivity(new Intent(UpdateVacationActivity.this, MainActivity.class));
            }

            final Integer afinalVacId = vacId;
            final EditText finalTitle = title;
            final EditText finalDesc = desc;
            final EditText finalPlace = place;
            final EditText finalStart = start;
            final EditText finalEnd = end;
            updateVacButton.setOnClickListener(new Button.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        assert finalTitle != null;
                        String finalVacTitle = finalTitle.getText().toString();
                        final String finalVacDesc = finalDesc.getText().toString();
                        final String finalVacPlace = finalPlace.getText().toString();
                        final Integer finalVacStart = Integer.valueOf(finalStart.getText().toString());
                        final Integer finalVacEnd = Integer.valueOf(finalEnd.getText().toString());

                        Vacation updateVac = new Vacation(afinalVacId, finalVacTitle, finalVacDesc, finalVacPlace, finalVacStart, finalVacEnd);
                        updateVacationDetails(updateVac);

                    }


                });
        } else {
            startActivity(new Intent(UpdateVacationActivity.this, MainActivity.class));
        }
    }

    private void updateVacationDetails(Vacation updateVac) {

        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()) {

            new AsyncTask<Vacation, Void, Integer>() {

                @Override
                protected Integer doInBackground(Vacation... params) {

                    //PATCH: Partially updates the vacation with id <id>.
                    ///api/v1/vacations/<id>
                    String urlString = getString(R.string.ApiUrl) + "vacations/" + params[0].id;
                    URL url;
                    Log.d("Path: ", urlString);
                    int statusCode = 0;

                    try {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("title", params[0].title);
                        jsonObject.put("description", params[0].description);
                        jsonObject.put("place", params[0].place);
                        //Update API to receive Start and End. Then only can you uncomment this
                        jsonObject.put("start", params[0].start);
                        jsonObject.put("end", params[0].end);

                        url = new URL(urlString);
                        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                        connection.setDoOutput(true);
                        connection.setRequestMethod("PATCH");
                        connection.addRequestProperty("Content-Type", "application/json");
                        connection.setRequestProperty("Accept", "application/json");
                        connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());

                        OutputStream outputstream = connection.getOutputStream();
                        OutputStreamWriter writer = new OutputStreamWriter(outputstream);
                        Log.d("Vacation Update Info", jsonObject.toString());
                        writer.write(jsonObject.toString());
                        writer.close();
                        outputstream.close();
                        statusCode = connection.getResponseCode();
                        connection.disconnect();
                        if (statusCode == 400) {
                            Log.d("RESULT: ", "ERROR" + statusCode);
                        } else if (statusCode == 200) {
                            Log.d("RESULT: ", "Your data has been updated!" + statusCode);
                        } else {
                            Log.d("The STATUS CODE: ", "" + statusCode);
                        }

                    } catch (IOException | JSONException e) {
                        e.printStackTrace();
                    }

                    return statusCode;
                }

                @Override
                protected void onPostExecute(Integer value){
                    super.onPostExecute(value);
                    if (value == 200) {
                        Toast.makeText(getApplicationContext(), "Your information has been updated.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Something isn't working right.", Toast.LENGTH_SHORT).show();
                    }
                }

            }.execute(updateVac);
    }

    }


}
