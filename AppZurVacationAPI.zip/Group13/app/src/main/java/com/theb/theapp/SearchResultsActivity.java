package com.theb.theapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.theb.theapp.utilities.SessionManager;
import com.theb.theapp.utilities.MemoryAdapter;
import com.theb.theapp.models.Memory;

public class SearchResultsActivity extends AppCompatActivity {

    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Here's what we could find...");
        session = new SessionManager(getApplicationContext());

        if (session.isLoggedIn()) {

            Intent mIntent = getIntent();

            if (mIntent != null) {
                final Memory[] memories = (Memory[]) getIntent().getSerializableExtra("Memory");

                MemoryAdapter adapter = new MemoryAdapter(SearchResultsActivity.this, memories);
                ListView listview = (ListView) findViewById(R.id.SearchResultsList);
                listview.setAdapter(adapter);

                listview.setOnItemClickListener((new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        Log.d("Memory ID", String.valueOf(memories[position].id));

                        Intent intent = new Intent(SearchResultsActivity.this, MemoriesActivity.class);
                        intent.putExtra("Memory ID", memories[position].id);
                        intent.putExtra("Memory Title", memories[position].title);
                        intent.putExtra("Memory Description", memories[position].description);
                        intent.putExtra("Memory Place", memories[position].place);
                        intent.putExtra("Memory Time", memories[position].time);
                        intent.putExtra("Memory Lat", memories[position].position.latitude);
                        intent.putExtra("Memory Long", memories[position].position.longitude);

                        startActivity(intent);
                    }
                }));
            }
            else {

                String[] values = new String[] { "No matching memories here. Go back to try again!"};
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, 0, values);
                ListView listview = (ListView) findViewById(R.id.SearchResultsList);
                listview.setAdapter(adapter);
            }

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if(id == R.id.menu_newsfeed) {
            startActivity(new Intent(SearchResultsActivity.this, NewsFeedActivity.class));
        }

        if(id == R.id.action_signout) {
            session.logoutUser();
            startActivity(new Intent(SearchResultsActivity.this, MainActivity.class));
        }

        if(id == R.id.action_mediaupload) {
            startActivity(new Intent(SearchResultsActivity.this, MediaUploadActivity.class));
        }

        if( id == R.id.action_search) {
            startActivity(new Intent(SearchResultsActivity.this, SearchActivity.class));
        }

        if(id == R.id.action_user) {
            Intent thisIntent = new Intent(SearchResultsActivity.this, UserActivity.class);
            thisIntent.putExtra("username", session.getUsername());
            startActivity(thisIntent);startActivity(new Intent(SearchResultsActivity.this, UserActivity.class));
        }

        if(id == R.id.action_addFriend) {
            startActivity(new Intent(SearchResultsActivity.this, AddFriendActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }

}
