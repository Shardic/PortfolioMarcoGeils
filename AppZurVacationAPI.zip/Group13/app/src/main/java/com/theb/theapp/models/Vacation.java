package com.theb.theapp.models;

/**
 * Created by Marco on 09.11.2015.
 */
public class Vacation {

    public int id;
    public String title;
    public String description;
    public String place;
    public int start;
    public int end;
    public String userId;

    public Vacation(int id) {
        this.id = id;
    }

    public Vacation(Integer vacId, String vacTitle, String vacDesc, String vacPlace, Integer vacStart, Integer vacEnd) {

        this.id = vacId;
        this.title = vacTitle;
        this.description = vacDesc;
        this.place = vacPlace;
        this.start = vacStart;
        this.end = vacEnd;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getEnd() {
        return end;
    }

    public void setEnd(int end) {
        this.end = end;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

}
