package com.theb.theapp.models;

/**
 * Created by B on 15-Dec-15.
 */
public class CurrentPosition {

    Position pos;
    String city;

    public CurrentPosition(Position pos, String city){
        this.pos = pos;
        this.city = city;
    }
}
