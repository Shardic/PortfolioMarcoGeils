package com.theb.theapp.models;

import java.util.Date;

/**
 * Created by Marco on 09.11.2015.
 */
public class Memory {

    public int id;
    public String title;
    public String description;
    public String place;
    public Date time;
    public Position position;
    public int VacationId;

    public Memory(int id) {
        this.id = id;
    }

    public Memory(String finalMemTitle, String finalMemDesc, String finalMemPlace, Date finalMemTime, Position finalMemPosition, Integer finalVacId) {
        this.title = finalMemTitle;
        this.description = finalMemDesc;
        this.place = finalMemPlace;
        this.time = finalMemTime;
        this.position = finalMemPosition;
        this.VacationId = finalVacId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public int getVacationId() {
        return VacationId;
    }

    public void setVacationId(int vacationId) {
        VacationId = vacationId;
    }
}
