package com.theb.theapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import com.google.gson.Gson;
import com.theb.theapp.utilities.SessionManager;
import com.theb.theapp.utilities.MemoryAdapter;
import com.theb.theapp.models.Memory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;

public class SearchActivity extends AppCompatActivity {

    //private TextView user_search;
    private Button gomemory;
    private EditText query_search;
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Search for your memories and your friend's");
        session = new SessionManager(getApplicationContext());

        if(session.isLoggedIn()) {
            gomemory = (Button) findViewById(R.id.goSearchMemory);
            final Spinner dropdown = (Spinner) findViewById(R.id.memoryType);
            String[] items = new String[]{"user", "place", "title"};
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
            dropdown.setAdapter(adapter);

            //Search for a memory
            gomemory.setOnClickListener(
                    new Button.OnClickListener() {
                        public void onClick(View v) {
                            query_search = (EditText) findViewById(R.id.SearchQuery);
                            String query = query_search.getText().toString();
                            String type = dropdown.getSelectedItem().toString();

                            //Log.v("Memory", memory_search.getText().toString());
                            //SearchActivity based on memory details

                            searchMemory(type, query);
                        }
                    }
            );

        }
    }

    private void searchMemory(final String type, final String query){

        new AsyncTask<String, Void, Memory[]>() {

            protected Memory[] doInBackground(String... params) {
                ///api/v1/memories/search?type=<type>&q=<query>
               // String searchtype = "\""+params[0]+"\"";
                String searchquery = params[1];

                //TODO Queries can only handle one word. Works fine with multiple words in Postman but not via app. Fix it.
                //searchquery = "Snow" vs "Snow Mobile". The latter fails!
                String path = getString(R.string.ApiUrl) + "memories/search?searchtype="+params[0]+"&searchquery="+searchquery;
                Log.d("Path",path);
                Memory[] memories = new Memory[] {};

                //TODO Access memories that correspond to the type and query. Display them in SearchResultsActivity Activity
                try{
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setDoInput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/json");
                    Log.d("test", session.getTokentype() + " " + session.getToken());
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    int statusCode = connection.getResponseCode();
                    Log.d("test", "status code after get is " + statusCode);
                    String response = "";
                    if (statusCode == 200) {
                        String line;
                        BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        while ((line=br.readLine()) != null) {
                            response+=line;
                        }
                        Gson gson = new Gson();
                        memories = gson.fromJson(response, Memory[].class);
                        Log.d("test", response);
                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (IOException | NullPointerException e) {
                    e.printStackTrace();
                }

                return memories;
            }

            protected void onPostExecute(final Memory[] memories) {
                super.onPostExecute(memories);

                if(Arrays.toString(memories) != "[]"){

                MemoryAdapter adapter = new MemoryAdapter(SearchActivity.this, memories);
                ListView listview = (ListView) findViewById(R.id.SearchResults);
                listview.setAdapter(adapter);

                listview.setOnItemClickListener((new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        Log.d("Memory ID", String.valueOf(memories[position].id));

                        Intent intent = new Intent(SearchActivity.this, MemoriesActivity.class);
                        intent.putExtra("Memory ID", memories[position].id);
                        intent.putExtra("Memory Title", memories[position].title);
                        intent.putExtra("Memory Description", memories[position].description);
                        intent.putExtra("Memory Place", memories[position].place);
                       /*
                        intent.putExtra("Memory Time", memories[position].time);
                        intent.putExtra("Memory Lat", memories[position].position.latitude);
                        intent.putExtra("Memory Long", memories[position].position.longtitude);
                        */
                        startActivity(intent);
                    }
                }));
            }
            else {

                String[] values = new String[] { "No matching memories here. Try again!"};
                ArrayAdapter<String> adapter = new ArrayAdapter<>(SearchActivity.this,android.R.layout.simple_list_item_1, 0, values);
                ListView listview = (ListView) findViewById(R.id.SearchResults);
                listview.setAdapter(adapter);
            }

        }
        }.execute(type, query);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if(id == R.id.menu_newsfeed) {
            startActivity(new Intent(SearchActivity.this, NewsFeedActivity.class));
        }

        if(id == R.id.action_signout) {
            session.logoutUser();
            startActivity(new Intent(SearchActivity.this, MainActivity.class));
        }

        if(id == R.id.action_addVacation)
        {
            startActivity(new Intent(SearchActivity.this, AddVacationActivity.class));
        }
        
        if(id == R.id.action_mediaupload) {
            startActivity(new Intent(SearchActivity.this, MediaUploadActivity.class));
        }

        if( id == R.id.action_search) {
            startActivity(new Intent(SearchActivity.this, SearchActivity.class));
        }

        if(id == R.id.action_user) {
            Intent thisIntent = new Intent(SearchActivity.this, UserActivity.class);
            thisIntent.putExtra("username", session.getUsername());
            startActivity(thisIntent);
        }

        if(id == R.id.action_update_account) {
            startActivity(new Intent(SearchActivity.this, UpdateAccountActivity.class));
        }

        if(id == R.id.action_addFriend) {
            startActivity(new Intent(SearchActivity.this, AddFriendActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }

}
