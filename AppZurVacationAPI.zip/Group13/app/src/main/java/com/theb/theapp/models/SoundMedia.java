package com.theb.theapp.models;

/**
 * Created by Marco on 09.11.2015.
 */
public class SoundMedia extends Media {

    public float duration;
    public String codec;
    public float bitRate;
    public int channels;
    public float samplingRate;

    public SoundMedia(int id, int memoryId) {
        super(id, memoryId);
    }

    public float getSamplingRate() {
        return samplingRate;
    }

    public void setSamplingRate(float samplingRate) {
        this.samplingRate = samplingRate;
    }

    public float getDuration() {
        return duration;
    }

    public void setDuration(float duration) {
        this.duration = duration;
    }

    public String getCodec() {
        return codec;
    }

    public void setCodec(String codec) {
        this.codec = codec;
    }

    public float getBitRate() {
        return bitRate;
    }

    public void setBitRate(float bitRate) {
        this.bitRate = bitRate;
    }

    public int getChannels() {
        return channels;
    }

    public void setChannels(int channels) {
        this.channels = channels;
    }
}
