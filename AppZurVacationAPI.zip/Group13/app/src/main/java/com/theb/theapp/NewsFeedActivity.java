package com.theb.theapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;
import com.theb.theapp.utilities.SessionManager;
import com.theb.theapp.utilities.FriendAdapter;
import com.theb.theapp.models.User;
import com.theb.theapp.utilities.DatabaseHelper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

public class NewsFeedActivity extends AppCompatActivity {

    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_feed);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Friends");

        session = new SessionManager(getApplicationContext());
        if (session.isLoggedIn()) {

            Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
            //The Newsfeed will show a list of all the current friends of the user

            //Check if there is an online connection
            ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isConnected() && networkInfo.isAvailable()) {
                showFriends(session.getUsername());
                //There is an online connection
                AdView mAdView = (AdView) findViewById(R.id.adView);
                AdRequest adRequest = new AdRequest.Builder().build();
                mAdView.loadAd(adRequest);
            }
            else {
                //No online connection
                ListView friendList = (ListView) findViewById(R.id.newsfeedlist);

                final String[] cachedFriends = accessFriends(session.getUsername());
                int value = 0;
                try {
                    value = cachedFriends.length;
                }
                catch(NullPointerException e){
                    e.printStackTrace();
                }
                if (value != 0) {
                    Log.d("Cached Friend List", Arrays.toString(cachedFriends));
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(NewsFeedActivity.this, android.R.layout.simple_list_item_1, cachedFriends);
                    friendList.setAdapter(adapter);

                    //Clicking on friend provides a profile view of the friend
                    friendList.setOnItemClickListener((new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            Log.d("Chosen Friend", String.valueOf(cachedFriends[position]));

                            Intent intent = new Intent(NewsFeedActivity.this, UserActivity.class);
                            intent.putExtra("username", cachedFriends[position]);
                            startActivity(intent);
                        }
                    }));
                }
                else
                {
                    String[] nofriends = {"You are so lonely!"};
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(NewsFeedActivity.this, android.R.layout.simple_list_item_1, nofriends);
                    friendList.setAdapter(adapter);
                }
            }

        } else {
            startActivity(new Intent(NewsFeedActivity.this, MainActivity.class));
        }
    }

    /***********************CACHED: LIST ALL FRIENDS FOR THE GIVEN USER.**************************/

    private String[] accessFriends(String username) {
        //TODO List all cached friends
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String usernameOne = "\"" + username + "\"";

        Cursor cursor = db.rawQuery(
                "SELECT * FROM friends WHERE username1 = "+ usernameOne,
                null
        );

        ArrayList<String> names = new ArrayList<>();
        if(cursor != null) {
            Log.d("Cursor is not null", String.valueOf(cursor));

            try {
                if(cursor.moveToFirst())
                {
                    for(Integer i = 0; i < cursor.getCount(); i++)
                    {
                        names.add(cursor.getString(cursor.getColumnIndex("username2")));
                    }
                }
                cursor.close();
            }
            catch(NullPointerException e)
            {
                e.printStackTrace();
            }
        }

        return names.toArray(new String[names.size()]);
    }

    private void showFriends(String username) {
        //DONE List all friends
        //DONE Create a friendsAdapter
        //DONE Save friend list to cache

        new AsyncTask<String, Void, User[]>() {

            protected User[] doInBackground(String... params) {

                // /api/v1/users/<username>/friends
                String path = getString(R.string.ApiUrl)+"users/"+ params[0] + "/friends";

                Log.d("test", "following url gets a request " + path);
                User[] user = new User[] {};
                try{
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setDoInput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/json");
                    Log.d("test", session.getTokentype() + " " + session.getToken());
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    int statusCode = connection.getResponseCode();
                    Log.d("test", "status code after get is " + statusCode);
                    String response = "";
                    if (statusCode == 200) {
                        String line;
                        BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        while ((line=br.readLine()) != null) {
                            response+=line;
                        }
                        Gson gson = new Gson();
                        user = gson.fromJson(response, User[].class);

                        Log.d("test", response);
                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return user;
            }

            protected void onPostExecute(final User[] friends){
                super.onPostExecute(friends);

                ListView friendlist = (ListView) findViewById(R.id.newsfeedlist);
                Log.d("Friend List", Arrays.toString(friends));

                //If the current user doesn't have any friends
                if(Arrays.toString(friends).equals("[]")){
                    String[] nofriends = {"Wanna connect with cool people like you?"};
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(NewsFeedActivity.this, android.R.layout.simple_list_item_1, nofriends);
                    friendlist.setAdapter(adapter);

                    //DONE ClickListener to AddFriend
                    friendlist.setOnItemClickListener((new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            Intent intent = new Intent(NewsFeedActivity.this, AddFriendActivity.class);
                            startActivity(intent);
                        }
                    }));

                }
                else {
                    //If the current user has friends print list of all friends
                    FriendAdapter currentfriends = new FriendAdapter(NewsFeedActivity.this, friends);
                    friendlist.setAdapter(currentfriends);

                    //DONE Add Friend details to the SQLite
                    Context ctx = NewsFeedActivity.this;
                    DatabaseHelper databaseHelper = new DatabaseHelper(ctx);
                    databaseHelper.delFriends(databaseHelper,session.getUsername(),friends);
                    databaseHelper.makeFriends(databaseHelper,session.getUsername(),friends);

                    //Clicking on friend provides a profile view of the friend
                    friendlist.setOnItemClickListener((new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            Log.d("Chosen Friend", String.valueOf(friends[position].username));

                            Intent intent = new Intent(NewsFeedActivity.this, UserActivity.class);
                            intent.putExtra("username", friends[position].username);
                            startActivity(intent);
                        }
                    }));
                }
            }

        }.execute(username);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if(id == R.id.action_addVacation)
        {
            startActivity(new Intent(NewsFeedActivity.this, AddVacationActivity.class));
        }
        if(id == R.id.menu_newsfeed) {
            startActivity(new Intent(NewsFeedActivity.this, NewsFeedActivity.class));
        }

        if(id == R.id.action_searchuser) {
            startActivity(new Intent(NewsFeedActivity.this, SearchUserActivity.class));
        }

        if(id == R.id.action_signout) {
            session.logoutUser();
        }

        if(id == R.id.action_mediaupload) {
            startActivity(new Intent(NewsFeedActivity.this, MediaUploadActivity.class));
        }

        if( id == R.id.action_search) {
            startActivity(new Intent(NewsFeedActivity.this, SearchActivity.class));
        }

        if(id == R.id.action_user) {
            Intent intent = new Intent(NewsFeedActivity.this, UserActivity.class);
            intent.putExtra("username", session.getUsername());
            Log.d("test", "Profile View should start now");
            startActivity(intent);
        }
        if(id == R.id.action_update_account){
            startActivity(new Intent(NewsFeedActivity.this, UpdateAccountActivity.class));
        }

        if(id == R.id.action_addFriend) {
            startActivity(new Intent(NewsFeedActivity.this, AddFriendActivity.class));
        }


        return super.onOptionsItemSelected(item);
    }

}
