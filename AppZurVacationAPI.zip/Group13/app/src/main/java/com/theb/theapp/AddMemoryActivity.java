package com.theb.theapp;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.theb.theapp.models.Memory;
import com.theb.theapp.models.Position;
import com.theb.theapp.models.Vacation;
import com.theb.theapp.utilities.SessionManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AddMemoryActivity extends AppCompatActivity {
//Add a new memory to an existing vacation


    SessionManager session;
    Button addMemoryButton;
    String titleString, descriptionString, placeString, timeString;
    EditText title, description, place, time, position;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_memory);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        session = new SessionManager(getApplicationContext());

        if (session.isLoggedIn()) {

            addMemoryButton = (Button) findViewById(R.id.addMemoryButton);

            addMemoryButton.setOnClickListener(
                    new Button.OnClickListener() {
                        public void onClick(View v) {

                            Intent thisIntent = getIntent();
                            if(thisIntent != null) {

                                title = (EditText) findViewById(R.id.Memory_titel_input);
                                titleString = title.getText().toString();

                                description = (EditText) findViewById(R.id.Memory_describtion_input);
                                descriptionString = description.getText().toString();

                                place = (EditText) findViewById(R.id.Memory_place_input);
                                placeString = place.getText().toString();

                                time = (EditText) findViewById(R.id.Memory_time_input);
                                timeString = time.getText().toString();

                                //String dtStart = "2010-10-15T09:27:37Z";
                                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                                Date date = new Date();


                                position = (EditText) findViewById(R.id.Memory_position_input);
                                Float positionFloat = Float.parseFloat(position.getText().toString());
                                Log.d("PosFloat",""+positionFloat);

                                Position pos = new Position();
                                pos.longitude = 50;
                               // pos.longitude = positionFloat;
                                pos.latitude = 50;
                               // pos.latitude = positionFloat;


                                Memory newMem = new Memory(titleString, descriptionString, placeString,
                                        date, pos, thisIntent.getIntExtra("Vacation ID", 0));

                                addMem(newMem);
                            }

                        }
                    }
            );

        }
        else {
            startActivity(new Intent(this, MainActivity.class));
        }

    }



    /************ADD A NEW MEMORY****************/
    private void addMem(final Memory newMemory) {

        new AsyncTask<Memory,Void,Integer>() {
            protected Integer doInBackground(Memory... params) {

                // /api/v1/vacations/<id>/memories
                String urlString = getString(R.string.ApiUrl) + "vacations/"+newMemory.VacationId+"/memories";
                URL url;
                int statusCode = 0;

                try {
                    JSONObject posObject = new JSONObject();
                    posObject.put("longitude",params[0].position.longitude);
                    posObject.put("latitude",params[0].position.latitude);

                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("title", params[0].title);
                    jsonObject.put("description", params[0].description);
                    jsonObject.put("place", params[0].place);
                    jsonObject.put("time", params[0].time);
                    jsonObject.put("position", posObject);
                    jsonObject.put("VacationId", params[0].VacationId);

                    //jsonObject.put("userId", params[0].userId);
                    url = new URL(urlString);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setDoInput(true);
                    connection.setDoOutput(true);
                    connection.setRequestMethod("POST");
                    connection.addRequestProperty("Content-Type", "application/json");
                    connection.setRequestProperty("Accept", "application/json");
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    OutputStream outputstream = connection.getOutputStream();
                    OutputStreamWriter writer = new OutputStreamWriter(outputstream);
                    writer.write(jsonObject.toString());
                    writer.close();
                    outputstream.close();
                    statusCode = connection.getResponseCode();
                    connection.disconnect();
                    if(statusCode == 400) {
                        Log.d("test", "Error in creating the memory");
                    } else if (statusCode == 200) {
                        Log.d("test", "Memory created");
                    }
                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }
                return statusCode;
            }

            protected void onPostExecute(Integer i) {
                super.onPostExecute(i);
                if (i == 200) {
                    Toast.makeText(getApplicationContext(), "Memory created", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Error in creating the memory.", Toast.LENGTH_SHORT).show();
                }
            }
        }.execute(newMemory);
    }
}
