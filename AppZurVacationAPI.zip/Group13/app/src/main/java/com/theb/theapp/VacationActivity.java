package com.theb.theapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.theb.theapp.utilities.DatabaseHelper;
import com.theb.theapp.utilities.SessionManager;
import com.theb.theapp.utilities.MemoryAdapter;
import com.theb.theapp.models.Memory;
import com.theb.theapp.utilities.SwipeDetector;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class VacationActivity extends AppCompatActivity {

    TextView vacationTitle, vacDesc, vacPlace, vacStart, vacEnd;
    SessionManager session;
    int vac_id;
    SwipeDetector swipeDetector = new SwipeDetector();
    int memoryToDelete = 0;

    AlertDialog memoDeleterDialog;

    public VacationActivity()
    {}

    public VacationActivity(Integer vac_id) {
        this.vac_id = vac_id;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vacation);

        // Install the Android Support Library per the SDK Manager to get that to work
        Toolbar toolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Vacation");

        memoDeleterDialog =  new AlertDialog.Builder(this).setTitle("Confirm Delete")
                .setMessage("Do you want to delete this Memory?")
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (memoryToDelete != 0) {
                            deleteMemory();
                        }
                    }
                })
                .setNeutralButton("Cancel", null) // don't need to do anything but dismiss here
                .create();

        session = new SessionManager(getApplicationContext());
        //Log.d("test", "ActionBarIsSet");

        if (session.isLoggedIn()) {

            final Intent mIntent = getIntent();

            if(mIntent != null)
            {
                vac_id = mIntent.getIntExtra("Vacation ID", 0);

                //vac_id = extras.getIntExtra("Vacation ID");
                Log.d("Vacation ID", "(Activity Vac)"+vac_id);

                vacationTitle = (TextView) findViewById(R.id.VacationTitle);
                vacationTitle.setText(mIntent.getStringExtra("Vacation Title"));

                vacPlace = (TextView) findViewById(R.id.Place);
                vacPlace.setText(mIntent.getStringExtra("Vacation Place"));

                vacDesc = (TextView) findViewById(R.id.VacationDescription);
                vacDesc.setText(mIntent.getStringExtra("Vacation Description"));


                vacStart = (TextView) findViewById(R.id.StartDate);
                vacStart.setText(""+mIntent.getIntExtra("Vacation Start",0));

                vacEnd = (TextView) findViewById(R.id.EndDate);
                vacEnd.setText(""+mIntent.getIntExtra("Vacation End", 0));

                loadMemoryList(vac_id);



                Button linkMemory = (Button) findViewById(R.id.link_add_memory_button);
                linkMemory.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if(session.getUsername().equals(mIntent.getStringExtra("Vacation UserName"))) {
                            Intent thisIntent = new Intent(VacationActivity.this, AddMemoryActivity.class);
                            thisIntent.putExtra("Vacation ID", vac_id);
                            startActivity(thisIntent);
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "You don't own this Vacation", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }

        } else {
            startActivity(new Intent(VacationActivity.this, MainActivity.class));
        }

//DONE Memory List
    }

    public void loadMemoryList(final Integer vac_id) {

        new AsyncTask<Integer, Void, Memory[]>() {
            @Override
            protected Memory[] doInBackground(Integer... params) {
                String path = getString(R.string.ApiUrl) + "vacations/" + params[0] + "/memories";
                Memory[] memories = new Memory[] {};

                try{
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setDoInput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/json");
                    Log.d("test", session.getTokentype() + " " + session.getToken());
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    int statusCode = connection.getResponseCode();
                    Log.d("test", "status code after get is " + statusCode);
                    String response = "";

                    if (statusCode == 200) {
                        String line;
                        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        while ((line=br.readLine()) != null) {
                            response+=line;
                        }
                        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:sss").create();
                        //2015-12-07T12:46:10.433
                       memories = gson.fromJson(response, Memory[].class);
                       // memories = new Memory[0];
                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return memories;

            }

            @Override
            protected void onPostExecute(final Memory[] memories) {
                super.onPostExecute(memories);

                MemoryAdapter adapter = new MemoryAdapter(VacationActivity.this, memories);
                ListView listview = (ListView) findViewById(R.id.MemoriesList);
                listview.setAdapter(adapter);
                listview.setOnTouchListener(swipeDetector);

                //TODO Cache:Add Vacation details to the SQLite
                Context ctx = VacationActivity.this;
                DatabaseHelper databaseHelper = new DatabaseHelper(ctx);
                databaseHelper.delMemories(databaseHelper, vac_id, memories);
                databaseHelper.saveMemories(databaseHelper, vac_id, memories);

                listview.setOnItemClickListener((new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        if (swipeDetector.swipeDetected()) {
                            if (swipeDetector.getAction() == SwipeDetector.Action.RL) {
                                memoryToDelete = memories[position].id;
                                memoDeleterDialog.show();
                            }
                        } else {
                                    Log.d("Vacation ID", ""+memories[position].id);

                                    Intent intent = new Intent(VacationActivity.this, MemoriesActivity.class);
                                    intent.putExtra("Memory ID", memories[position].id);
                                    intent.putExtra("Memory Title", memories[position].title);
                                    intent.putExtra("Memory Description", memories[position].description);
                                    intent.putExtra("Memory Place", memories[position].place);
                                    intent.putExtra("Memory Time", memories[position].time);
                                    intent.putExtra("Memory Lat", memories[position].position.latitude);
                                    intent.putExtra("Memory Long", memories[position].position.longitude);

                                    startActivity(intent);
                                }
                            }
                }));

                /*listview.setOnItemLongClickListener((new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                        Intent intent = new Intent(VacationActivity.this, UpdateMemoriesActivity.class);
                        intent.putExtra("Memory ID", memories[position].id);
                        intent.putExtra("Memory Title", memories[position].title);
                        intent.putExtra("Memory Description", memories[position].description);
                        intent.putExtra("Memory Place", memories[position].place);
                        intent.putExtra("Memory Time", memories[position].time);
                        intent.putExtra("Memory Lat", memories[position].position.latitude);
                        intent.putExtra("Memory Long", memories[position].position.longtitude);

                        startActivity(intent);
                        return true;
                    }
                    }));*/
            }
        }.execute(vac_id);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if(id == R.id.menu_newsfeed) {
            startActivity(new Intent(VacationActivity.this, NewsFeedActivity.class));
        }

        if(id == R.id.action_signout) {
            session.logoutUser();
            startActivity(new Intent(VacationActivity.this, MainActivity.class));
            //Clear out signed in credentials
        }

        if(id == R.id.action_mediaupload) {
            startActivity(new Intent(VacationActivity.this, MediaUploadActivity.class));
        }

        if( id == R.id.action_search) {
            startActivity(new Intent(VacationActivity.this, SearchActivity.class));
        }

        if(id == R.id.action_user) {
            Intent thisIntent = new Intent(VacationActivity.this, UserActivity.class);
            thisIntent.putExtra("username", session.getUsername());
            startActivity(thisIntent);
        }

        if(id == R.id.action_addFriend) {
            startActivity(new Intent(VacationActivity.this, AddFriendActivity.class));
        }

        if(id == R.id.action_addMemory) {
            Intent thisIntent = new Intent(VacationActivity.this, AddMemoryActivity.class);
            thisIntent.putExtra("Vacation ID",vac_id);
            startActivity(thisIntent);
        }


        return super.onOptionsItemSelected(item);
    }

    public void deleteMemory() {
        new AsyncTask<Integer, Void, Integer>() {
            protected Integer doInBackground(Integer... params) {
                String path = getString(R.string.ApiUrl) + "memories/" + params[0];
                int statusCode = 0;
                try{
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("DELETE");
                    connection.setDoInput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/json");
                    Log.d("test", session.getTokentype() + " " + session.getToken());
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    statusCode = connection.getResponseCode();
                    if (statusCode == 200) {
                        Log.d("test", "Successfully deleted the Memory");
                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return statusCode;
            }

            @Override
            protected void onPostExecute(Integer i) {
                super.onPostExecute(i);
                if(i == 200) {
                    Toast.makeText(getApplicationContext(), "You deleted this Memory", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Deletion failed", Toast.LENGTH_SHORT).show();
                }
            }
        }.execute(memoryToDelete);
    }

}
