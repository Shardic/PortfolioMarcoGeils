package com.theb.theapp.models;

/**
 * Created by Marco on 09.11.2015.
 */
public class Media {

    public int id;
    public String url;
    public String memory;
    public String container;

    public Media(int id, int memoryId) {
        this.id = id;
    }

    public String getFileUrl() {
        return url;
    }

    public void setFileUrl(String fileUrl) {
        this.url = fileUrl;
    }

    public String getContainer() {
        return container;
    }


    public String getMemory() {
        return memory;
    }

    public void setMemory(String memory) {
        this.memory = memory;
    }

    public void setContainer(String container) {
        this.container = container;
    }
}
