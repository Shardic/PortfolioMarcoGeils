package com.theb.theapp.models;

/**
 * Created by Marco on 09.11.2015.
 */
public class Account {

    public String username;
    public String email;
    public String password;


    public Account(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
    }
}
