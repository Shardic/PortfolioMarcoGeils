package com.theb.theapp;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.theb.theapp.models.Account;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;


public class RegisterActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Button registerButton = (Button) findViewById(R.id.AddVacationButton);

        //TODO: Add firstName and LastName input
        //Do not add firstname and lastname at this stage.
        registerButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String username;
                String email;
                String password;
                String password2;
                String firstName, lastName;

                EditText userEditText = (EditText) findViewById(R.id.vacation_title_input);
                username = userEditText.getText().toString();
                EditText emailEditText = (EditText) findViewById(R.id.vacation_description_input);
                email = emailEditText.getText().toString();
                EditText editText = (EditText) findViewById(R.id.vacation_place_input);
                password = editText.getText().toString();
                editText = (EditText) findViewById(R.id.vacation_start_date_input);
                password2 = editText.getText().toString();

                if(password.trim().equals(password2.trim())) {
                    Account accountToRegister = new Account(username,email,password);
                    ConnectivityManager connMgr = (ConnectivityManager)
                            getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
                    if (networkInfo != null && networkInfo.isConnected()) {
                        new AsyncTask<Account,Void,String>() {
                            protected String doInBackground(Account... params) {

                                String urlString = getString(R.string.ApiUrl) + "accounts";
                                URL url;

                                String returnString = "Error";
                                try {
                                    JSONObject jsonObject = new JSONObject();
                                    jsonObject.put("username", params[0].username);
                                    jsonObject.put("email", params[0].email);
                                    jsonObject.put("password", params[0].password);
                                    url = new URL(urlString);
                                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                                    connection.setDoOutput(true);
                                    connection.setRequestMethod("POST");
                                    connection.addRequestProperty("Content-Type", "application/json");
                                    connection.setRequestProperty("Accept", "application/json");
                                    OutputStream outputstream = connection.getOutputStream();
                                    OutputStreamWriter writer = new OutputStreamWriter(outputstream);
                                    writer.write(jsonObject.toString());
                                    writer.close();
                                    outputstream.close();
                                    int statusCode = connection.getResponseCode();
                                    connection.disconnect();
                                    if(statusCode == 400) {
                                        returnString = "Username already exists or Password is invalid";
                                    } else if (statusCode == 200) {
                                        returnString = "You have been registered! Log in now!";
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                return returnString;
                            }

                            protected void onPostExecute(String s) {
                                super.onPostExecute(s);
                                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                                if (s.equals("You have been registered! Log in now!")) {
                                    startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                                }
                            }

                        }.execute(accountToRegister);

                    } else {
                        Toast.makeText(getApplicationContext(), "No network connection available.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "The password fields have to match", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}

