package com.theb.theapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.*;
import org.apache.http.impl.DefaultBHttpClientConnection;

import com.google.gson.Gson;
import com.theb.theapp.utilities.MediaAdapter;
import com.theb.theapp.models.Media;
import com.theb.theapp.utilities.MultipartUtility;
import com.theb.theapp.utilities.SessionManager;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class MediaUploadActivity extends AppCompatActivity {

    SessionManager session;
    private Button uploadPicture, uploadVideo, uploadSound;
    public int memoryId;
    public String type = "null";

    int REQUEST_CAMERA = 0, SELECT_FILE = 1, REQUEST_CAMERAV = 2, SELECT_FILEV = 3, REQUEST_AUDIO = 4, SELECT_FILES = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media_upload);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        session = new SessionManager(getApplicationContext());

        if (!session.isLoggedIn()) {
            startActivity(new Intent(MediaUploadActivity.this, MainActivity.class));
        } else {
            Intent mIntent = getIntent();
            if (mIntent != null) {
                memoryId = mIntent.getIntExtra("Memory ID", 0);
            } else {
                startActivity(new Intent(MediaUploadActivity.this, MainActivity.class));
            }

            uploadPicture = (Button) findViewById(R.id.ButtonPictureCapture);
            uploadSound = (Button) findViewById(R.id.ButtonSoundCapture);
            uploadVideo = (Button) findViewById(R.id.ButtonVideoCapture);

            uploadPicture.setOnClickListener(
                    new Button.OnClickListener() {
                        public void onClick(View v) {
                            capturePicture();
                        }
                    }
            );

            uploadSound.setOnClickListener(
                    new Button.OnClickListener() {
                        public void onClick(View v) {
                            captureSound();
                        }
                    }
            );

            uploadVideo.setOnClickListener(
                    new Button.OnClickListener() {
                        public void onClick(View v) {
                            captureVideo();
                        }
                    }
            );

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if(id == R.id.menu_newsfeed) {
            startActivity(new Intent(MediaUploadActivity.this, NewsFeedActivity.class));
        }

        if(id == R.id.action_signout) {
            // session.logoutUser();
            startActivity(new Intent(MediaUploadActivity.this, MainActivity.class));
            //Clear out signed in credentials
        }

        if(id == R.id.action_mediaupload) {
            startActivity(new Intent(MediaUploadActivity.this, MediaUploadActivity.class));
        }

        if( id == R.id.action_search) {
            startActivity(new Intent(MediaUploadActivity.this, SearchActivity.class));
        }

        if(id == R.id.action_user) {
            //TODO: Repeat on all activities except NewsFeed
            Intent thisIntent = new Intent(MediaUploadActivity.this, UserActivity.class);
            thisIntent.putExtra("username", session.getUsername());
            startActivity(thisIntent);
        }

        if(id == R.id.action_addFriend) {
            startActivity(new Intent(MediaUploadActivity.this, AddFriendActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }
   //TODO: Here is something helpfull how it can be done to Access Camera for Videos and Photos http://developer.android.com/guide/topics/media/camera.html

    public void capturePicture() {
        final CharSequence[] items = { "Take Photo", "Choose from Library", "Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(MediaUploadActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (items[item].equals("Take Photo")) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, REQUEST_CAMERA);
                } else if (items[item].equals("Choose from Library")) {
                    Intent intent = new Intent(
                            Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    startActivityForResult(
                            Intent.createChooser(intent, "Select File"),
                            SELECT_FILE);
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    public void captureVideo() {
        final CharSequence[] items = { "Take Video", "Choose from Library", "Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(MediaUploadActivity.this);
        builder.setTitle("Add Video!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (items[item].equals("Take Video")) {
                    Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                    startActivityForResult(intent, REQUEST_CAMERAV);
                } else if (items[item].equals("Choose from Library")) {
                    Intent intent = new Intent(
                            Intent.ACTION_PICK,
                            android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("video/*");
                    startActivityForResult(
                            Intent.createChooser(intent, "Select File"),
                            SELECT_FILEV);
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    public void captureSound() {
        final CharSequence[] items = {"Choose from your Files", "Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(MediaUploadActivity.this);
        builder.setTitle("Add Sound!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (items[item].equals("Record Audio")) {
                } else if (items[item].equals("Choose from your Files")) {
                    Intent intent = new Intent();
                    intent.setType("audio/mp3");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(
                            intent, "Open Audio (mp3) file"), SELECT_FILES);
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CAMERA) {
                Uri fileUri = data.getData();
                String realPath = getPicturePathFromUri(fileUri);
                File file = new File(realPath);
                type = "pictures";
                Log.d("test", "fileUploadFile Exists:" + file.exists());
                uploadData(file);
            } else if (requestCode == SELECT_FILE) {
                type = "pictures";
                Uri fileUri = data.getData();
                String realPath = getPicturePathFromUri(fileUri);
                File file = new File(realPath);
                Log.d("test", "fileUploadFile Exists:" + file.exists());
                uploadData(file);
            } else if (requestCode == REQUEST_CAMERAV) {
                type = "videos";
                Uri fileUri = data.getData();
                String realPath = getPathVideo(fileUri);
                File file = new File(realPath);
                Log.d("test", "fileUploadFile Exists:" + file.exists());
                uploadData(file);
            } else if (requestCode == SELECT_FILEV) {
                type = "videos";
                Uri fileUri = data.getData();
                String realPath = getPathVideo(fileUri);
                File file = new File(realPath);
                uploadData(file);
            } else if (requestCode == REQUEST_AUDIO) {

            } else if (requestCode == SELECT_FILES) {
                type = "sounds";
                Uri fileUri = data.getData();
                String realPath = getPathSound(fileUri);
                File file = new File(realPath);
                uploadData(file);
            }
        }
    }

    public void uploadData(File theFile) {
        new AsyncTask<File, Void, Integer>() {
            protected Integer doInBackground(File... params) {
                int statusCode = 0;
                String charset = "UTF-8";
                String path = getString(R.string.ApiUrl) + "memories/" + memoryId + "/" + type;
                Log.d("test", path);
                try {
                    MultipartUtility multipart = new MultipartUtility(path, charset, session);

                    multipart.addFilePart("fileUpload", params[0]);

                    List<String> response = multipart.finish();

                    System.out.println("SERVER REPLIED:");

                    for (String line : response) {
                        Log.d("test", "Response for media Uplaod:" + line);
                    }
                } catch (IOException ex) {
                    System.err.println(ex);
                }
                return statusCode;
            }

            protected void onPostExecute(Integer i){
                super.onPostExecute(i);
            }
        }.execute(theFile);
    }

    public String getPicturePathFromUri(Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = { MediaStore.Images.Media.DATA };
            cursor = getContentResolver().query(contentUri, proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private String getPathVideo(Uri uri) {
        String[] projection = {MediaStore.Video.Media.DATA, MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DURATION};
        Cursor cursor = getContentResolver().query(uri, projection, null, null, null);
        cursor.moveToFirst();
        return cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA));
    }

    private String getPathSound(Uri uri) {
        Cursor cursor = null;
        try {
            String[] proj = { MediaStore.Audio.Media.DATA };
            cursor = getContentResolver().query(uri, proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
}