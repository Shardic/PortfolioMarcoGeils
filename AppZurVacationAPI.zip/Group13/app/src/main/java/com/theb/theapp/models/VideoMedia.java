package com.theb.theapp.models;

/**
 * Created by Marco on 09.11.2015.
 */
public class VideoMedia extends Media {

    public String videoCodec;
    public float videoBitRate;
    public int width;
    public int height;
    public float frameRate;
    public String audioCodec;
    public float audioBitRate;
    public int channels;
    public float samplingRate;

    public VideoMedia(int id, int memoryId) {
        super(id, memoryId);
    }

    public String getVideoCodec() {
        return videoCodec;
    }

    public void setVideoCodec(String videoCodec) {
        this.videoCodec = videoCodec;
    }

    public float getVideoBitRate() {
        return videoBitRate;
    }

    public void setVideoBitRate(float videoBitRate) {
        this.videoBitRate = videoBitRate;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public float getFrameRate() {
        return frameRate;
    }

    public void setFrameRate(float frameRate) {
        this.frameRate = frameRate;
    }

    public String getAudioCodec() {
        return audioCodec;
    }

    public void setAudioCodec(String audioCodec) {
        this.audioCodec = audioCodec;
    }

    public float getAudioBitRate() {
        return audioBitRate;
    }

    public void setAudioBitRate(float audioBitRate) {
        this.audioBitRate = audioBitRate;
    }

    public int getChannels() {
        return channels;
    }

    public void setChannels(int channels) {
        this.channels = channels;
    }

    public float getSamplingRate() {
        return samplingRate;
    }

    public void setSamplingRate(float samplingRate) {
        this.samplingRate = samplingRate;
    }
}
