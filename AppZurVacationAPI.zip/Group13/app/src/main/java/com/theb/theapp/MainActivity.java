package com.theb.theapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.theb.theapp.utilities.SessionManager;
import com.theb.theapp.models.AccessTokenResponse;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

//TODO: Add Activities/Layouts for add memory
//TODO: Redo the linking of activities to include everything in the correct place
//TODO: Add Activities/Layouts for edit profile, edit Vacations
//DONE: Add Options to delete Memos Vacations Friends and Users
//TODO: Implement the Search in Memories
//TODO: Implement the adding MediaFiles

public class MainActivity extends AppCompatActivity {

    private SessionManager session;
    private TextView loginresult;
    private Button signin, register;
    private EditText username, password;
    private String usernameString, passwordString;
    int result = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (android.os.Build.VERSION.SDK_INT > 9)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        session = new SessionManager(getApplicationContext());
        if (session.isLoggedIn()) {
            startActivity(new Intent(MainActivity.this, NewsFeedActivity.class));
        } else {
            loginresult = (TextView)findViewById(R.id.welcome);
            signin = (Button)findViewById(R.id.signin);
            register = (Button)findViewById(R.id.register);


            signin.setOnClickListener(
                    new Button.OnClickListener() {
                        public void onClick(View v) {
                            username = (EditText) findViewById(R.id.login_username_input);
                            password = (EditText) findViewById(R.id.login_password_input);
                            usernameString = username.getText().toString();
                            passwordString = password.getText().toString();
                            //Login the User
                            login();
                        }
                    }
            );

            register.setOnClickListener(
                    new Button.OnClickListener() {
                        public void onClick(View v) {
                            startActivity(new Intent(MainActivity.this, RegisterActivity.class));
                            //To view SearchActivity
                        }
                    }
            );

            AdView mAdView = (AdView) findViewById(R.id.adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
        }
    }

    //Request token
    public void login() {

        HashMap<String,String> userLoginMap = new HashMap<>();
        userLoginMap.put("grant_type","password");
        userLoginMap.put("username",usernameString);
        userLoginMap.put("password", passwordString);

        //noinspection unchecked
        new AsyncTask<HashMap<String,String>, Void, Integer>() {
            String path = getString(R.string.ApiUrl) + "token";
            int statusCode = 0;
            protected Integer doInBackground(HashMap<String,String>... params) {

                try {
                    Log.d("test", "username: " + usernameString);
                    Log.d("test", "password: " + passwordString);

                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setDoInput(true);
                    connection.setDoOutput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    OutputStream outputStream = connection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(outputStream, "UTF-8"));
                    writer.write(getPostDataString(params[0]));
                    writer.flush();
                    writer.close();
                    outputStream.close();
                    statusCode = connection.getResponseCode();
                    Log.d("test", "status code after get is " + statusCode);
                    String response = "";
                    if (statusCode == 200) {
                        String line;
                        BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        while ((line=br.readLine()) != null) {
                            response+=line;
                        }
                        Gson gson = new Gson();
                        AccessTokenResponse accessToken = gson.fromJson(response, AccessTokenResponse.class);
                        session.createLoginSession(usernameString,passwordString,accessToken);
                        Log.d("test", response);
                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return statusCode;
            }

            @Override
            protected void onPostExecute(Integer integer) {
                Log.d("Result", "result code is " + integer);
                if(integer == 200)
                    startActivity(new Intent(MainActivity.this, NewsFeedActivity.class));
                else
                {
                    ((TextView)findViewById(R.id.loginfail)).setText("Login Failed!");
                }
            }
        }.execute(userLoginMap);
    }

    private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        Log.d("test", "getting PostDataStrings");
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for(Map.Entry<String, String> entry : params.entrySet()){
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }
}
