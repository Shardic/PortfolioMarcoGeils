package com.theb.theapp.utilities;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.theb.theapp.R;
import com.theb.theapp.models.Media;
import com.theb.theapp.models.Memory;

public class MediaAdapter extends ArrayAdapter<Media> {

    private static class ViewHolder {
        TextView title;
    }

    public MediaAdapter(Context context, Media[] medias) {
        super(context, R.layout.item_media, medias);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Media med = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        ViewHolder viewHolder; // view lookup cache stored in tag
        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_media, parent, false);
            viewHolder.title = (TextView) convertView.findViewById(R.id.mediaName);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        // Lookup view for data population

        // Populate the data into the template view using the data object
        viewHolder.title.setText("" + med.memory + " " + med.container);
        // Return the completed view to render on screen
        return convertView;
    }

}
