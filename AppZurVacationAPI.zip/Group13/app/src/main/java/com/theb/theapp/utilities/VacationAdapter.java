package com.theb.theapp.utilities;

import android.content.Context;
import android.support.v7.internal.view.menu.MenuView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.theb.theapp.R;
import com.theb.theapp.models.Vacation;

import java.util.ArrayList;
import java.util.List;

public class VacationAdapter extends ArrayAdapter<Vacation> {
    //View lookup cache
    private static class ViewHolder {
        TextView title;
    }

    public VacationAdapter(Context context, Vacation[] vacations) {
        super(context, R.layout.item_vacation, vacations);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Vacation vac = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        ViewHolder viewHolder; // view lookup cache stored in tag
        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_vacation, parent, false);
            viewHolder.title = (TextView) convertView.findViewById(R.id.vacationName);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        // Lookup view for data population

        // Populate the data into the template view using the data object
        viewHolder.title.setText(vac.title);
        // Return the completed view to render on screen
        return convertView;
    }

}
