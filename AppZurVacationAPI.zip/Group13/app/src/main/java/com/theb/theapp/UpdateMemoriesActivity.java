package com.theb.theapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.theb.theapp.models.Position;
import com.theb.theapp.utilities.SessionManager;
import com.theb.theapp.models.Memory;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/****************************

public class UpdateMemoriesActivity extends AppCompatActivity {

    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_memories);

        Integer longPosition, vacId = null, memId = null;
        final EditText title, desc, place, time, latPosition;


        session = new SessionManager(getApplicationContext());

        if (session.isLoggedIn()) {

            Button updateMemButton = (Button) findViewById(R.id.button_update_memory);
            Intent thisIntent = getIntent();

            if (thisIntent != null) {

                memId = thisIntent.getIntExtra("Memory ID", 0);
                vacId = thisIntent.getIntExtra("Vacation ID", 0);


                title = (EditText) findViewById(R.id.editText_update_memory_title);
                title.setText(thisIntent.getStringExtra("Memory Title"));

                desc = (EditText) findViewById(R.id.editText_update_memory_desc);
                desc.setText(thisIntent.getStringExtra("Memory Description"));

                place = (EditText) findViewById(R.id.editText_update_memory_place);
                place.setText(thisIntent.getStringExtra("Memory Place"));

                //Update API to provide Start and End. Then only can you uncomment this
                time = (EditText) findViewById(R.id.editText_update_memory_time);
                time.setText("" + thisIntent.getIntExtra("Memory Time", 0));

                latPosition = (EditText) findViewById(R.id.editText_update_memory_position);
                longPosition = thisIntent.getIntExtra("Memory Long", 0);
                latPosition.setText(longPosition + ", " + thisIntent.getIntExtra("Memory Lat", 0));


                final Integer afinalMemId = memId;
                final Integer afinalVacId = vacId;
                final EditText finalTitle = title;
                final EditText finalDesc = desc;
                final EditText finalPlace = place;
                final EditText finalTime = time;
                final EditText finalPosition = latPosition;

                updateMemButton.setOnClickListener(new Button.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        final Integer finalMemId = afinalMemId;
                        String finalMemTitle = finalTitle.getText().toString();
                        final String finalMemDesc = finalDesc.getText().toString();
                        final String finalMemPlace = finalPlace.getText().toString();

                        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                        Date date = null;
                        try {
                            date = format.parse(finalTime.getText().toString());
                            System.out.println(date);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }

                        final Date finalMemTime = date;
                        final Position finalMemPosition = null;
                        finalMemPosition.latitude= Integer.valueOf(finalPosition.getText().toString());
                        finalMemPosition.longtitude = Integer.valueOf(finalPosition.getText().toString());

                        final Integer finalVacId = afinalVacId;

                        Memory updateMem = new Memory(finalMemId, finalMemTitle, finalMemDesc, finalMemPlace, finalMemTime, finalMemPosition, finalVacId);
                        updateMemoryDetails(updateMem);

                    }


                });
            }
        }else {
            startActivity(new Intent(UpdateMemoriesActivity.this, MainActivity.class));
        }
    }
    public void updateMemoryDetails(Memory updateMem){

        new AsyncTask<Memory,Void,Integer>() {
            protected Integer doInBackground(Memory... params) {

                // /api/v1/vacations/<id>/memories
                String urlString = getString(R.string.ApiUrl) + "vacations/"+newMemory.VacationId+"/memories";
                URL url;
                int statusCode = 0;

                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("title", params[0].title);
                    jsonObject.put("description", params[0].description);
                    jsonObject.put("place", params[0].place);
                    jsonObject.put("time", params[0].time);
                    jsonObject.put("position", params[0].position);
                    jsonObject.put("VacationId", params[0].VacationId);
                    //jsonObject.put("userId", params[0].userId);
                    url = new URL(urlString);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setDoInput(true);
                    connection.setDoOutput(true);
                    connection.setRequestMethod("PATCH");
                    connection.addRequestProperty("Content-Type", "application/json");
                    connection.setRequestProperty("Accept", "application/json");
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    OutputStream outputstream = connection.getOutputStream();
                    OutputStreamWriter writer = new OutputStreamWriter(outputstream);
                    writer.write(jsonObject.toString());
                    writer.close();
                    outputstream.close();
                    statusCode = connection.getResponseCode();
                    connection.disconnect();
                    if(statusCode == 400) {
                        Log.d("test", "Error in updating the memory");
                    } else if (statusCode == 200) {
                        Log.d("test", "Memory updated");
                    }
                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }
                return statusCode;
            }

            protected void onPostExecute(Integer i) {
                super.onPostExecute(i);
                if (i == 200) {
                    Toast.makeText(getApplicationContext(), "Memory updated", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Error in updating the memory.", Toast.LENGTH_SHORT).show();
                }
            }
        }.execute(updateMem);

    }
}
*/
