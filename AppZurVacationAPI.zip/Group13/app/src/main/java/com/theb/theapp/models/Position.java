package com.theb.theapp.models;

/**
 * Created by Marco on 09.11.2015.
 */
public class Position {

    public float longitude;
    public float latitude;

    public Position(float latitude, float longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Position() {

    }
}
