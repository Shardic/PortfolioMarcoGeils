package com.theb.theapp.utilities;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.theb.theapp.models.Memory;
import com.theb.theapp.models.User;
import com.theb.theapp.models.Vacation;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context context) {
        super(context, "vacationApp.db", null, 1);
    }

    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(
                    "CREATE TABLE User (" +
                            "id INTEGER PRIMARY KEY," +
                            "firstName TEXT," +
                            "lastName TEXT," +
                            "username TEXT NOT NULL," +
                            "email TEXT NOT NULL" +
                            ")"
            );

            db.execSQL(
                    "CREATE TABLE friends (" +
                            "username1 TEXT NOT NULL," +
                            "username2 TEXT NOT NULL" +
                            ")"
            );

            db.execSQL(
                    "CREATE TABLE Vacation (" +
                            "id INTEGER NOT NULL," +
                            "title TEXT NOT NULL," +
                            "description TEXT NOT NULL," +
                            "place TEXT NOT NULL," +
                            "start INTEGER NOT NULL," +
                            "end INTEGER NOT NULL," +
                            "username TEXT NOT NULL" +
                            ")"
            );

            db.execSQL(
                    "CREATE TABLE Memory (" +
                            "id INTEGER NOT NULL," +
                            "title TEXT NOT NULL," +
                            "description TEXT NOT NULL," +
                            "place TEXT NOT NULL," +
                            "time DATE NOT NULL," +
                            "posLong FLOAT NOT NULL," +
                            "posLat FLOAT NOT NULL," +
                            "vacID INTEGER NOT NULL" +
                            ")"
            );

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS User");
        db.execSQL("DROP TABLE IF EXISTS friends");
        db.execSQL("DROP TABLE IF EXISTS Vacation");
        db.execSQL("DROP TABLE IF EXISTS Memory");
        onCreate(db);

    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    /*******
     * CACHING FRIENDS
     * SAVING FRIENDS AND DELETING FRIENDS
     */
    public void delFriends(DatabaseHelper db, String baseFriend, User[] friends) {

        SQLiteDatabase sq = db.getWritableDatabase();

        for (User friend : friends) {
            sq.delete("friends", "(username1=? AND username2=?) OR (username2=? AND username1=?)",
                    new String[]{friend.username, baseFriend});
        }
    }

    public void makeFriends(DatabaseHelper db, String baseFriend, User[] friends) {
        //DONE Avoid duplicate values

        Cursor mCursor;

        SQLiteDatabase sq = db.getWritableDatabase();
        ContentValues cv = new ContentValues();

        //iterate through creating links between friends
        for (User friend : friends) {

            mCursor = sq.rawQuery("SELECT * FROM friends WHERE (username1=? AND username2=?) || (username2=? AND username1=?)", new String[]{baseFriend, friend.username});
            if (mCursor == null) {
                cv.put("username1", baseFriend);
                cv.put("username2", friend.username);
                sq.insert("friends", null, cv);

                Log.d("SAVEFRIENDS", "Friends data added" + baseFriend + friend.username);
            }
        }
    }

    /*********
     * CACHING USER PROFILE INFORMATION
     * DELETE AND SAVE PROFILE
     */

    public void deleteProfile(DatabaseHelper db, User user) {

        SQLiteDatabase sq = db.getWritableDatabase();
        //iterate through creating links between friends

        sq.delete("User", "username=?", new String[]{user.username});
        Log.d("DELPROFILE", "User data deleted" + user.username);
    }

    public void saveProfile(DatabaseHelper db, User user) {

        Cursor mCursor;

        SQLiteDatabase sq = db.getWritableDatabase();
        ContentValues cv = new ContentValues();
        //iterate through creating links between friends

        mCursor = sq.rawQuery("SELECT * FROM User WHERE username=?", new String[]{user.username});
        Log.d("SAVEPROFILE CURSORSTAT", "" + String.valueOf(mCursor));
        if (!mCursor.moveToNext()) {
            cv.put("id", user.id);
            cv.put("email", user.email);
            cv.put("firstName", user.firstName);
            cv.put("lastName", user.lastName);
            cv.put("username", user.username);

            sq.insert("User", null, cv);

            Log.d("SAVEPROFILE", "User data added" + user.username);
        }
    }

    /**********
     * CACHING VACATION DETAILS
     * SAVING VACATIONS AND DELETING THEM
     */

    public void delVacations(DatabaseHelper db, String username, Vacation[] vacations) {

        SQLiteDatabase sq = db.getWritableDatabase();

        for (Vacation vacation : vacations) {
            sq.delete("Vacation", "(id=? AND username=?)",
                    new String[]{String.valueOf(vacation.id), username});
        }
    }

    public void saveVacations(DatabaseHelper db, String username, Vacation[] vacations) {
        Cursor mCursor;

        SQLiteDatabase sq = db.getWritableDatabase();
        ContentValues cv = new ContentValues();
        //iterate through creating links between friends
        for (Vacation vacation : vacations) {

            mCursor = sq.rawQuery("SELECT * FROM Vacation WHERE (id=? AND username=?)", new String[]{String.valueOf(vacation.id), username});
            Log.d("SAVEVACATION CURSORSTAT", "" + String.valueOf(mCursor));
            if (!mCursor.moveToNext()) {
                cv.put("id", vacation.id);
                cv.put("title", vacation.title);
                cv.put("description", vacation.description);
                cv.put("place", vacation.place);
                cv.put("start", vacation.start);
                cv.put("end", vacation.end);
                cv.put("username", username);

                sq.insert("Vacation", null, cv);

                Log.d("SAVEVACATIONS", "Vacation data added" + vacation.title);
            }
        }
    }

    /**********
     * CACHING MEMORY INFORMATION
     * SAVING MEMORY AND DELETING MEMORY
     */

    public void saveMemories(DatabaseHelper db, Integer vac_id, Memory[] memories) {

        Cursor mCursor;

        SQLiteDatabase sq = db.getWritableDatabase();
        ContentValues cv = new ContentValues();
        //iterate through creating links between friends
        for (Memory memory : memories) {

            mCursor = sq.rawQuery("SELECT * FROM Memory WHERE (vacID=? AND title=?)", new String[]{String.valueOf(vac_id), memory.title});
            Log.d("SAVEMEM CURSORSTAT", "" + String.valueOf(mCursor));
            if (!mCursor.moveToNext()) {
                cv.put("id", memory.id);
                cv.put("title", memory.title);
                cv.put("description", memory.description);
                cv.put("place", memory.place);
                cv.put("posLong", memory.position.longitude);
                cv.put("posLat", memory.position.latitude);
                cv.put("vacID", vac_id);

                sq.insert("Memory", null, cv);

                Log.d("SAVEMEM", "Memory data added" + memory.title);
            }
        }
    }

    public void delMemories(DatabaseHelper db, Integer vac_id, Memory[] memories) {
        SQLiteDatabase sq = db.getWritableDatabase();

        for (Memory memory : memories) {
            sq.delete("Memory", "(vacID=? AND title=?)",
                    new String[]{String.valueOf(vac_id), memory.title});
        }

    }
}


    /*public static boolean CheckIsDataAlreadyInDBorNot(String TableName,String dbfield, String fieldValue) {
        SQLiteDatabase sqldb = EGLifeStyleApplication.sqLiteDatabase;
        String Query = "Select * from " + TableName + " where " + dbfield + " = " + fieldValue;
        Cursor cursor = sqldb.rawQuery(Query, null);
        if(cursor.getCount() <= 0){
            cursor.close();
            return false;
        }
        cursor.close();
        return true;
    }*/
