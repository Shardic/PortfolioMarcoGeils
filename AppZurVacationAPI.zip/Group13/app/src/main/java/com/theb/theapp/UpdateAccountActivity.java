package com.theb.theapp;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.theb.theapp.utilities.SessionManager;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import com.theb.theapp.models.User;

public class UpdateAccountActivity extends AppCompatActivity {


    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_account);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Update Your Information");

        session = new SessionManager(getApplicationContext());
        if (session.isLoggedIn()) {

            Button updateButton = (Button) findViewById(R.id.buttonUpdateInfo);
            TextView userNameView = (TextView) findViewById(R.id.editUserName);
            userNameView.setText(session.getUsername());

            //Updating User Information
            updateButton.setOnClickListener(new Button.OnClickListener() {
                public void onClick(View v) {

                    String email;
                    String firstName, lastName;

                    EditText emailEditText = (EditText) findViewById(R.id.editTextEmail);
                    email = emailEditText.getText().toString();
                    EditText firstNameeditText = (EditText) findViewById(R.id.editTextFirstName);
                    firstName = firstNameeditText.getText().toString();
                    EditText lastNameeditText = (EditText) findViewById(R.id.editTextLastName);
                    lastName = lastNameeditText.getText().toString();

                    updateAccountDetails(email, firstName, lastName);

                }
            });
        } else {
            startActivity(new Intent(UpdateAccountActivity.this, MainActivity.class));
        }
    }

    public void updateAccountDetails(String email, String firstName, String lastName) {
        if (email.isEmpty() && firstName.isEmpty() && lastName.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please enter the details you want updated.", Toast.LENGTH_SHORT).show();
        } else {

            User updateUser = new User(email, firstName, lastName);
            ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {

                new AsyncTask<User, Void, Integer>() {

                    @Override
                    protected Integer doInBackground(User... params) {
                        ///api/v1/users/<username>
                        //PUT: Updates the user with username <username>.
                        String urlString = getString(R.string.ApiUrl) + "users/" + session.getUsername();
                        URL url;
                        Log.d("Path: ", urlString);
                        int statusCode = 0;

                        try {
                            JSONObject jsonObject = new JSONObject();

                            jsonObject.put("email", params[0].email);
                            jsonObject.put("firstName", params[0].firstName);
                            jsonObject.put("lastName", params[0].lastName);

                            url = new URL(urlString);
                            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                            connection.setDoOutput(true);
                            connection.setRequestMethod("PATCH");
                            connection.addRequestProperty("Content-Type", "application/json");
                            connection.setRequestProperty("Accept", "application/json");
                            connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());

                            OutputStream outputstream = connection.getOutputStream();
                            OutputStreamWriter writer = new OutputStreamWriter(outputstream);
                            writer.write(jsonObject.toString());
                            writer.close();
                            outputstream.close();
                            statusCode = connection.getResponseCode();
                            connection.disconnect();
                            if (statusCode == 400) {
                                Log.d("RESULT: ", "ERROR" + statusCode);
                            } else if (statusCode == 200) {
                                Log.d("RESULT: ", "Your data has been updated!" + statusCode);
                            } else {
                                Log.d("The STATUS CODE: ", "" + statusCode);
                            }

                        } catch (IOException | JSONException e) {
                            e.printStackTrace();
                        }

                        return statusCode;
                    }

                    protected void onPostExecute(Integer value) {
                        super.onPostExecute(value);
                        if (value == 200) {
                            Toast.makeText(getApplicationContext(), "Your information has been updated.", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "Something isn't working right.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }.execute(updateUser);
            } else {
                Toast.makeText(getApplicationContext(), "No network connection available.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
