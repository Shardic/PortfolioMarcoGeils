package com.theb.theapp.utilities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.theb.theapp.MainActivity;
import com.theb.theapp.models.AccessTokenResponse;

public class SessionManager {

    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;

    int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "VacationAppPreference";
    private static final String IS_LOGIN = "IsLoggedIn";
    public static final String KEY_USERNAME = "username";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_TOKEN = "token";
    public static final String KEY_TOKENTYPE = "tokentype";
    public static final String KEY_TOKENEXPIRETIME = "tokenexpiretime";

    // Constructor
    public SessionManager(Context context){
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }


    public void createLoginSession(String username, String password, AccessTokenResponse accessTokenResponse){
        Log.d("test", "LoginGetsChecked");
        editor.putBoolean(IS_LOGIN, true);
        editor.putString(KEY_USERNAME, username);
        editor.putString(KEY_PASSWORD, password);
        editor.putString(KEY_TOKEN, accessTokenResponse.getAccess_token());
        editor.putString(KEY_TOKENTYPE, accessTokenResponse.getToken_type());
        long expireTime = System.currentTimeMillis() + accessTokenResponse.getExpires_in()*1000;
        editor.putLong(KEY_TOKENEXPIRETIME, expireTime);

        editor.commit();
    }

    public String getUsername() {
        return pref.getString(KEY_USERNAME, null);
    }

    public String getTokentype() {
        return pref.getString(KEY_TOKENTYPE, null);
    }

    public String getToken() {
        return pref.getString(KEY_TOKEN, null);
    }

    public boolean isLoggedIn() {
        //Log.d("test", "Login token data: " + pref.getString(KEY_TOKENTYPE, null) + pref.getString(KEY_TOKEN, null));

        if (pref.getBoolean(IS_LOGIN, false)) {
            if (this.loginTimeOutReached()) {
                logoutUser();
                return false;
            }
            return true;
        } else {
            return false;
        }
    }

    public boolean loginTimeOutReached() {
        long actualTime = System.currentTimeMillis();
        long runOutTime = pref.getLong(KEY_TOKENEXPIRETIME,0);
        return actualTime > runOutTime;
    }

    public void logoutUser(){
        // Clearing all data from Shared Preferences
        editor.clear();
        editor.commit();
        Intent i = new Intent(_context, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        _context.startActivity(i);
    }

}
