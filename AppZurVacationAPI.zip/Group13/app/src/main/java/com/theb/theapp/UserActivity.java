package com.theb.theapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.gson.Gson;
import com.theb.theapp.utilities.SessionManager;
import com.theb.theapp.utilities.VacationAdapter;
import com.theb.theapp.models.User;
import com.theb.theapp.models.Vacation;
import com.theb.theapp.utilities.DatabaseHelper;
import com.theb.theapp.utilities.SwipeDetector;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

public class UserActivity extends AppCompatActivity {

    TextView usernameView, fullNameView;
    SessionManager session;
    String theUsernameOfThisProfile = "";
    Menu thisMenu;
    SwipeDetector swipeDetector = new SwipeDetector();
    int vacationToDelete = 0;


    AlertDialog vacDeleterDialog;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("test", "Profile View is started");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        // Install the Android Support Library per the SDK Manager to get that to work
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Log.d("test", "ActionBarIsSet");

        vacDeleterDialog = new AlertDialog.Builder(this).setTitle("Confirm Delete")
                .setMessage("Do you want to delete this Vacation?")
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (vacationToDelete != 0) {
                            deleteVacation();
                        }
                    }
                })
                .setNeutralButton("Cancel", null) // don't need to do anything but dismiss here
                .create();

        session = new SessionManager(getApplicationContext());
        Log.d("test", "ActionBarIsSet");
        if (session.isLoggedIn()) {
            Intent thisIntent = getIntent();

            //Check if there is an online connection
            ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isConnected() && networkInfo.isAvailable()) {

                if (thisIntent != null) {
                    Bundle bundle = thisIntent.getExtras();
                    String username = (String) bundle.get("username");
                    Log.d("test", "The extra named " + username + " was put.");
                    loadUserData(username);
                    loadVacationList(username);
                }
            } else {
                //No online connection

                final User cachedUser = accessUsers(session.getUsername());
                usernameView = (TextView) findViewById(R.id.Username);
                fullNameView = (TextView) findViewById(R.id.FirstAndLastName);

                if (cachedUser != null) {
                    usernameView.setText(cachedUser.username);
                    fullNameView.setText(cachedUser.firstName + " " + cachedUser.lastName);
                }
                else
                {
                    usernameView.setText(":( Oops");
                }

                ListView vacationList = (ListView) findViewById(R.id.VacationsList);
                Vacation[] cachedVacations;
                cachedVacations = accessVacations(session.getUsername());
               /* int value = 0;

                try {
                    value = cachedVacations.length;
                }
                catch(NullPointerException e){
                    e.printStackTrace();
                }*/
                if (cachedVacations != null) {

                    //If there are cached Vacations do the following
                    Log.d("Cached Vacations", Arrays.toString(cachedVacations));
                    //ArrayAdapter<Vacation> adapter = new ArrayAdapter<>(UserActivity.this, android.R.layout.simple_list_item_1, cachedVacations);
                    VacationAdapter adapter = new VacationAdapter(UserActivity.this, cachedVacations);
                    vacationList.setAdapter(adapter);

                    //Clicking on friend provides a profile view of the friend
                    final Vacation[] finalCachedVacations = cachedVacations;
                    vacationList.setOnItemClickListener((new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            Log.d("Chosen Vacation", String.valueOf(finalCachedVacations[position].title));

                            Intent intent = new Intent(UserActivity.this, VacationActivity.class);
                            intent.putExtra("Vacation ID", finalCachedVacations[position].id);
                            startActivity(intent);
                        }
                    }));
                } else {
                    //If there are no cached Vacations
                    String[] noVacation = {"You need a LIFE!"};
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(UserActivity.this, android.R.layout.simple_list_item_1, noVacation);
                    vacationList.setAdapter(adapter);
                }
            }
        } else {
            startActivity(new Intent(UserActivity.this, MainActivity.class));
        }
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    /***************
     * CACHE: PROVIDE USER PROFILE INFORMATION
     ***************/
    private User accessUsers(String username) {

        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String usernameOne = "\"" + username + "\"";
        User currentUser = null;

        Cursor cursor = db.rawQuery("SELECT * FROM User WHERE username = " + usernameOne, null);

        if (cursor.moveToFirst()) {
            Log.d("Cursor is not null", String.valueOf(cursor));

            try {
                currentUser.username = cursor.getString(cursor.getColumnIndex("username"));
                currentUser.firstName = cursor.getString(cursor.getColumnIndex("firstName"));
                currentUser.lastName = String.valueOf(cursor.getColumnIndex("lastName"));
                currentUser.email = String.valueOf(cursor.getColumnIndex("email"));

                Log.d("CURRENTUSER:", String.valueOf(currentUser));
                cursor.close();
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
        }

        return currentUser;
    }

    /********************
     * LIST ALL CACHED VACATION
     *********************/
    private Vacation[] accessVacations(String username) {

        //TODO List all cached Vacations
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String usernameOne = "\"" + username + "\"";
        Vacation[] vacations = new Vacation[]{};

        Cursor cursor = db.rawQuery("SELECT * FROM Vacation WHERE username = " + usernameOne, null);

        if (cursor != null) {
            Log.d("Cursor is not null", String.valueOf(cursor));

            try {
                if (cursor.moveToFirst()) {
                    for (Integer i = 0; i < cursor.getCount(); i++, cursor.moveToNext()) {
                        vacations[i].id = cursor.getInt(cursor.getColumnIndex("id"));
                        vacations[i].title = cursor.getString(cursor.getColumnIndex("title"));
                        vacations[i].description = cursor.getString(cursor.getColumnIndex("description"));
                        vacations[i].place = cursor.getString(cursor.getColumnIndex("place"));
                        vacations[i].start = cursor.getInt(cursor.getColumnIndex("start"));
                        vacations[i].end = cursor.getInt(cursor.getColumnIndex("end"));
                    }
                }
                cursor.close();
            } catch (NullPointerException | ArrayIndexOutOfBoundsException e) {
                e.printStackTrace();
            }
        }

        //return names.toArray(new String[names.size()]);
        return vacations;
    }

    /*************RETRIEVE USER INFORMATION AND DISPLAY IN USER PROFILE. ****************/
    /*************
     * STORE USER INFO IN SQLITE FOR CACHING PURPOSES.
     ***********************/
    public void loadUserData(final String username) {
        usernameView = (TextView) findViewById(R.id.Username);
        fullNameView = (TextView) findViewById(R.id.FirstAndLastName);

        new AsyncTask<String, Void, User>() {

            @Override
            protected User doInBackground(String... params) {
                String path = getString(R.string.ApiUrl) + "users/" + username;
                Log.d("test", "following url gets a request " + path);
                User user = new User("0");
                try {
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setDoInput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/json");
                    Log.d("test", session.getTokentype() + " " + session.getToken());
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    int statusCode = connection.getResponseCode();
                    Log.d("test", "status code after get is " + statusCode);
                    String response = "";
                    if (statusCode == 200) {
                        String line;
                        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        while ((line = br.readLine()) != null) {
                            response += line;
                        }
                        Gson gson = new Gson();
                        user = gson.fromJson(response, User.class);
                        Log.d("test", response);
                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return user;
            }

            @Override
            protected void onPostExecute(User user) {
                super.onPostExecute(user);
                theUsernameOfThisProfile = user.username;

                try {
                if (session.getUsername().equals(theUsernameOfThisProfile)) {
                        MenuItem i = thisMenu.findItem(R.id.action_deleteAccount);
                        i.setVisible(true);
                    }else{
                        MenuItem i = thisMenu.findItem(R.id.action_removeFriend);
                        i.setVisible(true);
                    }
                }
                catch(NullPointerException e){
                    e.printStackTrace();
                }
                usernameView.setText(user.username);
                fullNameView.setText(user.firstName + " " + user.lastName);

                //DONE Add personal details to the SQLite
                Context ctx = UserActivity.this;
                DatabaseHelper databaseHelper = new DatabaseHelper(ctx);
                databaseHelper.deleteProfile(databaseHelper, user);
                databaseHelper.saveProfile(databaseHelper, user);
            }
        }.execute(username);
    }

    /*************RETRIEVE VACATION INFORMATION AND DISPLAY IN USER PROFILE UNDER USER DETAILS. ****************/
    /*************DELETE VACATIONS BY SWIPING & EDIT VACATION BY PRESS AND HOLD**************/
    /*************
     * STORE VACATION DETAILS IN SQLITE FOR CACHING PURPOSES.
     ***********************/
    public void loadVacationList(final String username) {
        //DONE: load the vacations for the user

        new AsyncTask<String, Void, Vacation[]>() {
            protected Vacation[] doInBackground(String... params) {
                String path = getString(R.string.ApiUrl) + "users/" + params[0] + "/vacations";
                Log.d("test", "following url gets a request " + path);
                Vacation[] vacations = new Vacation[]{};
                try {
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setDoInput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/json");
                    Log.d("test", session.getTokentype() + " " + session.getToken());
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    int statusCode = connection.getResponseCode();
                    Log.d("test", "status code after get is " + statusCode);
                    String response = "";

                    if (statusCode == 200) {
                        String line;
                        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        while ((line = br.readLine()) != null) {
                            response += line;
                        }
                        Gson gson = new Gson();
                        vacations = gson.fromJson(response, Vacation[].class);
                        //Log.d("test", response);
                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return vacations;
            }

            @Override
            protected void onPostExecute(final Vacation[] vacations) {
                super.onPostExecute(vacations);
                //DONE: implement an adapter who adds the vacation list to the mListView
                //DONE: implement a new ArrayAdapter as a class for Viewing Vacations as Views see tutorial:https://github.com/codepath/android_guides/wiki/Using-an-ArrayAdapter-with-ListView

                VacationAdapter adapter = new VacationAdapter(UserActivity.this, vacations);
                ListView listview = (ListView) findViewById(R.id.VacationsList);
                listview.setAdapter(adapter);

                //DONE Cache:Add Vacation details to the SQLite
                Context ctx = UserActivity.this;
                DatabaseHelper databaseHelper = new DatabaseHelper(ctx);
                databaseHelper.delVacations(databaseHelper, session.getUsername(), vacations);
                databaseHelper.saveVacations(databaseHelper, session.getUsername(), vacations);

                listview.setOnTouchListener(swipeDetector);
                //Clicking on a specific Vacation provides further information on Vacation
                listview.setOnItemClickListener((new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        if (swipeDetector.swipeDetected()) {
                            if (swipeDetector.getAction() == SwipeDetector.Action.RL) {
                                vacationToDelete = vacations[position].id;
                                vacDeleterDialog.show();
                            }
                        } else {
                            Log.d("Vacation ID", String.valueOf(vacations[position].id));

                            Intent intent = new Intent(UserActivity.this, VacationActivity.class);
                            intent.putExtra("Vacation ID", vacations[position].id);
                            intent.putExtra("Vacation Title", vacations[position].title);
                            intent.putExtra("Vacation Description", vacations[position].description);
                            intent.putExtra("Vacation Place", vacations[position].place);
                            intent.putExtra("Vacation Start", vacations[position].start);
                            intent.putExtra("Vacation End", vacations[position].end);
                            intent.putExtra("Vacation UserId", vacations[position].userId);
                            intent.putExtra("Vacation UserName", username);
                            startActivity(intent);
                        }
                    }
                }));

                //Pressing and Holding on specific Vacation leads to Editing Vacation
                listview.setOnItemLongClickListener((new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                        Log.d("Vacation ID", String.valueOf(vacations[position].id));


                        Intent intent = new Intent(UserActivity.this, UpdateVacationActivity.class);
                        intent.putExtra("Vacation ID", vacations[position].id);
                        intent.putExtra("Vacation Title", vacations[position].title);
                        intent.putExtra("Vacation Description", vacations[position].description);
                        intent.putExtra("Vacation Place", vacations[position].place);
                        intent.putExtra("Vacation Start", vacations[position].start);
                        intent.putExtra("Vacation End", vacations[position].end);
                        intent.putExtra("Vacation UserId", vacations[position].userId);
                        startActivity(intent);

                        return false;
                    }
                }));
            }
        }.execute(username);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        thisMenu = menu;
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if(id == R.id.action_signout) {
            session.logoutUser();
            startActivity(new Intent(UserActivity.this, MainActivity.class));
            //DONE: Sign out user
        }

        if (id == R.id.action_mediaupload) {
            startActivity(new Intent(UserActivity.this, MediaUploadActivity.class));
        }

        if (id == R.id.action_search) {
            startActivity(new Intent(UserActivity.this, SearchActivity.class));
        }

        if (id == R.id.menu_newsfeed) {
            startActivity(new Intent(UserActivity.this, NewsFeedActivity.class));
        }

        if (id == R.id.action_user) {
            Intent intent = new Intent(UserActivity.this, UserActivity.class);
            intent.putExtra("username", session.getUsername());
            Log.d("test", "Profile View should start now");
            startActivity(intent);
        }

        if (id == R.id.action_removeFriend) {
            this.removeFriend(theUsernameOfThisProfile);
            startActivity(new Intent(UserActivity.this, NewsFeedActivity.class));
        }

        if (id == R.id.action_deleteAccount) {
            this.deleteAccount();
            startActivity(new Intent(UserActivity.this, MainActivity.class));
        }

        if (id == R.id.action_addFriend) {
            startActivity(new Intent(UserActivity.this, AddFriendActivity.class));
        }

        if(id == R.id.action_searchuser) {
            startActivity(new Intent(UserActivity.this, SearchUserActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }

    //DONE: Put in menu when user shown and session user is not the same, pass the username from shown user
//Deletes Friend, should only be available when the User shown in the activity is a different user then the logged in User
    public void removeFriend(final String friendToDelete) {
        new AsyncTask<String, Void, Integer>() {
            protected Integer doInBackground(String... params) {
                String path = getString(R.string.ApiUrl) + "users/" + session.getUsername() + "/friends/" + friendToDelete;
                int statusCode = 0;
                try {
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("DELETE");
                    connection.setDoInput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/json");
                    Log.d("test", session.getTokentype() + " " + session.getToken());
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    statusCode = connection.getResponseCode();
                    if (statusCode == 200) {
                        Log.d("test", "Successfully deleted user as a friend");
                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return statusCode;
            }

            @Override
            protected void onPostExecute(Integer i) {
                super.onPostExecute(i);
                if (i == 200) {
                    Toast.makeText(getApplicationContext(), "You unfriended him.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Deletion failed", Toast.LENGTH_SHORT).show();
                }
            }
        }.execute(friendToDelete);
    }


    //DONE: make available in menu when user shown and session user is the same person
    //Deletes Friend, should only be available when the User shown in the activity is the same user as the logged in User
    public void deleteAccount() {
        new AsyncTask<String, Void, Integer>() {
            protected Integer doInBackground(String... params) {
                String path = getString(R.string.ApiUrl) + "users/" + session.getUsername();
                int statusCode = 0;
                try {
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("DELETE");
                    connection.setDoInput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/json");
                    Log.d("test", session.getTokentype() + " " + session.getToken());
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    statusCode = connection.getResponseCode();
                    if (statusCode == 200) {
                        Log.d("test", "Successfully deleted your Account");
                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return statusCode;
            }

            @Override
            protected void onPostExecute(Integer i) {
                super.onPostExecute(i);
                if (i == 200) {
                    Toast.makeText(getApplicationContext(), "You deleted your Account", Toast.LENGTH_SHORT).show();
                    session.logoutUser();
                } else {
                    Toast.makeText(getApplicationContext(), "Deletion failed", Toast.LENGTH_SHORT).show();
                }
            }
        }.execute();
    }

    public void deleteVacation() {
        new AsyncTask<Integer, Void, Integer>() {
            protected Integer doInBackground(Integer... params) {
                String path = getString(R.string.ApiUrl) + "vacations/" + params[0];
                int statusCode = 0;
                try {
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("DELETE");
                    connection.setDoInput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/json");
                    Log.d("test", session.getTokentype() + " " + session.getToken());
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    statusCode = connection.getResponseCode();
                    if (statusCode == 200) {
                        Log.d("test", "Successfully deleted the Vacation");
                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return statusCode;
            }

            @Override
            protected void onPostExecute(Integer i) {
                super.onPostExecute(i);
                if (i == 200) {
                    Toast.makeText(getApplicationContext(), "You deleted this Vacation", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(UserActivity.this, UserActivity.class);
                    intent.putExtra("username", theUsernameOfThisProfile);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "Deletion failed", Toast.LENGTH_SHORT).show();
                }
            }
        }.execute(vacationToDelete);
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "User Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://com.theb.theapp/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "User Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://com.theb.theapp/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }


}
