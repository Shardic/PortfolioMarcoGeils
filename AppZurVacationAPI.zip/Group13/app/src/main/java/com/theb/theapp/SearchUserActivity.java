package com.theb.theapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import com.google.gson.Gson;
import com.theb.theapp.models.Memory;
import com.theb.theapp.models.User;
import com.theb.theapp.utilities.FriendAdapter;
import com.theb.theapp.utilities.MemoryAdapter;
import com.theb.theapp.utilities.SessionManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;

public class SearchUserActivity extends AppCompatActivity {


    private Button goUser;
    private EditText query_search;
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_user);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        session = new SessionManager(getApplicationContext());

        if(session.isLoggedIn()) {
            goUser = (Button) findViewById(R.id.button_search_user);
            //Search for a user
            goUser.setOnClickListener(
                    new Button.OnClickListener() {
                        public void onClick(View v) {
                            query_search = (EditText) findViewById(R.id.text_search_user);
                            String query = query_search.getText().toString();

                            //Log.v("Memory", memory_search.getText().toString());
                            //SearchActivity based on memory details

                            searchUser(query);
                        }
                    }
            );

        }
    }

    private void searchUser(String username){
        new AsyncTask<String, Void, User[]>() {

            protected User[] doInBackground(String... params) {


                // /api/v1/users/<username>
                // Returns the user with username <username>.
                String path = getString(R.string.ApiUrl) + "users/"+params[0];
                Log.d("Path", path);
                User[] user = new User[] {};

                try{
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setDoInput(true);
                    connection.addRequestProperty("Accept", "application/json");
                    connection.addRequestProperty("Content-Type", "application/json");
                    Log.d("test", session.getTokentype() + " " + session.getToken());
                    connection.setRequestProperty("Authorization", session.getTokentype() + " " + session.getToken());
                    int statusCode = connection.getResponseCode();
                    Log.d("test", "status code after get is " + statusCode);
                    String response = "";
                    if (statusCode == 200) {
                        String line;
                        BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        while ((line=br.readLine()) != null) {
                            response+=line;
                        }
                        Gson gson = new Gson();
                        user = gson.fromJson(response, User[].class);
                        Log.d("test", response);
                    } else {
                        Log.d("test", "Error in Response");
                    }
                    connection.disconnect();
                } catch (IOException | NullPointerException e) {
                    e.printStackTrace();
                }

                return user;
            }

            protected void onPostExecute(final User[] users) {
                super.onPostExecute(users);

                if(Arrays.toString(users) != "[]"){

                    FriendAdapter adapter = new FriendAdapter(SearchUserActivity.this, users);
                    ListView listview = (ListView) findViewById(R.id.search_user_list);
                    listview.setAdapter(adapter);

                    listview.setOnItemClickListener((new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                           // Log.d("Memory ID", String.valueOf(memories[position].id));

                            Intent intent = new Intent(SearchUserActivity.this, UserActivity.class);
                            intent.putExtra("username", users[position].username);
                            startActivity(intent);
                        }
                    }));
                }
                else {

                    String[] values = new String[] { "No matching memories here. Try again!"};
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(SearchUserActivity.this,android.R.layout.simple_list_item_1, 0, values);
                    ListView listview = (ListView) findViewById(R.id.search_user_list);
                    listview.setAdapter(adapter);
                }

            }
        }.execute(username);
    }

}
